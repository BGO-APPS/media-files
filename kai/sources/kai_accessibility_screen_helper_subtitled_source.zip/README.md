# Google Play Accessibility Declaration — Screen Helper Subtitles

Complete Play Store accessibility declaration responses and dual SRT/VTT subtitles.
