# Creative Prompt & Synthesis Pipeline: Creator Phone Reaction

## Generation Prompt
```
Genuine surprised reaction as phone receives incoming autonomous voice call from KAI rescheduling Google Calendar meeting.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
