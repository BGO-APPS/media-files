import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { kai, fontFamily } from "../theme";
import { ChatBubble } from "../components/ChatBubble";
import { TypewriterLine } from "../components/TypewriterLine";
import { LiveDot } from "../components/LiveDot";
import { KaiStamp } from "../components/KaiStamp";

// Day 2 — "It Remembered". Template: Typewriter Cursor Reveal.
// Opens with a short backstory of marketing.md's "three weeks of tiny
// moments" — two earlier, unrelated things the user casually told KAI,
// each timestamped weeks apart — so the birthday recall below reads as a
// payoff, not a cold open. Then a near-literal storyboard of marketing.md
// §5 Scenario B (Arjun / mom's birthday) — a chat thread growing downward,
// three bubbles stacking to read as "the whole exchange" (reinforces "it
// remembers weeks of context"). fps 30. Beat frames map to the brief's
// approximate second-timings.
const CHARS_PER_FRAME = 0.9; // matches TypewriterLine's own default
const BACKSTORY_CHARS_PER_FRAME = 1.6; // faster — these beats are brief asides

// --- Beats 0-1 (NEW): two casual, unrelated messages from weeks ago,
// establishing "KAI remembers lots of small stuff" before the payoff below.
const OPEN_A_LEN = 54; // 1.8s: "3 weeks ago" caption + bubble, typed out
const OPEN_B_LEN = 48; // 1.6s: "2 weeks ago" caption + bubble, typed out
const BACKSTORY_LEN = OPEN_A_LEN + OPEN_B_LEN; // 102 frames (3.4s) total

const BACKSTORY_BUBBLE_START = 12; // per-beat local frame: bubble pops in
const BACKSTORY_TYPE_START = 16; // text starts just after the pop

const CAPTION_A = "3 weeks ago";
const TEXT_A = "I hate morning meetings, remind me gently";
const CAPTION_B = "2 weeks ago";
const TEXT_B = "add oat milk to the list";

// --- Beats 2-5 (existing payoff sequence, unchanged internally — pushed
// later in the overall timeline only via the Sequence `from` prop below).
const BEAT_1_END = 15; // +0.0-0.5s: lone blinking caret, no text yet
const BUBBLE_1_START = 15; // +0.5s: bubble 1 pops in + types concurrently (ends ~1.8s later)
const BUBBLE_2_START = 54; // +1.8s hard cut: bubble 2 pops in
const TYPE_2_START = 78; // +2.6s: bubble 2 text starts typing (ends ~3.6s later)
const BUBBLE_3_START = 108; // +3.6s hard cut: bubble 3 pops in
const TYPE_3_START = 114; // slight cascade delay before bubble 3 types
const BEAT_4_END = 144; // +4.8s: end of messages scene, hard cut to outro caption

const TEXT_1 = "you told me mom's bday is tomorrow";
const TEXT_2 = "flowers close at 6.";
const TEXT_3 = "order the usual place?";

// Frame at which bubble 3's text has finished typing — the LiveDot appears
// once it's fully typed, per the brief ("signaling this is live/acting now").
const TYPE_3_DONE = TYPE_3_START + Math.ceil(TEXT_3.length / CHARS_PER_FRAME);

// --- Beat 6 (NEW): a beat of black + one line spelling out the callback,
// right before the end-card.
const OUTRO_CAPTION_LEN = 30; // 1.0s: "That was 3 weeks ago."
const OUTRO_CAPTION_TEXT = "That was 3 weeks ago.";

// --- Absolute offsets (frames from the start of the whole composition).
const MESSAGES_FROM = BACKSTORY_LEN; // 102
const OUTRO_CAPTION_FROM = MESSAGES_FROM + BEAT_4_END; // 246
const STAMP_LEN = 105; // extended to fully cover the ElevenLabs VO track (361 frames / 12.0s)
const STAMP_FROM = OUTRO_CAPTION_FROM + OUTRO_CAPTION_LEN; // 276

export const day2DurationInFrames = STAMP_FROM + STAMP_LEN; // 306 frames = 10.2s @30fps
export const day2Fps = 30;
export const day2Width = 1080;
export const day2Height = 1920;

export const Day2Memory: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.black, fontFamily }}>
      <Audio src={staticFile("audio/day2.mp3")} />
      {/* Beats 0-1: backstory — two earlier, unrelated things the user told KAI */}
      <Sequence from={0} durationInFrames={OPEN_A_LEN}>
        <BackstoryBeat caption={CAPTION_A} text={TEXT_A} />
      </Sequence>
      <Sequence from={OPEN_A_LEN} durationInFrames={OPEN_B_LEN}>
        <BackstoryBeat caption={CAPTION_B} text={TEXT_B} />
      </Sequence>

      {/* Beats 2-5: lone caret, then the birthday chat thread growing downward */}
      <Sequence from={MESSAGES_FROM} durationInFrames={BEAT_4_END}>
        <MessagesScene />
      </Sequence>

      {/* Beat 6: hard cut to a one-line callback caption */}
      <Sequence from={OUTRO_CAPTION_FROM} durationInFrames={OUTRO_CAPTION_LEN}>
        <OutroCaption text={OUTRO_CAPTION_TEXT} />
      </Sequence>

      {/* Beat 7: hard cut to end-card */}
      <Sequence from={STAMP_FROM} durationInFrames={STAMP_LEN}>
        <KaiStamp startFrame={0} tagline="It remembers everything. So you don't have to." />
      </Sequence>
    </AbsoluteFill>
  );
};

// Beats 0-1 — a small timestamp-style caption fades in above a chat bubble
// that types out something small and unrelated to the birthday thread below
// — establishing "KAI remembers lots of small stuff" weeks before the
// payoff (marketing.md's "three weeks of tiny moments"). Uses the same
// ChatBubble + TypewriterLine as the payoff thread, same visual style, so
// it reads as one continuous chat history.
const BackstoryBeat: React.FC<{ caption: string; text: string }> = ({ caption, text }) => {
  const frame = useCurrentFrame();
  const captionOpacity = Math.min(1, frame / 10);

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        paddingLeft: 64,
        paddingRight: 64,
        gap: 16,
      }}
    >
      <div
        style={{
          fontFamily,
          fontWeight: 500,
          fontSize: 24,
          letterSpacing: 1.5,
          textTransform: "uppercase",
          color: kai.steel,
          opacity: captionOpacity,
        }}
      >
        {caption}
      </div>
      {frame >= BACKSTORY_BUBBLE_START && (
        <ChatBubble startFrame={BACKSTORY_BUBBLE_START}>
          <TypewriterLine
            text={text}
            startFrame={BACKSTORY_TYPE_START}
            charsPerFrame={BACKSTORY_CHARS_PER_FRAME}
            color={kai.ink}
            fontSize={36}
          />
        </ChatBubble>
      )}
    </AbsoluteFill>
  );
};

const MessagesScene: React.FC = () => {
  const frame = useCurrentFrame();

  if (frame < BEAT_1_END) {
    return (
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <BlinkingCaret />
      </AbsoluteFill>
    );
  }

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        paddingTop: 260,
        paddingLeft: 64,
        paddingRight: 64,
        gap: 28,
      }}
    >
      {frame >= BUBBLE_1_START && (
        <ChatBubble startFrame={BUBBLE_1_START}>
          <TypewriterLine
            text={TEXT_1}
            startFrame={BUBBLE_1_START}
            color={kai.ink}
            fontSize={36}
          />
        </ChatBubble>
      )}

      {frame >= BUBBLE_2_START && (
        <ChatBubble startFrame={BUBBLE_2_START}>
          <TypewriterLine
            text={TEXT_2}
            startFrame={TYPE_2_START}
            color={kai.ink}
            fontSize={36}
          />
        </ChatBubble>
      )}

      {frame >= BUBBLE_3_START && (
        <div style={{ position: "relative" }}>
          <ChatBubble startFrame={BUBBLE_3_START}>
            <TypewriterLine
              text={TEXT_3}
              startFrame={TYPE_3_START}
              color={kai.ink}
              fontSize={36}
            />
          </ChatBubble>
          {frame >= TYPE_3_DONE && (
            <div
              style={{
                position: "absolute",
                right: 8,
                top: "50%",
                transform: "translateY(-50%)",
              }}
            >
              <LiveDot size={18} />
            </div>
          )}
        </div>
      )}
    </AbsoluteFill>
  );
};

// Beat 1 — a single blinking caret alone on black, before any message exists.
const BlinkingCaret: React.FC = () => {
  const frame = useCurrentFrame();
  const on = Math.floor(frame / 8) % 2 === 0;
  return (
    <div
      style={{
        width: 6,
        height: 54,
        borderRadius: 2,
        background: kai.paper,
        opacity: on ? 1 : 0,
      }}
    />
  );
};

// Beat 6 — a single callback line on black, right before the end-card,
// spelling out that the birthday recall above drew on something said three
// weeks earlier.
const OutroCaption: React.FC<{ text: string }> = ({ text }) => {
  const frame = useCurrentFrame();
  const opacity = Math.min(1, frame / 12);
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div
        style={{
          fontFamily,
          fontWeight: 500,
          fontSize: 32,
          color: kai.silver,
          opacity,
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};
