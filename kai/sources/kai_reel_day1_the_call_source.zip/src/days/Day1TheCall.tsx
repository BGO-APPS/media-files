import React from "react";
import { AbsoluteFill, Audio, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { kai, fontFamily } from "../theme";
import { ScreenshotCard } from "../components/ScreenshotCard";
import { DoodleArrow } from "../components/DoodleArrow";
import { KaiStamp } from "../components/KaiStamp";

// Day 1 — "The Call" (hero post). Template: Screenshot-in-Card.
// Beat sheet source: agent-chat/03-seven-day-content-calendar.md, Day 1,
// extended per marketing.md §6 Ad 1 spec — "Quick cuts of Scenario A
// dialogue as on-screen kinetic text" — using the real Scenario A call
// script (marketing.md §5) so the middle of the ad isn't dead air.
// fps 30. Beat frames below map directly to the calendar's second-timings.
const BEAT_1_END = 30; // 0.0-1.0s: two-tier caption
const BEAT_2_END = 36; // 1.0-1.2s: card pops in
const BEAT_3_END = 105; // 1.2-3.5s: card holds, doodle arrow — card is gone after this
const BEAT_4_END = 147; // 3.5-4.9s: kinetic cut 1 — "Your exam's at 10."
const BEAT_5_END = 189; // 4.9-6.3s: kinetic cut 2 — "Hall B this time."
const BEAT_6_END = 237; // 6.3-7.9s: kinetic cut 3 — "Want me to block tonight for that assignment?"
const BEAT_7_END = 267; // 7.9-8.9s: payoff line "No other AI does this."
const BEAT_8_END = 360; // 8.9-12.0s: stamp — extended to fully cover the ElevenLabs VO track (330 frames / 11.0s)

export const day1DurationInFrames = BEAT_8_END;
export const day1Fps = 30;
export const day1Width = 1080;
export const day1Height = 1920;

const PopIn: React.FC<{ children: React.ReactNode; delay?: number }> = ({
  children,
  delay = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - delay);
  const pop = spring({ frame: local, fps, config: { damping: 12, mass: 0.6, stiffness: 200 } });
  return (
    <div style={{ transform: `scale(${0.85 + pop * 0.15})`, opacity: Math.min(1, local / 4) }}>
      {children}
    </div>
  );
};

// Same weight/size class + spring feel as the payoff line beat below, reused
// for the new kinetic-typography quick cuts so every hard-cut in this file
// reads as one consistent motion signature — not a bolted-on new style.
const KineticLine: React.FC<{ children: React.ReactNode; fontSize?: number }> = ({
  children,
  fontSize = 58,
}) => (
  <PopIn>
    <div
      style={{
        fontSize,
        fontWeight: 700,
        color: kai.ink,
        textAlign: "center",
        maxWidth: 860,
        lineHeight: 1.15,
      }}
    >
      {children}
    </div>
  </PopIn>
);

export const Day1TheCall: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.paper, fontFamily }}>
      <Audio src={staticFile("audio/day1.mp3")} />
      {/* Beats 1-3 + 7: caption + card share the frame, caption text swaps.
          Null in between (frames BEAT_3_END-BEAT_6_END) while the kinetic
          quick-cut sequences below own the screen. */}
      <Sequence from={0} durationInFrames={BEAT_7_END}>
        <AbsoluteFill
          style={{
            alignItems: "center",
            justifyContent: "flex-start",
            paddingTop: 180,
          }}
        >
          <BeatCaption />
        </AbsoluteFill>
      </Sequence>

      {/* Beat 2-3: the tilted card, scale-pops in and holds, then is gone —
          the kinetic dialogue cuts below get a clean Paper frame, no card
          bleeding through behind them. */}
      <Sequence from={BEAT_1_END} durationInFrames={BEAT_3_END - BEAT_1_END}>
        <AbsoluteFill>
          <ScreenshotCard startFrame={0} />
          <ArrowOverlay holdUntil={BEAT_3_END - BEAT_1_END} />
        </AbsoluteFill>
      </Sequence>

      {/* Beats 4-6: hard-cut kinetic-typography quick cuts of the real
          Scenario A call (marketing.md §5) — the ad-script beat the 5.5s
          cut skipped. Each is its own full Paper-bg screen, ink text only. */}
      <Sequence from={BEAT_3_END} durationInFrames={BEAT_4_END - BEAT_3_END}>
        <AbsoluteFill
          style={{
            background: kai.paper,
            alignItems: "center",
            justifyContent: "center",
            padding: "0 90px",
          }}
        >
          <KineticLine>Your exam&rsquo;s at 10.</KineticLine>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={BEAT_4_END} durationInFrames={BEAT_5_END - BEAT_4_END}>
        <AbsoluteFill
          style={{
            background: kai.paper,
            alignItems: "center",
            justifyContent: "center",
            padding: "0 90px",
          }}
        >
          <KineticLine>Hall B this time.</KineticLine>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={BEAT_5_END} durationInFrames={BEAT_6_END - BEAT_5_END}>
        <AbsoluteFill
          style={{
            background: kai.paper,
            alignItems: "center",
            justifyContent: "center",
            padding: "0 90px",
          }}
        >
          <KineticLine fontSize={46}>
            Want me to block tonight for that assignment?
          </KineticLine>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 8: stamp outro */}
      <Sequence from={BEAT_7_END} durationInFrames={BEAT_8_END - BEAT_7_END}>
        <KaiStamp startFrame={0} tagline="The AI that calls you." />
      </Sequence>
    </AbsoluteFill>
  );
};

const ArrowOverlay: React.FC<{ holdUntil: number }> = ({ holdUntil }) => {
  const frame = useCurrentFrame();
  if (frame < 20 || frame > holdUntil) return null;
  const progress = Math.min(1, (frame - 20) / 16);
  return (
    <div style={{ position: "absolute", left: "58%", top: "62%" }}>
      <DoodleArrow progress={progress} color={kai.ink} />
    </div>
  );
};

// Beat 1 caption (thin/bold two-tier) morphs into Beat 7 payoff line —
// per calendar: "Your phone never actually— / rings." then, after the
// card is gone and the kinetic dialogue cuts have run, "No other AI does
// this." Returns null across the card-hold gap and the kinetic-cut beats,
// which own the screen themselves.
const BeatCaption: React.FC = () => {
  const frame = useCurrentFrame();

  if (frame < BEAT_1_END) {
    return (
      <PopIn>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 34, fontWeight: 500, color: kai.steel }}>
            Your phone never actually—
          </div>
          <div style={{ fontSize: 64, fontWeight: 700, color: kai.ink, marginTop: 4 }}>
            rings.
          </div>
        </div>
      </PopIn>
    );
  }

  if (frame >= BEAT_2_END && frame < BEAT_3_END) {
    // caption stays visible above the card during the hold beat, per spec
    return (
      <div style={{ textAlign: "center", opacity: 0.9 }}>
        <div style={{ fontSize: 30, fontWeight: 500, color: kai.steel }}>
          Your phone never actually—
        </div>
        <div style={{ fontSize: 50, fontWeight: 700, color: kai.ink }}>rings.</div>
      </div>
    );
  }

  if (frame >= BEAT_6_END && frame < BEAT_7_END) {
    return (
      <PopIn delay={BEAT_6_END}>
        <div
          style={{
            fontSize: 58,
            fontWeight: 700,
            color: kai.ink,
            textAlign: "center",
            maxWidth: 800,
          }}
        >
          No other AI does this.
        </div>
      </PopIn>
    );
  }

  return null;
};
