# Remotion React Composition: Day 1: The Call

Built with Remotion React video engine. Install dependencies with `npm install` and run `npm start`.
