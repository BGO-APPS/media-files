import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { PhoneRingIcon } from "../components/Icons";
import { ScreenshotCard } from "../components/ScreenshotCard";
import { KaiStamp } from "../components/KaiStamp";

// Day 4 — "Hands Full" (utility ad). Template: Icon Cold-Open -> Screenshot-in-Card.
// Dramatizes marketing.md §5 Scenario C — Meera, cooking, hands covered in
// flour, runs her whole exchange with KAI by voice, hands never touch the
// phone. The exchange is the full two-request scenario verbatim (grocery add
// + plumber reminder), not the truncated single-request cut. fps 30. Beat
// frames below map to this file's own beat sheet (adapted from the ~15s
// "Hands Full" ad concept in marketing.md §6 Ad 4).
const BEAT_1_END = 18; // 0.0-0.6s: cold-open caption, deliberately incomplete
const BEAT_2_END = 54; // 0.6-1.8s: PhoneRingIcon scale-pops in below the caption
const BEAT_3_END = 78; // 1.8-2.6s: hard cut, payoff caption completes the sentence
const BEAT_4_END = 258; // 2.6-8.6s: hard cut, tilted card, full 4-bubble voice/chat mock
const BEAT_4B_END = 294; // 8.6-9.8s: card snaps away, reinforcing caption beat
const BEAT_5_END = 409; // 9.8-13.6s: hard cut, KaiStamp outro — extended to cover the ElevenLabs VO track (389 frames / 13.0s)

export const day4DurationInFrames = BEAT_5_END;
export const day4Fps = 30;
export const day4Width = 1080;
export const day4Height = 1920;

export const Day4HandsFull: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.paper, fontFamily }}>
      <Audio src={staticFile("audio/day4.mp3")} />
      {/* Beats 1-2: cold-open caption, then the listening icon pops in below it */}
      <Sequence from={0} durationInFrames={BEAT_2_END}>
        <AbsoluteFill
          style={{
            alignItems: "center",
            justifyContent: "flex-start",
            paddingTop: 220,
          }}
        >
          <WordPop>
            <div
              style={{
                fontSize: 34,
                fontWeight: 500,
                color: kai.steel,
                textAlign: "center",
              }}
            >
              here&rsquo;s the AI that—
            </div>
          </WordPop>
          <IconBeat />
        </AbsoluteFill>
      </Sequence>

      {/* Beat 3: hard cut to the payoff caption completing the sentence */}
      <Sequence from={BEAT_2_END} durationInFrames={BEAT_3_END - BEAT_2_END}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <WordPop from="none">
            <div
              style={{
                fontSize: 58,
                fontWeight: 700,
                color: kai.ink,
                textAlign: "center",
                maxWidth: 820,
              }}
            >
              —actually listens back.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4: proof beat — tilted card, custom voice/chat mock (Scenario C) */}
      <Sequence from={BEAT_3_END} durationInFrames={BEAT_4_END - BEAT_3_END}>
        <AbsoluteFill>
          <ScreenshotCard startFrame={0} tiltDeg={-3.5} mock={<MockChatScreen />} />
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4b: card snaps away, quick reinforcing caption before the stamp */}
      <Sequence from={BEAT_4_END} durationInFrames={BEAT_4B_END - BEAT_4_END}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <WordPop from="none">
            <div
              style={{
                fontSize: 46,
                fontWeight: 700,
                color: kai.ink,
                textAlign: "center",
                maxWidth: 760,
              }}
            >
              Hands still covered in flour.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 5: hard cut to stamp outro */}
      <Sequence from={BEAT_4B_END} durationInFrames={BEAT_5_END - BEAT_4B_END}>
        <KaiStamp startFrame={0} tagline="Zero typing. Your day, handled." />
      </Sequence>
    </AbsoluteFill>
  );
};

// The icon mounts partway through the cold-open sequence (local frame
// BEAT_1_END), scale-pops in large via WordPop, then rides its own
// self-animation (ring wiggle + faint sound-wave lines) — reads as "KAI is
// listening," not "KAI is ringing."
const IconBeat: React.FC = () => {
  const frame = useCurrentFrame();
  if (frame < BEAT_1_END) return null;
  return (
    <div style={{ marginTop: 64 }}>
      <WordPop delay={BEAT_1_END} from="bottom">
        <PhoneRingIcon color={kai.ink} size={220} />
      </WordPop>
    </div>
  );
};

// Custom mock passed into ScreenshotCard's `mock` prop — a self-contained
// voice/chat conversation screen (not the project's ChatBubble component),
// styled black background with white/card-colored bubbles per marketing.md
// §2 palette rules. Dramatizes Scenario C's full exchange verbatim: two
// requests from Meera (groceries, then the plumber reminder) and KAI's two
// replies (a short ack, then the full confirmation), not a single truncated
// round-trip.
const MockChatScreen: React.FC = () => {
  const frame = useCurrentFrame();
  const bubble1 = Math.min(1, Math.max(0, (frame - 14) / 10));
  const bubble2 = Math.min(1, Math.max(0, (frame - 40) / 10));
  const bubble3 = Math.min(1, Math.max(0, (frame - 78) / 10));
  const bubble4 = Math.min(1, Math.max(0, (frame - 110) / 10));

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        background: kai.black,
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-end",
        gap: 16,
        padding: "0 24px 56px",
      }}
    >
      {/* Meera's first spoken line — the grocery add */}
      <div
        style={{
          alignSelf: "flex-end",
          maxWidth: "82%",
          background: kai.steel,
          color: kai.black,
          borderRadius: 20,
          borderBottomRightRadius: 6,
          padding: "14px 18px",
          fontFamily,
          fontSize: 20,
          fontWeight: 500,
          lineHeight: 1.3,
          opacity: bubble1,
          transform: `translateY(${(1 - bubble1) * 16}px)`,
        }}
      >
        add paneer + curd to the list
      </div>
      {/* KAI's short ack */}
      <div
        style={{
          alignSelf: "flex-start",
          maxWidth: "82%",
          background: kai.card,
          color: kai.black,
          borderRadius: 20,
          borderBottomLeftRadius: 6,
          padding: "14px 18px",
          fontFamily,
          fontSize: 20,
          fontWeight: 600,
          lineHeight: 1.3,
          opacity: bubble2,
          transform: `translateY(${(1 - bubble2) * 16}px)`,
        }}
      >
        Got it, added.
      </div>
      {/* Meera's second spoken line — the plumber reminder, same style as her first */}
      <div
        style={{
          alignSelf: "flex-end",
          maxWidth: "82%",
          background: kai.steel,
          color: kai.black,
          borderRadius: 20,
          borderBottomRightRadius: 6,
          padding: "14px 18px",
          fontFamily,
          fontSize: 20,
          fontWeight: 500,
          lineHeight: 1.3,
          opacity: bubble3,
          transform: `translateY(${(1 - bubble3) * 16}px)`,
        }}
      >
        and remind me to call the plumber tomorrow morning
      </div>
      {/* KAI's full reply, verbatim from marketing.md Scenario C */}
      <div
        style={{
          alignSelf: "flex-start",
          maxWidth: "82%",
          background: kai.card,
          color: kai.black,
          borderRadius: 20,
          borderBottomLeftRadius: 6,
          padding: "14px 18px",
          fontFamily,
          fontSize: 20,
          fontWeight: 600,
          lineHeight: 1.3,
          opacity: bubble4,
          transform: `translateY(${(1 - bubble4) * 16}px)`,
        }}
      >
        List updated. I&rsquo;ll call you at 9 about the plumber.
      </div>
    </div>
  );
};
