# Remotion React Composition: Day 7: Meeting Intervention

Built with Remotion React video engine. Install dependencies with `npm install` and run `npm start`.
