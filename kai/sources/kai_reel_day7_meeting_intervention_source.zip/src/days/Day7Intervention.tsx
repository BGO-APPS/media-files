import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { HardWipe, wipeCoverAmount } from "../components/HardWipe";
import { TypewriterLine } from "../components/TypewriterLine";
import { ChatBubble } from "../components/ChatBubble";
import { LiveDot } from "../components/LiveDot";
import { DoodleUnderline } from "../components/DoodleUnderline";
import { KaiStamp } from "../components/KaiStamp";

// Day 7 — "The Intervention" (viral/shareable closer of the week). Template:
// Typewriter Cursor Reveal -> Hard-Wipe Scene Transition.
// Source: marketing.md §5 Scenario E ("The Public Flex") / §6 Ad 5
// ("The Intervention" — viral/funny, "made to be shared"). This is
// explicitly the highest-energy, most playful video of the week.
// fps 30, 1080x1920.
//
// Full bit per marketing.md: friends at a café, a phone rings (screen says
// KAI), a friend asks "who's KAI?", they answer on speaker, KAI delivers the
// callout, and "Everyone loses it." Both the question and the aftermath
// reaction are real beats from the ad script — both now play out below,
// bookended by the same paper bg the cold open uses.
//
// Beat frames (approx. seconds in comments):
const BEAT1_LINE2_DELAY = 14; // "a phone rings." pops in
const BEAT1_LINE3_DELAY = 42; // "friend: who's KAI?" pops in, its own beat
const BEAT1_END = 102; // 0.0-3.4s: Scene A — café setup + "who's KAI?", paper bg
const WIPE_START = BEAT1_END; // 3.4s: hard wipe begins covering Scene A
const WIPE_COVER_FRAMES = 10; // circle grows 0->1 over these frames
const WIPE_HOLD_FRAMES = 4; // frame fully covered — safe to swap scenes
const WIPE_RECEDE_FRAMES = 10; // circle shrinks 1->0, revealing Scene B
const WIPE_FULL_COVER = WIPE_START + WIPE_COVER_FRAMES; // 112: Scene A safe to unmount
const WIPE_END = WIPE_START + WIPE_COVER_FRAMES + WIPE_HOLD_FRAMES + WIPE_RECEDE_FRAMES; // 126 (~4.2s)

const LINE1_START = WIPE_END; // 126 (~4.2s): Scene B revealed, KAI's first line types
const LINE1_CUT = LINE1_START + 24; // 150 (~5.0s): hard cut to line two
const BEAT3_END = LINE1_CUT + 18; // 168 (~5.6s): end of the two-line typewriter beat
const BEAT4_END = BEAT3_END + 24; // 192 (~6.4s): end of the "closing time?" callout

const AFTERMATH_START = BEAT4_END; // 192 (~6.4s): hard cut back to paper bg, bookending Scene A
const AFTERMATH_END = AFTERMATH_START + 96; // 288 (~9.6s): reaction beat + half-beat hold, ends
const BEAT5_END = AFTERMATH_END + 72; // 360 (12.0s): end of KaiStamp outro — extended to cover the ElevenLabs VO track (300 frames / 10.0s)

export const day7DurationInFrames = BEAT5_END;
export const day7Fps = 30;
export const day7Width = 1080;
export const day7Height = 1920;

export const Day7Intervention: React.FC = () => {
  const frame = useCurrentFrame();

  const wipeLocal = frame - WIPE_START;
  const coverAmount =
    frame >= WIPE_START && frame < WIPE_END
      ? wipeCoverAmount(wipeLocal, WIPE_COVER_FRAMES, WIPE_HOLD_FRAMES, WIPE_RECEDE_FRAMES)
      : 0;

  return (
    <AbsoluteFill style={{ fontFamily, background: kai.black }}>
      <Audio src={staticFile("audio/day7.mp3")} />
      {/* Scene B (black bg — the café-table call) is mounted UNDERNEATH the wipe
          starting at WIPE_START, for the whole cover-hold-recede window. Its own
          content is keyed off absolute frame numbers (LINE1_START etc.), so it
          renders blank/black until its cue arrives — nothing pops early even
          though the layer itself is already mounted and waiting. */}
      {frame >= WIPE_START && frame < BEAT4_END && (
        <AbsoluteFill style={{ background: kai.black }}>
          <SceneB frame={frame} />
        </AbsoluteFill>
      )}

      {/* Scene A (paper bg — the café setup) is layered ON TOP of Scene B (later
          in JSX = higher stacking), so it stays visible while the circle grows
          across it. It unmounts the instant the circle finishes covering the
          frame (frame >= WIPE_FULL_COVER, coverAmount hits 1) — invisible, since
          the overlay is a solid opaque black at that exact moment. */}
      {frame < WIPE_FULL_COVER && (
        <AbsoluteFill style={{ background: kai.paper }}>
          <SceneA />
        </AbsoluteFill>
      )}

      {/* The wipe itself — always the topmost layer while active. */}
      {coverAmount > 0 && <HardWipe coverAmount={coverAmount} color={kai.black} />}

      {/* Beat 6 — hard cut back to paper bg for the aftermath reaction, the
          moment the ad script calls "Everyone loses it." Bookends Scene A's
          look before the outro stamp. */}
      {frame >= AFTERMATH_START && frame < AFTERMATH_END && (
        <AbsoluteFill style={{ background: kai.paper }}>
          <Aftermath frame={frame} />
        </AbsoluteFill>
      )}

      {/* Beat 7 — hard cut to the end stamp. */}
      <Sequence from={AFTERMATH_END} durationInFrames={BEAT5_END - AFTERMATH_END}>
        <KaiStamp startFrame={0} tagline="My AI called me out. 💀" />
      </Sequence>
    </AbsoluteFill>
  );
};

// Beat 1 — deliberately plain/low-key setup, to contrast with the payoff.
// Three staggered captions: the scene, the inciting incident, and the
// audience-surrogate question ("who's KAI?") that the payoff answers.
const SceneA: React.FC = () => (
  <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 80 }}>
    <div style={{ textAlign: "center" }}>
      <WordPop>
        <div style={{ fontSize: 54, fontWeight: 700, color: kai.ink, letterSpacing: -1 }}>
          friends at a café.
        </div>
      </WordPop>
      <WordPop delay={BEAT1_LINE2_DELAY}>
        <div
          style={{
            fontSize: 54,
            fontWeight: 700,
            color: kai.ink,
            letterSpacing: -1,
            marginTop: 18,
          }}
        >
          a phone rings.
        </div>
      </WordPop>
      <WordPop delay={BEAT1_LINE3_DELAY}>
        <div
          style={{
            fontSize: 54,
            fontWeight: 700,
            color: kai.ink,
            letterSpacing: -1,
            marginTop: 18,
          }}
        >
          friend: “who’s KAI?”
        </div>
      </WordPop>
    </div>
  </AbsoluteFill>
);

// Beat 3-4 — the payoff, on black. KAI's line types out in two hard-cut
// chunks, then the callout lands with the one green accent of the whole reel.
const SceneB: React.FC<{ frame: number }> = ({ frame }) => (
  <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: "0 72px" }}>
    {frame >= LINE1_START && frame < LINE1_CUT && (
      <ChatBubble startFrame={LINE1_START}>
        <TypewriterLine
          text="you said no online shopping till salary day."
          startFrame={LINE1_START}
          charsPerFrame={1.8}
          fontSize={34}
          weight={700}
          color={kai.ink}
        />
      </ChatBubble>
    )}

    {frame >= LINE1_CUT && frame < BEAT3_END && (
      <ChatBubble startFrame={LINE1_CUT}>
        <TypewriterLine
          text="you just opened the app."
          startFrame={LINE1_CUT}
          charsPerFrame={1.4}
          fontSize={34}
          weight={700}
          color={kai.ink}
        />
      </ChatBubble>
    )}

    {frame >= BEAT3_END && frame < BEAT4_END && (
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <WordPop delay={BEAT3_END} from="none">
          <div style={{ fontSize: 62, fontWeight: 700, color: kai.paper, letterSpacing: -1 }}>
            closing time?
          </div>
        </WordPop>
        <LiveDot size={20} />
      </div>
    )}
  </AbsoluteFill>
);

// Beat 6 — the aftermath reaction, bookending Scene A's paper look. Big
// pop-in caption plus a self-drawing doodle underline to keep the hold
// itself in motion (per the week's "more motion graphics" rule) — settles
// well before AFTERMATH_END, leaving a deliberate half-beat static hold
// before the hard cut into the KaiStamp outro.
const Aftermath: React.FC<{ frame: number }> = ({ frame }) => {
  const local = Math.max(0, frame - AFTERMATH_START);
  const underlineProgress = Math.min(1, Math.max(0, (local - 20) / 24));
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 80 }}>
      <div style={{ textAlign: "center" }}>
        <WordPop>
          <div style={{ fontSize: 72, fontWeight: 700, color: kai.ink, letterSpacing: -1 }}>
            Everyone loses it. 💀
          </div>
        </WordPop>
        <div style={{ display: "flex", justifyContent: "center", marginTop: 22 }}>
          <DoodleUnderline progress={underlineProgress} color={kai.ink} width={220} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
