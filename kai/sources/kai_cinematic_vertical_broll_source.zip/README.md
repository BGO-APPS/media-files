# Creative Prompt & Synthesis Pipeline: Cinematic Vertical B-Roll

## Generation Prompt
```
Clean vertical 9:16 cinematic product b-roll showing paper-and-ink minimal interface with green accents.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
