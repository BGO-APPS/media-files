# KAI Android Intro Splash — App Architecture Source

Android Jetpack Compose startup layout, permission declaration, and interactive onboarding scaffold.
