# KAI — Play Store Listing Copy

Written against `marketing.md` (primary USP: "The AI that calls you"; voice:
short, confident, second person, present tense; aesthetic: restraint).

---

## Short description
*Play Store limit: 80 characters.*

```
The AI that calls you. Remembers everything. Runs your day.
```
**59 / 80 characters.**

### Alternates
```
The AI that calls you — and remembers every word you say.        (56)
Not a chatbot. A personal AI that rings your phone and acts.     (60)
Your AI calls you, remembers you, and runs your day.             (51)
```

---

## Full description
*Play Store limit: 4000 characters. This is ~1,900 — deliberately short. Nobody
reads a wall of text on a store page.*

```
Your phone rings.
The screen says KAI.
Answer it.

That's the part people don't believe until it happens.

KAI is a personal AI that doesn't sit around waiting to be opened. It calls you, talks like a person, remembers you, and quietly runs your day in the background.


IT CALLS YOU

A real incoming call, on your real lock screen. Pick up and talk — no typing, no prompts, no app to open. KAI rings when something actually matters: a deadline creeping up, a birthday you mentioned once, a promise you made to yourself at 2am.


IT REMEMBERS YOU. FOREVER.

Tell it once. That's it. Your gym days, your deadlines, your sister's birthday, how you like your mornings. Every conversation — typed or spoken — feeds one memory that never resets. No "new chat". No starting over. No explaining yourself twice.


IT ACTS FIRST

You shouldn't have to remember to check your reminders. KAI nudges you before you forget, then follows up when you don't. That's the difference between a tool you use and an assistant who's got you.


TALK INSTEAD OF TYPING

Hold the button and speak. Cooking, driving, walking, hands covered in flour — KAI keeps up, answers back, and handles it.


YOUR WHOLE DAY, IN ONE PLACE

"Remind me to pay rent on the 1st."
"Put gym every Monday at 7."
"What's on tomorrow?"

Reminders, calendar, and a morning brief that tells you what today actually looks like. One app instead of four.


BUILT TO BE QUIET

No neon. No glow. No sci-fi costume. Black ink on warm paper — fast, calm, and built like it respects your attention.


Stop opening apps. Start answering them.

KAI. The AI that lives with you.
```

---

## Notes before you publish

**On naming competitors.** `marketing.md` lists "ChatGPT waits. KAI comes to
you." as an approved tagline, and it is a genuinely strong line — but I left it
out of the store listing on purpose. Google Play's metadata policy discourages
referencing other apps and brands in your listing, and it is an easy,
avoidable flag on review. Keep that line for ads, TikTok and the landing page,
where it does its best work anyway. "Stop opening apps. Start answering them."
carries the same idea here without naming anyone.

**Claims to keep honest.** The copy above only promises what the build actually
does: incoming AI calls, push-to-talk voice, persistent cross-session memory,
reminders, calendar, morning brief. It deliberately avoids "no other app does
this" — a superlative that is hard to defend and easy to challenge.

**The first three lines are the whole game.** Play truncates the description
behind a "more" tap on mobile, so `Your phone rings. / The screen says KAI. /
Answer it.` is what most people will ever read. That is why the hook is three
short lines and not a paragraph.

**Pair it with the right screenshot.** The first screenshot should be the black
incoming-call screen, not the chat. The call is the scroll-stopper; leading
with a chat UI makes KAI look like every other assistant.

---

## P3 — Store Listing Experiments (Play Console Guide)

### Setup in Google Play Console
1. Navigate to **Google Play Console** -> Select **KAI AI** (`com.gokul00060.gnxmobile`).
2. Go to **Grow** -> **Store presence** -> **Store listing experiments**.
3. Click **Create experiment**:
   - Experiment type: **Default graphics and text** (tests icon, short description, and screenshots).
   - Variants: Up to 3 variants against Control.
   - Traffic split: 50/50 (for 1 variant) or 25/25/25/25 (for 3 variants).
4. **Test Assets**:
   - **Variant A (Call-First Hook)**:
     - Title: `KAI — The AI That Calls You`
     - Short description: `The AI that calls you. Remembers everything. Runs your day.`
     - Leading screenshot: Incoming Black Call Screen.
   - **Variant B (Memory & Execution Hook)**:
     - Short description: `Not a chatbot. A personal AI that rings your phone and acts.`
   - **Variant C (Personal Companion Hook)**:
     - Short description: `Your AI calls you, remembers you, and runs your day.`
5. **Sample Size & Duration**:
   - Accept Console's minimum sample size calculation.
   - Allow experiment to run until 90%+ confidence interval is achieved.
   - Apply winning variant directly in Console.
