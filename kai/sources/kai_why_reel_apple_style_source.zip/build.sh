#!/usr/bin/env bash
# Rebuild the "Why KAI" reel.
#   ./build.sh            cues → score → mix → check → render
#   ./build.sh sound      cues + score + mix only (assets/audio/master.wav)
#   ./build.sh media      re-stage clips/stills/fonts from the raw recordings
#   ./build.sh video      check + render only
#   ./build.sh vo [voice] regenerate narrator takes (Deepgram, costs credits) + word timings,
#                         e.g. ./build.sh vo aura-2-orion-en — then run ./build.sh
# Timing lives in build/cues.py only; index.html reads it via assets/cues.js.
set -euo pipefail
cd "$(dirname "$0")"
step=${1:-all}
PY=${PY:-/opt/miniconda3/bin/python3}   # needs numpy + scipy

if [[ $step == vo ]]; then
  "$PY" vo/make_vo.py "${2:-aura-2-thalia-en}"
  "$PY" vo/words.py "${2:-aura-2-thalia-en}"
  echo "new takes written — set VOICE in build/cues.py if you switched voice, then ./build.sh"
  exit 0
fi
if [[ $step == sound || $step == all ]]; then
  "$PY" build/cues.py
  "$PY" music/score.py
  "$PY" build/mix.py
fi
if [[ $step == media ]]; then
  "$PY" build/prep_media.py
fi
if [[ $step == video || $step == all ]]; then
  npx hyperframes check
  npx hyperframes render -o renders/_picture.mp4 --fps 30 --quality delivery
  # the renderer's audio pass lands ~4 dB quiet; mux the mastered track instead
  # (-0.6 dB keeps AAC true-peak under -1 dBTP)
  ffmpeg -hide_banner -v error -y -i renders/_picture.mp4 -i assets/audio/master.wav -map 0:v -map 1:a \
    -c:v copy -af volume=-0.6dB -c:a aac -b:a 320k -ar 48000 -movflags +faststart -t 45.396 renders/KAI_Why_Reel.mp4
  rm -f renders/_picture.mp4
fi
