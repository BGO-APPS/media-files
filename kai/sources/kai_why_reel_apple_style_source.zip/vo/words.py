"""Word timestamps for every take (Deepgram nova-3) -> vo/takes/<voice>/words.json.
Also prints each take's speech start/end so lines can be placed on the beat grid."""
import json, sys, pathlib, urllib.request
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from make_vo import api_key, VOICE
d = pathlib.Path(__file__).parent / "takes" / VOICE
out = {}
for wav in sorted(d.glob("*.wav")):
    req = urllib.request.Request("https://api.deepgram.com/v1/listen?model=nova-3&smart_format=true",
        data=wav.read_bytes(), method="POST",
        headers={"Authorization": f"Token {api_key()}", "Content-Type": "audio/wav"})
    r = json.load(urllib.request.urlopen(req))
    words = r["results"]["channels"][0]["alternatives"][0]["words"]
    out[wav.stem] = [{"w": w["punctuated_word"], "s": round(w["start"], 3), "e": round(w["end"], 3)} for w in words]
    print(f"{wav.stem:12s}", " ".join(f'{w["punctuated_word"]}@{w["start"]:.2f}' for w in words))
json.dump(out, open(d / "words.json", "w"), indent=1)
