"""Narrator takes for the KAI "Why KAI" reel — Deepgram Aura-2, one file per line.

Usage:  python3 vo/make_vo.py [voice]        (default aura-2-thalia-en)
Key:    DEEPGRAM_API_KEY env var, or KAI-Why-Reel/.env  (DEEPGRAM_API_KEY=...)

"Kai" is spelled that way on purpose so the TTS says it as one word, not K-A-I.
"""
import os, sys, json, subprocess, urllib.request, pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
VOICE = sys.argv[1] if len(sys.argv) > 1 else "aura-2-thalia-en"

LINES = {
    "v1_wait":     "Every other AI... waits for you.",
    "v2_doesnt":   "Kai doesn't.",
    "v3_calls":    "It calls you.",
    "v4_remember": "It remembers what you tell it.",
    "v5_first":    "It speaks up... before you forget.",
    "v6_does":     "Kai opens the app... and does it for you.",
    "v7_oneai":    "One AI. For your whole day.",
    "v8_acts":     "Other AIs answer. Kai gets it done.",
    "v9_lives":    "Kai... the AI that lives with you.",
    "v10_cta":     "Download the app now... link in bio.",
}


def api_key():
    if os.environ.get("DEEPGRAM_API_KEY"):
        return os.environ["DEEPGRAM_API_KEY"]
    for line in (ROOT / ".env").read_text().splitlines():
        if line.startswith("DEEPGRAM_API_KEY="):
            return line.split("=", 1)[1].strip()
    raise SystemExit("no DEEPGRAM_API_KEY")


def main():
    key = api_key()
    out = HERE / "takes" / VOICE
    out.mkdir(parents=True, exist_ok=True)
    for name, text in LINES.items():
        req = urllib.request.Request(
            f"https://api.deepgram.com/v1/speak?model={VOICE}"
            "&encoding=linear16&sample_rate=48000&container=wav",
            data=text.encode(), method="POST",
            headers={"Authorization": f"Token {key}", "Content-Type": "text/plain"})
        wav = out / f"{name}.wav"
        wav.write_bytes(urllib.request.urlopen(req).read())
        d = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "csv=p=0", str(wav)], capture_output=True, text=True).stdout.strip()
        print(f"{name:12s} {d}s  {text}")
    json.dump(LINES, open(out / "lines.json", "w"), indent=1)


if __name__ == "__main__":
    main()
