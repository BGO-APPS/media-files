"""Try alternate wordings for a line; print what the STT hears back. Usage: trial.py name "text" ["text"...]"""
import sys, json, pathlib, urllib.request
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from make_vo import api_key
VOICE = "aura-2-thalia-en"
name, texts = sys.argv[1], sys.argv[2:]
for i, t in enumerate(texts):
    req = urllib.request.Request(f"https://api.deepgram.com/v1/speak?model={VOICE}&encoding=linear16&sample_rate=48000&container=wav",
        data=t.encode(), method="POST", headers={"Authorization": f"Token {api_key()}", "Content-Type": "text/plain"})
    wav = pathlib.Path(__file__).parent / "trials" / f"{name}_{i}.wav"
    wav.write_bytes(urllib.request.urlopen(req).read())
    req = urllib.request.Request("https://api.deepgram.com/v1/listen?model=nova-3&smart_format=true",
        data=wav.read_bytes(), method="POST", headers={"Authorization": f"Token {api_key()}", "Content-Type": "audio/wav"})
    words = json.load(urllib.request.urlopen(req))["results"]["channels"][0]["alternatives"][0]["words"]
    print(f"{name}_{i}: {t!r:48s} -> " + " ".join(f'{w["punctuated_word"]}@{w["start"]:.2f}' for w in words), f'| end {words[-1]["end"]:.2f}')
