---
workflow: general-video
flow: automation
storyboard: no
message: "Every other AI waits for you. KAI comes to you, then gets it done."
destination: reels
aspect: 1080x1920
language: en
audience: 18-35 tech-forward people who already use ChatGPT/Gemini and want an AI that *does*
length: 45s (hard window 30-55s)
angle: "Why KAI" — Apple-style launch reel, reasons as chapters, beat-synced
---

## Intent

A brand-new "WHY KAI" reel, built from scratch (owner's order: do not open or reuse any
previous video's scripts — KAI-Launch-Trailer / KAI-Intro-Film are off-limits).
It should feel like an Apple product-launch film: restraint, huge tight type, hero device
shots, macro zoom-ins on the UI, phones cropped past the frame edge, clean masked
transitions, every cut on the beat. Its job is to convince the viewer to install KAI.

Owner's words: "APPLE LAUCH DEMO VIDEO", "convince the user to use the KAI AI APP",
"it should sync and i need motion graphics and transition edits everything",
"keep all the mobile frame zoom in and cropped out also", "30-55sec budget reels format".

## Assets

- `../raw_livetalk_uber.mp4`, `../raw_livetalk_doordash.mp4` — Live voice screen recordings (1080x2340, silent)
- `../raw_copilot_uber.mp4`, `../raw_copilot_whats.mp4` — KAI operating Uber / WhatsApp (silent)
- `../video_backups/raw_doordash_demo_2026-09-27.mp4`, `raw_zepto_demo_…`, `footage/whatsapp_demo.mov` — KAI operating DoorDash / Zepto / WhatsApp
- `~/Documents/marketing/Kai_rebirth/app_screenshorts/native_device/*.png` — native screenshots: incoming call (08), memory (07), mom's-birthday proactive chat (00), reminders, calendar
- `~/Documents/music research/original/NUEVAYoL - Bad Bunny (N H Remake).flp` — music REFERENCE (drum rhythm grid + arrangement only)

## Customizations

- **Score:** composed from scratch in `music/`. 118 BPM, A minor, dembow/perreo in the NUEVAYoL lane:
  salsa-piano cold open, then the drop. Drum *rhythms* are taken from the reference FLP's
  kick/snare/cowbell/percussion/shaker grids (rhythm isn't protected). Every drum and bass
  sound is synthesized in numpy, piano is rendered through a SoundFont. The hook, bassline and
  chords are new. Rule from `music research/00_START_HERE_FOR_AI.md`: 90% same vibe is fine,
  copying the melody is not. So no D#6 ostinato, no A–E–A–C 808 line, no F#/C# blasted 808,
  no samples or stems.
- **Voice-over:** Deepgram Aura-2 (`aura-2-thalia-en`), one file per line, placed on the beat grid.
- **Sync:** one timing source (`cues.json`) drives the music, the VO placement and the GSAP timeline.
- **Mix:** a single pre-mastered track (`assets/audio/master.wav`). Music is side-chain ducked under the VO inside the mix.

## Notes

- Brand: ink & paper monochrome (#050505 / #0E0E10 / #F6F6F4), live-green #30D158 as the ONLY accent,
  red #FF453A only for the decline button on the call screen. No neon, glow, gradients or sci-fi.
- Font: Inter Tight (OFL, SF-like) embedded via @font-face + JetBrains Mono for small labels.
  SF Pro is avoided because of Apple's licence.
- Never say "GNX". Never claim a price or a platform that isn't true — the CTA is "Get KAI."
