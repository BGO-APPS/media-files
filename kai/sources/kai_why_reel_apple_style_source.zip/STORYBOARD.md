---
message: "Every other AI waits for you. KAI comes to you, then gets it done."
audience: 18-35 tech-forward people who already use ChatGPT/Gemini
mode: autonomous
canvas: 1080x1920 @30fps
duration: 45.4s (88 beats @118 BPM + tail)
rhythm: hook-SLAM-hold-hold-BREAK-rapid×4-STAB-reveal-STOP/SLAM-LOGO
---

All times are beats (b) on the 118 BPM grid, from `build/cues.py`. Monolithic `index.html`,
one GSAP timeline. Registry searched: `device-frame-stage` / `grain-overlay` exist, but the reel needs
~12 phone instances with nested zoom wrappers around live video, so the phone frame and grain are
hand-built.

## Frame 1 — intro "They wait" (b0–b8)
status: built · src: index.html#s1a,#s1b
rules: kinetic-beat-slam, waterfall-entry · transition out: overexposure flash (b8)
Ink canvas. An empty "Ask anything" field with a cursor blinking on every beat. VO words build
"Every other AI" → "waits." (slam) → "for you.". b6 hard cut to black: "KAI" snaps in on the word,
"doesn't." slides under it. Stop-time in the music.

## Frame 2 — "It calls you." (b8–b16)
status: built · src: index.html#s2
rules: spring-pop-entrance, coordinate-target-zoom, press-release-spring · transition out: zoom-through (b16)
DROP. The incoming-call phone slams up from below, oversized and cropped at the bottom edge,
rattling on the buzz (b8, b12), ring rings pulsing from the avatar. b12 camera pushes into
"Urgent: Client pitch deck review in 20 mins"; b14 pans to Accept; b15 press + ripple.

## Frame 3 — "It remembers." (b16–b24)
status: built · src: index.html#s3
rules: spring-pop-entrance, coordinate-target-zoom · transition out: vertical push (b24)
Paper canvas, phone bleeding off the right edge. Memory chat bubbles pop on beats; b20 camera
zooms into "You casually told me 3 weeks ago… I never forget." + "Remembered · 3 weeks later" chip.

## Frame 4 — "It speaks up… before you forget." (b24–b32)
status: built · src: index.html#s4
rules: spring-pop-entrance, multi-phase-camera · transition out: blur-through (b32)
Mirror layout (phone bleeds left). KAI's unprompted heads-up about mom's birthday pops (b25),
user reply (b27), "Done. Flowers scheduled…" (b29). "Unprompted" chip.

## Frame 5 — "Just say it." (b32–b42)
status: built · src: index.html#s5
rules: multi-phase-camera, coordinate-target-zoom · transition out: horizontal push/whip (b42)
Break. The real Live screen plays in sync with the real recorded command. Camera eases in on the
transcript. b40 re-drop on "Right away" — flash + punch-in.

## Frame 6 — montage "It does it" (b42–b58)
status: built · src: index.html#s6
rules: kinetic-beat-slam, coordinate-target-zoom, nudge-curve · transitions: whip push on b46/b50/b54
Uber → DoorDash → WhatsApp → Zepto, one per bar. Each phone is oversized/cropped, its in-screen
cuts land on beats (A/B/C), and the camera zooms onto the result at C with a factual result chip.

## Frame 7 — "4 apps. 0 taps." (b58–b60)
status: built · src: index.html#s6g
rules: spring-pop-entrance, kinetic-beat-slam · transition out: circle iris (b60)
Stop-time stab. Four result phones drop in a row; "4 apps." (b58) / "0 taps." (b59).

## Frame 8 — "One AI. For your whole day." (b60–b68)
status: built · src: index.html#s7
rules: multi-phase-camera, 3d-camera-flight (tilted strip) · transition out: push slide (b68)
Paper. A tilted strip of six KAI screens, cropped on both sides, starts zoomed on one phone and
pulls back to reveal all of them, then drifts. Capability labels tick in.

## Frame 9 — "Other AIs answer. KAI gets it done." (b68–b76)
status: built · src: index.html#s8
rules: theme-crossfade-morph, kinetic-beat-slam · transition out: hard cut (b76)
Paper, a grey typing bubble that just… types. "Kai" lands alone in the silence; b72 the frame
flips to ink and "gets it done." slams with four result ticks.

## Frame 10 — logo + CTA (b76–b88)
status: built · src: index.html#s9
rules: spring-pop-entrance, press-release-spring · final fade allowed
Black. "KAI" wordmark slams on the spoken "Kai", live-green dot pings, tagline builds word by word,
"Get KAI" pill pops (b80) and is pressed (b82). Final hit b84, fade out.
