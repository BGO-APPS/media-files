# KAI Zepto Grocery Demo — Automation Source Code

Autonomous cart checkout and screen capture directives for Zepto instant delivery.
