# KAI — Live Talk + Copilot Hardening Plan

**Goal:** stop the fix-one-break-another loop and get Live Talk + KAI Copilot to industry-standard reliability.

**Reference:** `Extracted_App/` — decompiled `com.agiinc.androidagent` v2.5.0 (minSdk 33 / targetSdk 36), a shipping Android AI agent. Everything attributed to "the reference app" below was read out of its manifest, resources, and dex strings, not assumed.

---

## 0. TL;DR

1. **KAI has no UI path to enable its own accessibility service — at all.** `A11yBridge.isEnabledInSettings()` is written but **never called**, and nothing in the app ever opens `ACTION_ACCESSIBILITY_SETTINGS`. Users must independently discover Android Settings → Accessibility → Installed apps → KAI → toggle. Most never will. Copilot then dies at preflight with *"try again in a moment"* — which is a lie, because waiting never helps. **This is likely the single biggest reason Copilot "doesn't work."**
2. **Your two screenshot failures have one cause and a one-block fix.** KAI's manifest is missing a `<queries>` declaration, so on Android 11+ `openApp()` is blind to every other app on the phone. "Open Play Store" and "open Free Fire" could never have worked.
3. **The regression loop is structural, not a discipline problem.** Copilot targets UI by *pixel coordinates guessed by a vision model*. Guesses aren't reproducible, so no fix can be locked in by a test, so every prompt tweak silently trades one app's reliability for another's. That is the loop. It cannot be disciplined away — the substrate has to change.
4. **The fix is the reference app's substrate:** target UI by *accessibility node* (resource-id / text / content-description), not coordinates. Keep vision as a fallback, not the primary.
5. **Simple commands shouldn't touch the vision loop at all.** The reference app routes "open YouTube" / "scroll down" / "go back" / "flashlight" to direct one-shot tools that explicitly bypass the agent loop. KAI sends everything through screenshot→VLM→coordinates. See §3.2.
6. **The loop-breaker is a golden-set regression harness.** You already record every Copilot step + screenshot server-side (`modules/copilot/monitor.py`). That is 90% of a replayable fixture corpus. Wire it into a test suite and prompt changes get scored against ~100 real past screens in seconds instead of by vibes on your own phone.

Phase 0 is ~2–3 days and fixes everything visible. Phases 1–2 are the ones that actually end the loop.

---

## 1. The two bugs in your screenshots — exact root cause

Both screenshots show Live Talk failing to open an app and then *improvising an explanation*:

> "Hmm, it looks like there was a small issue with opening the Play Store."
> "I'm not totally sure why that happened. Sometimes there can be a temporary glitch…"

That vagueness is the tell: the model was handed a failure with no diagnostic content, so it made something up.

### 1.1 Root cause: missing `<queries>` — package visibility

[`KaiAccessibilityService.kt:137`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/KaiAccessibilityService.kt#L137) resolves app names like this:

```kotlin
val candidates = pm.queryIntentActivities(
    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0,
)
```

The code is correct. The OS silently defeats it. Android 11 (API 30) introduced **package visibility filtering**: an app targeting API 30+ gets a *filtered* result from `queryIntentActivities` containing essentially only itself, unless it declares what it needs to see.

KAI is `targetSdk = 36` ([`app/build.gradle.kts:20`](gnx_ai_kotlin/app/build.gradle.kts#L20)) and declares **no `<queries>` block and no `QUERY_ALL_PACKAGES`** — verified across every manifest in the module. So `candidates` is near-empty, both `firstOrNull` lookups miss, `openApp` returns `false`, and the user hears a shrug.

The reference app declares exactly the block KAI is missing (`AndroidManifest.xml` line 33):

```xml
<queries>
    <intent>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent>
</queries>
```

Note they do **not** use `QUERY_ALL_PACKAGES` (0 occurrences). That matters: `QUERY_ALL_PACKAGES` is a Play-restricted permission requiring a declaration form and a qualifying use case. The `<queries>` MAIN/LAUNCHER route gets launcher-style enumeration without that review burden. Use theirs.

### 1.2 Why Free Fire specifically will never work via vision

Free Fire is a Unity game. It renders to a single `SurfaceView` — its accessibility node tree is effectively empty and its visual UI is unlabelled art. There is no node to target and no reliable text to OCR. **`open_app` via launcher intent is the only viable route to a game**, which is precisely the path that was broken. Fixing §1.1 fixes the Free Fire case outright.

### 1.3 Secondary cause: failures aren't diagnosable

`openApp` returns a bare `Boolean`. [`GestureExecutor.kt:85`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/GestureExecutor.kt#L85) turns that into a single English string, and the model gets no machine-readable reason. There is no way for it to say "I can't see your installed apps — screen access may need re-granting," because nothing told it that.

The reference app ships a typed `com.agiinc.androidagent.agent.StopReason` enum plus `PhoneTaskResult`, with discrete terminal states (`COMPLETED / FAILED / ABORTED / CANCELED / BLOCKED / TIMEOUT / ERROR`). Every stop is a category, never a sentence.

### 1.4 The bigger bug: there is no way to turn on accessibility

This one is worse than the `<queries>` bug, because the `<queries>` fix doesn't matter if this isn't fixed too.

Verified in `gnx_ai_kotlin`:

- [`A11yBridge.kt:36`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/A11yBridge.kt#L36) defines `isEnabledInSettings()` — **and nothing ever calls it.**
- `ACTION_ACCESSIBILITY_SETTINGS` appears **nowhere in the codebase.** There is no button, no deep link, no prompt.
- [`ScreenControlPermissions.kt`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/ScreenControlPermissions.kt) handles *only* the overlay permission.
- The single UI entry point is a `ToggleTile` buried in `SettingsScreen.kt:379` — *"Let KAI control your screen"* — whose `checked` state is `settings.screenControlEnabled && overlayGranted`. **Accessibility isn't part of the condition.** So the toggle can read ON while Copilot is structurally incapable of doing anything.
- Tapping it when overlay is missing calls `openOverlaySettings(context)`, which drops the user on a bare system screen with **no guidance about what to do there** and no guidance that a *second*, harder grant is also required.

Net effect: a user enables the toggle, sees it turn on, asks KAI to do something, and hits this at [`CopilotSessionController.kt:105`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/CopilotSessionController.kt#L105):

```kotlin
if (!A11yBridge.awaitConnected(3000)) {
    refuse("a11y_not_connected", "Screen access isn't ready yet — try again in a moment.")
```

"Try again in a moment" is actively misleading — the service isn't slow to bind, it was never enabled, and no amount of waiting will change that. The user concludes the feature is broken. They're not wrong.

**This is the gold-standard gap you identified, and it's the correct thing to fix first.** See §3.1.

---

## 2. Why you're stuck in the loop

This is the part worth reading twice. The codebase is genuinely well-written — the comments in `CopilotSessionController` and `GestureExecutor` show careful reasoning about real failure modes. The loop isn't sloppiness. It's three structural properties:

### 2.1 Coordinate guessing is not reproducible

`modules/copilot/prompts.py` instructs the model to *estimate* pixel positions:

```
- If element is at ~10% from left edge, x = 100
- If element is at ~50% (center), x = 500
```

and [`GestureExecutor.kt:21`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/GestureExecutor.kt#L21) dispatches a blind gesture there:

```kotlin
fun px(norm: Int, dim: Int): Float = (norm / 1000f) * dim
```

Nothing checks that the tap landed on the intended element. The comment at line 73 records the symptom precisely — *"the KAI Copilot session that tapped this app's own decorative gear icon three times and gave up."*

A coordinate guess varies with device, density, font scale, OEM skin, theme, and A/B'd layouts. So a prompt change that fixes WhatsApp shifts the estimator's behaviour on Play Store. **You are not fixing bugs; you are re-balancing a single global estimator.** Every fix is a trade. That is the loop, exactly as you described it.

### 2.2 KAI never reads the screen's structure

`rootInActiveWindow` appears **nowhere** in the codebase. `KaiAccessibilityService` uses the node tree for one narrow purpose — `findFocus(FOCUS_INPUT)` for typing — and nothing else. And `onAccessibilityEvent` is an empty body:

```kotlin
override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
```

So Copilot has no idea what screen it's on, no window-change signal, and **no post-action verification**. It can't tell a successful tap from a missed one, which is why it narrates confusion instead of retrying.

Meanwhile the accessibility config is under-provisioned. KAI's [`kai_accessibility_service.xml`](gnx_ai_kotlin/app/src/main/res/xml/kai_accessibility_service.xml) vs. the reference app's:

| Attribute | KAI | Reference app | Why it matters |
|---|---|---|---|
| `accessibilityEventTypes` | `typeWindowStateChanged` | `0xffffffff` (all) | Screen-change detection, action verification |
| `accessibilityFlags` | *(absent)* | `0x8052` | See below |
| `flagReportViewIds` (`0x10`) | ✗ | ✓ | **Without it `getViewIdResourceName()` returns null** — no `com.whatsapp:id/entry`, no stable targeting |
| `flagRetrieveInteractiveWindows` (`0x40`) | ✗ | ✓ | See dialogs, sheets, IME, and other windows — not just the focused one |
| `canRetrieveWindowContent` | ✓ | ✓ | — |
| `canPerformGestures` | ✓ | ✓ | — |
| `canTakeScreenshot` | ✓ | ✓ | — |
| `isAccessibilityTool` | ✗ | ✓ | Play policy posture (see §6) |

`flagReportViewIds` is the single most important missing line in the repo. It is the difference between "tap somewhere around (500, 850)" and "click the node whose id is `com.whatsapp:id/send`."

### 2.3 There is no regression net at all

- **Zero tests.** No `src/test`, no `src/androidTest` anywhere in `gnx_ai_kotlin`.
- **Zero crash reporting.** No Sentry, Crashlytics, Bugsnag, or PostHog in the Gradle files. The reference app ships **both** Sentry (crashes) and PostHog (product analytics), and has a built-in `history.api.DebugAgentRunDetailDestination` screen for inspecting any past agent run step-by-step on-device.

So when something breaks in the field you learn about it from your own phone, by accident. Every fix is unverified, and nothing stops a fix from silently undoing an older one.

**What you already have, and should build on:** server-side you're in better shape than the client. `modules/copilot/monitor.py` already does `record_session_start / record_step / record_session_end` and uploads per-step screenshots. `modules/copilot/flags.py` already has a DB-backed `copilot_enabled` kill switch with `registry.abort_all()`. That's a real foundation — §4 turns it into the regression harness.

---

## 3. The reference architecture (what they do differently)

| Concern | Reference app | KAI today |
|---|---|---|
| **Element targeting** | Node tree: `resourceId` + `contentDescription` + `boundsInScreen`, serialized to text (`"Failed to build view hierarchy"`, `"; boundsInScreen: "`, `getViewIdResourceName`, `LocalResourceIdCache` all present in dex) | VLM-estimated 0–1000 coordinates |
| **Action verbs** | `Click`, `Swipe`, `ScrollBy`, `ScrollByOffset`, `ScrollUp/Down`, `ScrollToIndex`, `Type`, `PressBack`, `PressHome`, `Screenshot` | `tap`, `double_tap`, `long_press`, `swipe*`, `type`, `back`, `home`, `open_app`, `system_settings`, `wait` |
| **Screenshots** | AccessibilityService `canTakeScreenshot` (`A11yScreenshotCap`) — supplementary | Same mechanism — but it's the *only* input |
| **Background execution** | **Virtual display** (`virtualdisplay.VdResetActivity`; "Acquired VirtualDisplay backend=local", "Trusted VirtualDisplay unavailable; aborting background run") — agent drives a mirrored display so it doesn't hijack the user's screen | Drives the real foreground screen |
| **Failure reporting** | Typed `StopReason` + `PhoneTaskResult` | Free-text English string |
| **Step telemetry** | `PostStepWorker`, `PostResultWorker`, `HeartbeatWorker` — WorkManager, retry-safe | Server-side `record_step` (good) |
| **On-device debugging** | `DebugAgentRunDetailDestination` — per-run step inspector | None |
| **Mic arbitration** | `audio.AudioInputLease`, `RealtimeAudioFocusEvent` | No explicit lease |
| **Overlay safety** | `common.OverlayInteractionGuard` — agent can't click its own overlay | `overlayRects` passed to server as a prompt hint only |
| **Invocation** | Registered for `android.intent.action.ASSIST` — summonable by the system assistant gesture | In-app only |
| **Onboarding** | `SettingsGuidePipActivity` — picture-in-picture guide that stays visible *while* the user is in system Settings | Static instructions |
| **Notification context** | `HermesNotificationListenerService` | None |
| **Monitoring** | Sentry + PostHog | None |
| **Stack** | Hilt, Room, DataStore, Retrofit 3 + OkHttp 5 + `okhttp-sse`, Compose, Coil | — |

The headline: **they use the node tree as the source of truth and the screenshot as context. KAI uses the screenshot as the source of truth and never reads the tree.**

### 3.1 Their permission onboarding — treat this as the gold standard

You asked whether they put up a button and have the AI explain how to grant it. **Yes — and it's a full designed funnel, not a button.** Evidence pulled from their dex:

**One state object for every permission.** Not scattered checks:

```
PermissionGateUiState(overlayGranted=, accessibilityGranted=,
                      defaultAssistantGranted=, notificationsGranted=, …)
SettingsPermissionState(overlayGranted=, accessibilityGranted=, …,
                        defaultAssistantAvailable=true, batteryOptimizationIgnored=)
```

**A dedicated CTA per permission** — their analytics keys enumerate them exactly:

```
onboarding_cta_accessibility
onboarding_cta_display_overlay
onboarding_cta_default_assistant
permission_row   permission_missing   permission_granted
permission_denied   permission_request_shown   permission_dialog
```

`permission_row` confirms a repeating row component: one row per permission, live status, its own action button.

**First-person copy in the assistant's own voice**, explaining *why* — not OS boilerplate:

> " I need to tap and swipe for you."
> "I need this to help you."
> "Allows AGI to perform taps and gestures on your behalf."

**Literal step-by-step instructions for the system screen** — this is the `SettingsGuidePipActivity` payload, a picture-in-picture window that stays on screen *while the user is inside Android Settings*, where your app's UI is otherwise gone:

> "Find AGI under downloaded or installed apps. Turn it on, then tap Allow."

Button labels found: `"Turn on overlay"`, `"Display over apps"`, `"Enable notification access?"`, `"Accessibility service not enabled"`.

**A real recovery funnel for refusal** — the part almost nobody builds:

```
onboarding_accessibility_blocked     onboarding_refuse_accessibility
onboarding_accessibility_recovery    onboarding_blocked_show_me
onboarding_recovery_not_now          onboarding_recovery_open_settings
onboarding_funnel   onboarding_step   gate_blocked   gate_error_screen
first_run_cta_arrow   first_run_success_cta   first_run_permissions_granted
```

So: if you refuse, you aren't dead-ended — you get a recovery screen offering **"show me"** (walk me through it) or **"not now"**, and every branch is instrumented so they can see exactly where users fall out.

**Speech is coordinated with granting.** The assistant is talking during this, and they had to solve the collision:

```
CancelSpeechAndGrant
Mic gate timed out; force-cancelling speech before granting microphone
VoiceAgentMicPermissionBehavior(requestOnEntry=true, finishOnPermissionDenied=true,
                                startOnEntryWhenMicGranted=true,
                                startOnBubblePermissionGrant=false)
```

That last line is a *declarative* policy object — permission behaviour is configuration, not scattered `if` statements.

> Accuracy note: the CTAs, the step-by-step copy, the first-person framing, the recovery funnel, and the speech/grant coordination are all directly evidenced above. Their `message_user({"content":"…"})` tool returns "a concise **spoken** description," so the assistant demonstrably can speak arbitrary guidance — but I did not find a specific string proving it reads the accessibility steps aloud. Treat "AI speaks the permission guidance" as clearly supported by the architecture and worth building, not as a verbatim copy of a proven string.

**They also make it hard to get permanently stuck:**

```
accessibility service back, re-attaching overlay (attempt=…)
accessibility service still unavailable after 120 retries
```

They poll for **120 attempts** and re-attach the overlay when the service returns. KAI gives up after `awaitConnected(3000)` — 3 seconds — and then reports a misleading message.

### 3.2 Two-tier tools: simple commands never enter the agent loop

A second finding worth as much as the permission work. Their tool descriptions are explicit that easy things bypass the vision agent entirely:

> "Immediately open an installed app **without starting the full phone agent**. Use this for simple realtime requests like open YouTube, launch Chrome, or go to Maps. **Prefer `package_name` when you know it from the installed app list**; otherwise pass `app_name`."

> "Immediately scroll the current screen down using Android accessibility. Use this for simple realtime requests like scroll, scroll down, keep going… **when no full phone task is currently running**."

> "Do not open Settings, use quick settings, or call `start_task` for flashlight control."

Their full tool surface:

| Tier | Tools |
|---|---|
| **Direct / one-shot** (no vision, no loop) | `open_app`, `scroll_down`, `scroll_up`, `go_back`, `go_home`, `set_flashlight` |
| **Agent loop** (vision + node tree, multi-step) | `start_task` |
| **Terminal** (typed outcomes) | `finished`, `message_user`, `failed_to_complete_task` |

Plus a prompt section of explicit routing rules ("Tool-choice shortcuts: use `open_app` for phrases like open, launch, or go to…").

Two things follow for KAI:

1. **The model resolves to a package name, not a fuzzy label the phone then has to guess at** — *"Optional Android package name from the installed app list."* This is the structural version of the §0.3 fix: don't string-match a label at execution time, resolve to a real package name up front. (Their own client dex names a field `installed_apps` sitting immediately next to their `getInstalledApplications()` call — consistent with a lazy, queryable source rather than a fixed prompt blob, though the client is just the collector; their actual LLM call happens server-side at `api.agi.tech`, so there's no way to tell from the APK alone whether it's delivered as a tool result or a prompt field. Don't copy a delivery mechanism I can't confirm — §0.7 below designs this properly regardless.)
2. **"Open Play Store" should be a one-shot intent, never a vision task.** In KAI it currently enters the same screenshot→coordinates loop as everything else. That's how you get the session that "tapped this app's own decorative gear icon three times and gave up."

### 3.3 It's not a special "doesn't guess" model — it's what data the model is given

Worth being precise about this, since it's easy to assume the fix is swapping in a smarter VLM. It isn't. Confirmed by the current research literature, not just this codebase:

- **General-purpose VLMs are provably bad at raw pixel coordinates.** *"GPT-4V is unable to produce the exact x-y coordinate of the button location"* — this is true of Gemini and Claude too, and it's *why* [prompts.py](GNXSupreme5.0/modules/copilot/prompts.py) asking for `[x, y]` from 0–1000 produces guesses that miss. No amount of prompt-tuning fixes a task the model architecture isn't good at. ([Set-of-Mark Prompting, arXiv:2310.11441](https://arxiv.org/abs/2310.11441))
- **The fix that actually works in production agents is "Set-of-Mark": label the real elements (from the accessibility tree) with numbered IDs, and have the model pick an ID instead of predicting a coordinate.** *"Combining the annotated screenshot with the text metadata from accessibility tree, including the index, tag, name, and text of the elements"* — this is exactly Phase 1.1/1.2 of this plan (the indexed node list). It's a data/architecture change, not a model change, and it works with whatever VLM you're already paying for (Gemini, in KAI's case). ([LLM-Powered GUI Agents in Phone Automation survey, arXiv:2504.19838](https://arxiv.org/pdf/2504.19838))
- **Specialized "grounding" models do exist** — UI-TARS, SeeClick, ShowUI, GUI-Actor, Aria-UI — trained specifically to predict GUI coordinates more accurately than a general VLM. They're real and actively researched (GUI-Actor-7B beats UI-TARS-72B on the ScreenSpot-Pro benchmark despite being ~10x smaller — [arXiv:2506.03143](https://arxiv.org/html/2506.03143v1)), but they're still *fundamentally predicting a location from pixels* — better guessing, not "not guessing." Swapping to one means running a second, separate model alongside Gemini, self-hosted or via a research API, purely for the "vision fallback" slice of Copilot (games, canvas apps). Given Phase 1 makes vision a minority fallback path once the node tree is primary, this isn't worth the added infra for KAI right now — revisit only if the vision-fallback slice turns out to be a bigger fraction of real usage than expected.
- Nothing found in the reference app's dex names a specific model or provider — their LLM/VLM calls happen server-side (`api.agi.tech`), same as KAI's. Their advantage isn't a better model. It's that they hand their model ground-truth text (resource IDs, labels, bounds) instead of asking it to eyeball a screenshot.

**Bottom line: Phase 1 (node-tree indexing) *is* the "stop guessing" fix. It needs no model change.** Keep Gemini; change what it's fed.

---

## 4. The plan

### Phase 0 — Stop the bleeding (~2–3 days)

Small, independently shippable, no architecture change. Do this first and your screenshot bugs *and* the silent onboarding failure are gone.

**0.0 — Build the permission gate. This is the highest-value item in the whole plan.** (§1.4, §3.1)

Nothing else in Copilot matters if users can't turn it on, and today most can't. Port their pattern:

1. **One state object**, mirroring `PermissionGateUiState`:
   ```kotlin
   data class CopilotPermissionState(
       val accessibilityGranted: Boolean,   // A11yBridge.isEnabledInSettings() — finally call it
       val overlayGranted: Boolean,         // Settings.canDrawOverlays()
       val micGranted: Boolean,
       val notificationsGranted: Boolean,
   ) { val allReady get() = accessibilityGranted && overlayGranted && micGranted }
   ```
   Refresh on `ON_RESUME` — `rememberOverlayPermissionGranted` at `SettingsScreen.kt:1043` already has the right shape, generalise it to all four.

2. **A permission row per grant** — status chip (Granted / Needed) + its own action button, in a dedicated Copilot setup screen rather than one ambiguous toggle. Wire the accessibility row to:
   ```kotlin
   Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(FLAG_ACTIVITY_NEW_TASK)
   ```

3. **Fix the lying toggle.** `checked` must include `accessibilityGranted`. A toggle that reads ON while Copilot cannot function is worse than no toggle.

4. **First-person copy explaining why**, in KAI's voice, not OS boilerplate — *"I need this to tap and swipe for you."* You already have `copilot_a11y_description` in `strings.xml`; extend that tone into the gate UI.

5. **Step-by-step guidance that survives leaving the app.** Ship the copy first — *"Find KAI under 'Downloaded apps', tap it, turn it on, then tap Allow."* — shown before the jump. PiP (`SettingsGuidePipActivity`, `android.software.picture_in_picture`) is the better version and belongs here too, but the copy alone recovers most of the loss and is a fraction of the work. Do copy in 0.0, PiP as 0.0b.

6. **A recovery path, not a dead end.** If a grant is missing when a task is requested, don't refuse with a generic string — return `PermissionMissing(which)` and have Live Talk *say* what's needed and offer to open the right screen. Mirror their `show me` / `not now` branches.

7. **Replace the 3-second timeout.** `awaitConnected(3000)` conflates "not enabled" with "still binding". Check `isEnabledInSettings()` first:
   - not enabled → `A11yNotEnabled` → offer the setup flow (never "try again in a moment")
   - enabled but unbound → poll generously (theirs goes to 120 attempts) and re-attach the overlay on return

8. **Instrument the funnel.** `permission_request_shown` / `permission_granted` / `permission_denied` / `recovery_shown` / `recovery_open_settings` / `recovery_not_now`, per permission. Without this you're guessing where users drop; with it you'll know within a day of shipping. Pairs with the crash reporting in 0.5.

**0.1 — Add the `<queries>` block** to `gnx_ai_kotlin/app/src/main/AndroidManifest.xml`:

```xml
<queries>
    <intent>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent>
</queries>
```

Do **not** add `QUERY_ALL_PACKAGES`.

**0.2 — Provision the accessibility config.** In `kai_accessibility_service.xml`:

```xml
android:accessibilityEventTypes="typeAllMask"
android:accessibilityFlags="flagReportViewIds|flagRetrieveInteractiveWindows|flagIncludeNotImportantViews"
android:canRetrieveWindowContent="true"
android:canPerformGestures="true"
android:canTakeScreenshot="true"
```

`flagReportViewIds` is the unlock for Phase 1 — land it now so the data is available.

**0.3 — Harden `openApp`.** Replace the two-step label match with a resolution ladder, and return a *reason* instead of a bool:

1. Alias table for common names (`play store` → `com.android.vending`, `whatsapp` → `com.whatsapp`, `telegram` → `org.telegram.messenger`, …)
2. Exact label match (case-insensitive)
3. Normalised match (strip spaces/punctuation)
4. `contains` match — **only if unambiguous**; if 2+ candidates match, return `Ambiguous(candidates)` so the model can ask "did you mean X or Y?"
5. For Play Store specifically, fall back to `market://` / `https://play.google.com/store` VIEW intent

**0.4 — Introduce a typed failure taxonomy.** Replace `GestureExecutor.ExecResult(ok, detail)` and Copilot's terminal strings with a sealed hierarchy, and send the *code* over the wire alongside the human string:

```
AppNotFound(query, didYouMean) | AppNotInstalled(query) | Ambiguous(candidates)
NoNodeMatch(target) | NodeNotClickable(target) | GestureDispatchFailed
SecureScreen | ScreenOff | A11yNotConnected | OverlayPermissionMissing
StepBudgetExhausted | Timeout | UserAborted | ServerError
```

Then teach the Live Talk prompt to explain each code honestly. `AppNotFound` should produce *"I can't find an app called Free Fire on your phone — is it definitely installed?"*, never *"I'm not totally sure why that happened."*

**0.5 — Add crash + product telemetry.** Sentry (or Crashlytics) in `gnx_ai_kotlin`. You cannot harden what you cannot see, and right now field failures are invisible. Tag every event with `copilot_session_id` so client crashes join to the server-side step records.

**0.6 — Split the tool surface into two tiers.** (§3.2) Add direct one-shot tools that bypass the vision loop entirely — `open_app`, `scroll_down`, `scroll_up`, `go_back`, `go_home` — and reserve the `control_screen` agent loop for genuinely multi-step work. Add explicit routing rules to the Live Talk prompt, copying their "Tool-choice shortcuts" pattern. "Open Play Store" must never cost a screenshot, a VLM call, or a coordinate guess.

**0.7 — Resolve apps without paying for the full installed-app list every turn.** (§3.2) A real device carries 150–250 installed apps. Dumping all of them into the Live Talk system prompt on every session — the naive reading of the previous draft of this item — costs roughly 800–1,500 tokens *per session*, paid whether or not a rare app is ever mentioned. Don't do that. Instead, three tiers, cheapest first:

1. **Static alias table, ~0 tokens.** A small hardcoded map in `GestureExecutor`/`openApp` for the handful of apps that dominate real usage — WhatsApp, Telegram, Instagram, Chrome, YouTube, Play Store, Gmail, Maps, Settings, Camera, and whatever else shows up once real usage data exists (Phase 2's golden set will tell you). `"whatsapp" → "com.whatsapp"`, etc. This resolves the large majority of "open X" requests with a plain string lookup — no model round-trip, no tool call, no extra tokens at all.
2. **Model's own knowledge, then verify, ~0 extra prompt tokens.** For anything not in the alias table, let the model guess the package name itself — Gemini already knows common package names from training data (e.g. Free Fire is publicly `com.dts.freefireth`) — and have `open_app` try `pm.getLaunchIntentForPackage(guess)` directly. A guess that resolves costs nothing extra. This is the "try the package ID, check if it's actually installed" flow you described.
3. **`fetch_installed_apps(query: string)` tool, called only on a miss.** If (1) and (2) both fail — unknown app, or guessed package not present on this device — the model calls a tool that runs `queryIntentActivities`/`getInstalledApplications` **filtered fuzzily by `query` server-side on the phone**, returning only the top handful of label/package matches (typically 1–5 rows), not the full 200-app list. The model picks from those and retries `open_app` with the resolved `package_name`. This is the only tier that costs meaningful tokens, and it only fires for the genuinely rare case (Free Fire, an obscure regional app) — exactly the split you asked for.

Net: the common case ("open WhatsApp") costs the same as today, zero extra tokens. The rare case costs one small tool round-trip instead of a permanent 800–1,500-token tax on every session. `open_app`'s existing resolution ladder (§0.3) becomes the implementation of tiers 1–2; tier 3 is the one new tool.

### Phase 1 — Deterministic targeting (the real fix, ~1–2 weeks)

This is what takes coordinate guessing off the critical path.

**1.1 — Build a node-tree serializer** in `KaiAccessibilityService`. Walk `rootInActiveWindow` (and `windows` now that `flagRetrieveInteractiveWindows` is set), keep only actionable/labelled nodes, and emit a stable indexed list:

```
[0]  EditText   id=com.whatsapp:id/entry        text=""            editable  bounds=(60,1780,880,1880)
[1]  Button     id=com.whatsapp:id/send         desc="Send"        clickable bounds=(900,1790,1010,1870)
[2]  TextView   id=com.whatsapp:id/conversation text="Amma"        clickable bounds=(0,300,1080,420)
```

Cap it (~80 nodes, truncate long text) to bound token cost. Include `packageName` and the current activity so the model knows where it is.

**1.2 — Change the action contract to reference *indices*, not pixels.** The model returns `{"action":"click","target":1}`. The executor resolves index → `AccessibilityNodeInfo` → `performAction(ACTION_CLICK)`. No coordinates involved, so it is invariant to device, density, and font scale.

Resolution ladder inside the executor:
1. `node.performAction(ACTION_CLICK)` on the target
2. If not clickable, walk up to the nearest clickable ancestor
3. If still nothing, `tap()` the centre of `boundsInScreen` — the existing coordinate path, now a *fallback* rather than the default

**1.3 — Keep vision, demote it.** Send the screenshot *and* the node list every step. Vision earns its place for: games and canvas apps with empty trees (Free Fire), disambiguating visually-similar nodes, and reading rendered content the tree doesn't expose. When the tree has fewer than ~3 actionable nodes, fall through to today's pure-coordinate path automatically.

**1.4 — Add post-action verification.** Implement `onAccessibilityEvent` to record window/content changes. After each action, wait for settle and compare a cheap tree fingerprint (package + activity + node-count + focused-node id) before/after. Feed the model an explicit `screen_changed: true|false`. A click that changes nothing is a *detectable miss* it can retry differently — instead of a silent failure it narrates 3 steps later.

**1.5 — Enforce the overlay guard in code.** Today `overlayRects` is a prompt hint, so the model is politely asked not to tap KAI's own bubble. Do it structurally: filter KAI's own package out of the node list, and reject any resolved node or coordinate intersecting the live overlay rect. Mirrors the reference app's `OverlayInteractionGuard`.

### Phase 2 — The regression harness (this is what ends the loop, ~1 week)

Without this, Phase 1 buys you accuracy and you still can't lock a fix in.

**2.1 — Record the node tree alongside the screenshot.** Extend `monitor.record_step` to persist the serialized tree per step. You already store screenshots, so this is one more column.

**2.2 — Build a golden set from production runs.** Export ~100 real steps as fixtures:

```
fixtures/<case>/  task.txt  history.json  tree.txt  screen.jpg  expected.json
```

Seed it from the runs you already have recorded, weighted toward the failures you've been chasing. Every bug you've hit twice becomes a permanent fixture.

**2.3 — Offline replay test suite.** A pytest suite that feeds each fixture to the planner and asserts the chosen action is in an allowed set (not one exact string — several actions are legitimately correct). Report pass rate.

**2.4 — Gate prompt/model changes on it.** No prompt edit, model swap, or action-space change merges without running the suite. **This is the mechanism that breaks the loop**: a change that fixes WhatsApp and quietly regresses Play Store now shows up as `94% → 81%` in seconds, on your laptop, instead of on a user's phone three weeks later.

**2.5 — On-device run inspector.** Port the reference app's `DebugAgentRunDetailDestination`: a debug screen listing every step of the last N sessions with screenshot, tree, model reasoning, chosen action, and outcome. Turns "it failed weirdly" into a bug report you can act on.

**2.6 — A tiny device smoke suite.** 5–10 `androidTest` cases against real apps (open Settings, toggle Wi-Fi, open WhatsApp and focus the composer). Run before each release. Not comprehensive — just enough to catch a catastrophic break.

### Phase 3 — Live Talk hardening

**3.1 — Explicit mic lease.** Adopt the reference app's `AudioInputLease` pattern: a single owner for `RECORD_AUDIO` across Live Talk, the AI-call feature, and Copilot, with defined priority and preemption. Two features both opening an `AudioRecord` is a classic source of exactly the intermittent "sometimes it just doesn't hear me" bug that resists fixing.

**3.2 — Formalise the reconnect path.** [`CopilotSessionController.kt:207`](gnx_ai_kotlin/app/src/main/java/com/gokul00060/gnxmobile/livetalk/screencontrol/CopilotSessionController.kt#L207) already handles the subtle late-`SocketError`-overwrites-real-result race (the `SessionEnded` exception) — that reasoning is sound, keep it. Add on top: exponential backoff with jitter (the reference app has `BACKOFF_BASE_DELAY_SECONDS`), an explicit `Reconnecting` UI phase, and session resume so a 2-second network blip doesn't kill a 30-second task.

**3.3 — Register for `ASSIST`.** Add the `android.intent.action.ASSIST` intent filter so Live Talk is summonable by the system assistant gesture. Cheap, and it's the difference between an app you open and an assistant that's always a gesture away.

**3.4 — Notification context.** Port the equivalent of `HermesNotificationListenerService` (`ACTION_NOTIFICATION_LISTENER_SETTINGS`, `"Enable notification access?"`). Reading notifications lets KAI answer "what did I miss?" and gives Copilot context for messaging tasks. Add it as a *fourth, optional* row in the Phase 0 permission gate — clearly marked optional, so it never blocks Copilot setup.

**3.5 — Floating bubble.** Their `FloatingBubbleService` (SPECIAL_USE FGS, subtype `floating_quick_access_bubble`, *"Tap the floating bubble to open the assistant."*) makes the assistant reachable from inside any app. You already have `ScreenControlBubble` and overlay plumbing, so this is mostly lifecycle work on top of what exists.

### Phase 4 — Background execution (optional, later)

The reference app's virtual display lets the agent work without commandeering the user's screen. It's a genuine product differentiator and the single most advanced thing in their build — but it's also the most complex, has OEM-dependent reliability ("Trusted VirtualDisplay unavailable; aborting background run" is a real code path in their app), and appears to be gated behind a privileged/`DUMP`-permission server on their side. **Don't attempt this until Phases 0–2 are solid.** Foreground reliability first.

---

## 5. Sequencing

| Phase | Effort | Outcome |
|---|---|---|
| **0** | ~2–3 days | **Users can actually turn Copilot on**; screenshot bugs fixed; simple commands stop using vision; failures become diagnosable; you can see crashes |
| 1 | 1–2 weeks | Targeting becomes deterministic — the loop's root cause removed |
| 2 | ~1 week | Fixes become permanent; regressions caught pre-merge |
| 3 | ~1 week | Live Talk stops failing intermittently; notification context; bubble |
| 4 | later | Background agent (virtual display) |

Ship Phase 0 on its own. Do not bundle it with Phase 1 — you want the permission gate and the `<queries>` fix in users' hands this week, and you want the funnel numbers from 0.0 item 8 in isolation so you can tell what each change bought you.

**If you only do one thing: do 0.0.** Deterministic targeting fixes a feature users can't reach today. The permission gate is what lets them reach it.

---

## 6. Two risks to decide on, not discover

**Play Store accessibility policy.** Google's Accessibility API policy requires the use to be disclosed and to genuinely serve accessibility, or to have an approved exception. `isAccessibilityTool="true"` is the reference app's declaration — and they've shipped with it — but for an AI agent it's a judgement call, not a settled safe harbour. You already have `copilot_a11y_description` in `strings.xml`, which is the right instinct. Before adding `isAccessibilityTool`, decide deliberately whether you're claiming accessibility-tool status; an enforcement action against a live app with 100+ installs and paid tiers is a much worse day than a rejected update. This is worth 20 minutes on the current policy text rather than copying the flag because a competitor has it.

**Don't lose what's already good.** `CopilotSessionController` encodes several hard-won fixes in comments — the `isKeyguardLocked` false-positive, the `LiveTalkService.scope` vs `sessionJob` cancellation subtlety, the late-socket-error race. Phase 1 touches this file. **Turn each of those comments into a Phase 2 fixture or unit test before refactoring**, or the rewrite will reintroduce them and you'll be back in the loop you're trying to leave.

---

## 7. Definition of done

Phase 0–2 is complete when all of these hold:

**Permissions (Phase 0.0 — the gate)**
- [ ] There is an in-app button that opens `ACTION_ACCESSIBILITY_SETTINGS`
- [ ] `A11yBridge.isEnabledInSettings()` is actually called, and gates the toggle's `checked` state
- [ ] The "Let KAI control your screen" toggle can never read ON while Copilot is non-functional
- [ ] Every required permission has its own row with live status and its own action button
- [ ] Step-by-step instructions ("Find KAI under Downloaded apps…") are shown before the jump to Settings
- [ ] A missing permission mid-task makes KAI *say* which one and offer to open it — never "try again in a moment"
- [ ] A refusal leads to a recovery screen, not a dead end
- [ ] Per-permission funnel events fire, and you can read grant rates the day after shipping

**Copilot reliability**
- [ ] "Open Play Store", "open WhatsApp", "open Free Fire" succeed on a real device
- [ ] "Open X" / "scroll down" / "go back" complete with **zero** screenshots and zero VLM calls
- [ ] A non-installed app produces *"I can't find an app called X on your phone"*, never a vague glitch message
- [ ] Common apps resolve via the static alias table or a verified package-name guess, at zero added prompt tokens; `fetch_installed_apps` is called only on a miss
- [ ] Every Copilot failure surfaces a typed reason code, client and server
- [ ] `flagReportViewIds` is set and node `resourceId`s appear in recorded step data
- [ ] ≥80% of agent-loop actions resolve via node targeting; coordinates are fallback-only

**Not going back into the loop**
- [ ] A golden set of ≥100 real production steps exists and runs offline
- [ ] Prompt/model changes are gated on the golden-set pass rate
- [ ] Crash reporting is live and joined to `copilot_session_id`
- [ ] The on-device run inspector exists in debug builds

The item that actually ends the loop is the golden set. Everything else is a fix; that one is the machine that keeps fixes from undoing each other.
