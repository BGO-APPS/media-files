# Creative Prompt & Synthesis Pipeline: Creator Holding Device

## Generation Prompt
```
Close-up macro grip holding smartphone while emerald glowing orb navigates between WhatsApp and DoorDash without touching.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
