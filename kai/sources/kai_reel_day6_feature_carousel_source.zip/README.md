# Remotion React Composition: Day 6: Feature Carousel

Built with Remotion React video engine. Install dependencies with `npm install` and run `npm start`.
