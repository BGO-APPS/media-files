import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { PhoneRingIcon, BrainIcon, CalendarIcon, BoltIcon } from "../components/Icons";
import { LiveDot } from "../components/LiveDot";
import { KaiStamp } from "../components/KaiStamp";

// Day 6 — "Feature Carousel". Template: repeating lead-in, swapped tail — a
// fast top-of-funnel brand intro for someone who's never heard of KAI, pulled
// straight from marketing.md §1's feature table. Beats 1-6 share an identical
// skeleton (same icon size/position, same text size/position) so the eye
// predicts the pattern and processes each swapped payload faster — per the
// project's hook-style research. Beat 7 hands off to the standard KaiStamp
// end-card with the primary tagline (marketing.md §7), verbatim, since this
// is a general brand-intro video.
//
// All 6 rows of marketing.md §1's feature table are now covered (previous
// cut only used 4): calls you, never forgets/remembers, runs your day, talk
// to it live, chat, acts first. The two new beats (4 and 5, inserted before
// the "It acts first." differentiator so that beat stays last) are new
// distinct features rather than a near-duplicate of the existing "It
// remembers you." beat.

// Local icon for beat 4 — "Talk to it. Live." (real-time voice, marketing.md
// §1 row 2). No dedicated voice icon exists yet in Icons.tsx and this file
// is not allowed to touch src/components/, so it's built inline here,
// matching the flat monochrome line-icon language (currentColor via `color`
// prop, no gradients/glow) used by the rest of the set.
const WaveformIcon: React.FC<{ color: string; size?: number }> = ({ color, size = 64 }) => {
  const frame = useCurrentFrame();
  const baseHeights = [16, 28, 42, 30, 18];
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      {baseHeights.map((base, i) => {
        const h = base * (0.7 + 0.3 * Math.abs(Math.sin(frame / 6 + i * 1.3)));
        const x = 6 + i * 12;
        return <rect key={i} x={x} y={32 - h / 2} width={7} height={h} rx={3.5} fill={color} />;
      })}
    </svg>
  );
};

// Local icon for beat 5 — "It thinks it through." (smart chat that reasons,
// searches, and gets things done, marketing.md §1 row 3). Same constraint as
// WaveformIcon above: kept inline rather than added to Icons.tsx.
const ChatBubbleIcon: React.FC<{ color: string; size?: number }> = ({ color, size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path
      d="M8 14h48a4 4 0 0 1 4 4v26a4 4 0 0 1-4 4H24l-12 10V48h-4a4 4 0 0 1-4-4V18a4 4 0 0 1 4-4z"
      stroke={color}
      strokeWidth={4}
      strokeLinejoin="round"
      fill="none"
    />
    <circle cx="22" cy="30" r="2.5" fill={color} />
    <circle cx="32" cy="30" r="2.5" fill={color} />
    <circle cx="42" cy="30" r="2.5" fill={color} />
  </svg>
);

// Beat cuts below are NOT eyeballed — they're the exact phrase-end
// timestamps from ElevenLabs' forced-alignment API run against the real
// day6.mp3 narration (audio/day6.mp3, voice "River"), converted to frames
// at 30fps. Each caption now hard-cuts to the next right as its own phrase
// finishes being spoken, instead of the flat ~1.3s-per-beat guess that
// caused the reported "text out of sync with audio" issue.
const BEAT_1_END = 24; // 0.80s: "It calls you." finishes
const BEAT_2_END = 55; // 1.84s: "It remembers you." finishes
const BEAT_3_END = 97; // 3.24s: "It plans your day." finishes
const BEAT_4_END = 144; // 4.80s: "Talk to it, live." finishes
const BEAT_5_END = 182; // 6.06s: "It thinks it through." finishes
const BEAT_6_END = 221; // 7.38s: "It acts first." finishes (bg flips to black, LiveDot appears)
const CTA_DELAY = 80; // local-to-stamp frame where "KAI...lives with you." VO finishes (301 - 221)
const BEAT_7_END = 360; // 12.00s: KaiStamp + CTA — extended to cover the ElevenLabs VO track (312 frames / 10.4s)

export const day6DurationInFrames = BEAT_7_END;
export const day6Fps = 30;
export const day6Width = 1080;
export const day6Height = 1920;

// Shared skeleton for beats 1-6 — icon on top, headline below, identical
// size/position/weight every time. Icon + text are wrapped in a single
// WordPop so they land together as one unit rather than two races.
const BeatSlide: React.FC<{
  text: string;
  icon: React.ReactNode;
  background: string;
  showLiveDot?: boolean;
}> = ({ text, icon, background, showLiveDot }) => {
  return (
    <AbsoluteFill style={{ background, fontFamily }}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <WordPop
          from="bottom"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 28,
          }}
        >
          <div>{icon}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div
              style={{
                fontSize: 72,
                fontWeight: 700,
                color: kai.paper,
                textAlign: "center",
                letterSpacing: -1.5,
                maxWidth: 900,
              }}
            >
              {text}
            </div>
            {showLiveDot ? <LiveDot size={18} /> : null}
          </div>
        </WordPop>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const Day6FeatureCarousel: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.ink, fontFamily }}>
      <Audio src={staticFile("audio/day6.mp3")} />
      {/* Beat 1 — hook: the killer feature */}
      <Sequence from={0} durationInFrames={BEAT_1_END}>
        <BeatSlide
          text="It calls you."
          icon={<PhoneRingIcon color={kai.paper} size={96} />}
          background={kai.ink}
        />
      </Sequence>

      {/* Beat 2 — hard cut, identical skeleton, swapped payload */}
      <Sequence from={BEAT_1_END} durationInFrames={BEAT_2_END - BEAT_1_END}>
        <BeatSlide
          text="It remembers you."
          icon={<BrainIcon color={kai.paper} size={96} />}
          background={kai.ink}
        />
      </Sequence>

      {/* Beat 3 — hard cut, identical skeleton, swapped payload */}
      <Sequence from={BEAT_2_END} durationInFrames={BEAT_3_END - BEAT_2_END}>
        <BeatSlide
          text="It plans your day."
          icon={<CalendarIcon color={kai.paper} size={96} />}
          background={kai.ink}
        />
      </Sequence>

      {/* Beat 4 (new) — hard cut, real-time voice / hands-free conversation,
          marketing.md §1 row 2 */}
      <Sequence from={BEAT_3_END} durationInFrames={BEAT_4_END - BEAT_3_END}>
        <BeatSlide
          text="Talk to it. Live."
          icon={<WaveformIcon color={kai.paper} size={96} />}
          background={kai.ink}
        />
      </Sequence>

      {/* Beat 5 (new) — hard cut, smart chat that reasons/searches/acts,
          marketing.md §1 row 3. Deliberately not "It never forgets." to
          avoid duplicating Beat 2's memory beat. */}
      <Sequence from={BEAT_4_END} durationInFrames={BEAT_5_END - BEAT_4_END}>
        <BeatSlide
          text="It thinks it through."
          icon={<ChatBubbleIcon color={kai.paper} size={96} />}
          background={kai.ink}
        />
      </Sequence>

      {/* Beat 6 — hard cut, bg flips to pure black, LiveDot signals the
          differentiator: this one acts first, unprompted. Stays last among
          the swapped-payload beats. */}
      <Sequence from={BEAT_5_END} durationInFrames={BEAT_6_END - BEAT_5_END}>
        <BeatSlide
          text="It acts first."
          icon={<BoltIcon color={kai.paper} size={96} />}
          background={kai.black}
          showLiveDot
        />
      </Sequence>

      {/* Beat 7 — end-card, primary tagline verbatim from marketing.md §7.
          CTA pops in at CTA_DELAY, right as the VO finishes saying it. */}
      <Sequence from={BEAT_6_END} durationInFrames={BEAT_7_END - BEAT_6_END}>
        <KaiStamp
          startFrame={0}
          tagline="KAI. The AI that lives with you."
          ctaDelay={CTA_DELAY}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
