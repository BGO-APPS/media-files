# KAI / Your first minute

Concept: a welcoming pocket field guide that turns each capability into one action the viewer can repeat.

Canvas: 1080×2340, 30 fps, 60 seconds. Safe content 64–1016 horizontally and 110–2190 vertically.
Palette: cream #F4F2E9 background; deep forest #18392F text; moss #557060 secondary; pale sage #DCE8CF panels; citron #DBF36B instructional highlight; white #FFFFFF screenshot mattes.
Typography: Montserrat 900 headlines (100–120 px), Montserrat 400/700 supporting text (42–54 px), IBM Plex Mono 400 chapter labels (28 px). Embed fonts locally.
Composition: top chapter label and 6-step progress rail; headline at y=250; one dominant real screen excerpt in a square-cornered editorial window; instruction strip below; persistent caption zone y=2050. No 3D phone frames.
Motion: directional reveals, smoothly settling panels, accurately placed tap rings, screen-detail changes synchronized with narration. Hold examples long enough to read. Six distinct layouts using shared anchors. No flashing cuts.
Music: new 96 BPM D-major instrumental, soft electric-key chords, rounded bass, light percussion and restrained bell motif. Narration leads. End resolves on a fresh four-note signature.
