# KAI / Your first minute

Fresh pre-signup tutorial. Six chapters, exact 60-second canvas.

## Frame 1 — welcome
status: animated
src: compositions/welcome.html
duration: 7s
rules: spring-pop-entrance, waterfall-entry
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.

## Frame 2 — talk
status: animated
src: compositions/talk.html
duration: 12s
rules: spring-pop-entrance, waterfall-entry, cursor-click-ripple (registry simulated-cursor pulse adapted to touch)
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.

## Frame 3 — memory
status: animated
src: compositions/memory.html
duration: 10s
rules: spring-pop-entrance, waterfall-entry
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.

## Frame 4 — plan
status: animated
src: compositions/plan.html
duration: 11s
rules: spring-pop-entrance, waterfall-entry
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.

## Frame 5 — apps
status: animated
src: compositions/apps.html
duration: 12s
rules: spring-pop-entrance, waterfall-entry
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.

## Frame 6 — start
status: animated
src: compositions/start.html
duration: 8s
rules: spring-pop-entrance, waterfall-entry
Narration supplies the teaching order. Hold the real screen detail while the caption progresses.