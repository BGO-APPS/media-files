---
workflow: general-video
flow: automation
storyboard: no
message: "KAI turns an everyday request into help with your day; start by typing or speaking."
destination: in-app before signup
aspect: 1080x2340
length: 60 seconds
language: English
audience: first-time KAI users
voice: aura-2-thalia-en
---

## Confirmed
Make a one-minute tutorial before signup. Reuse raw screenshots and footage. New narration script, same voice. Entirely new music, composition and visual setup. Do not view or listen to the prior finished reel or reuse its production.

## Production decisions
Build one finished version autonomously from the clarified brief. Six teaching chapters, clear captions and touch indicators. Portrait dimensions follow the supplied native screenshots. Fresh sage/cream tutorial styling, numbered chapter rail, large screen excerpts, original 96 BPM instrumental.

## Assets
Native screenshots: /Users/skgokulbarath/Documents/marketing/Kai_rebirth/app_screenshorts/native_device
Raw recordings: GNX/raw_livetalk_uber.mp4, GNX/raw_copilot_uber.mp4, and KAI-Why-Reel/footage/whatsapp_demo.mov (raw source only).

## Scope
Explain chat/Live Talk, memory, reminders/calendar, proactive calls and app control. Finish with signup and one first request. No app integration requested. Validate current control labels against app code. Screenshots are illustrative supplied material; avoid implying staged examples are fresh live transactions.
