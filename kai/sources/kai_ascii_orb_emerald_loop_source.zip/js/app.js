/**
 * GNX Alive Energy Sphere - Main Application Entrypoint with Theme Selector
 */

import { logger } from './logger/logger.js';
import { EnergySphereRenderer } from './sphere/energy_sphere_renderer.js';
import { AudioReactiveController, SPHERE_STATES } from './sphere/audio_reactive_controller.js';

class App {
    constructor() {
        this.renderer = null;
        this.controller = null;
    }

    bootstrap() {
        logger.info('App.bootstrap', 'Initializing GNX Alive Energy Sphere Web Application');

        const canvas = document.getElementById('sphere-canvas');
        if (!canvas) {
            logger.error('App.bootstrap', 'Canvas element #sphere-canvas not found in DOM');
            return;
        }

        // Initialize WebGL Renderer
        this.renderer = new EnergySphereRenderer(canvas);
        if (!this.renderer.init()) {
            logger.error('App.bootstrap', 'Failed to initialize WebGL Renderer');
            return;
        }

        // Initialize Audio Reactive State Controller
        this.controller = new AudioReactiveController(this.renderer);
        this.controller.init();

        // Bind UI Controls & Theme Buttons
        this._bindUIControls();
        this._bindThemeSelector();

        // Start 60 FPS Render Loop
        this.renderer.start();

        logger.info('App.bootstrap', 'Energy Sphere Web App successfully launched & rendering at 60 FPS');
    }

    _bindUIControls() {
        const btnIdle = document.getElementById('btn-idle');
        const btnListen = document.getElementById('btn-listen');
        const btnTalk = document.getElementById('btn-talk');
        const btnSurge = document.getElementById('btn-surge');
        const btnMic = document.getElementById('btn-mic');
        const statusText = document.getElementById('status-text');

        const buttons = [btnIdle, btnListen, btnTalk, btnSurge];

        const setActiveButton = (targetBtn) => {
            buttons.forEach(btn => btn.classList.remove('active'));
            if (targetBtn) targetBtn.classList.add('active');
        };

        btnIdle.addEventListener('click', () => {
            this.controller.setState(SPHERE_STATES.IDLE);
            setActiveButton(btnIdle);
        });

        btnListen.addEventListener('click', () => {
            this.controller.setState(SPHERE_STATES.LISTENING);
            setActiveButton(btnListen);
        });

        btnTalk.addEventListener('click', () => {
            this.controller.setState(SPHERE_STATES.TALKING);
            setActiveButton(btnTalk);
        });

        btnSurge.addEventListener('click', () => {
            this.controller.triggerSurge(2500);
        });

        btnMic.addEventListener('click', async () => {
            await this.controller.enableMicrophone();
            setActiveButton(btnListen);
        });

        // Sync HUD Status Label on state change
        this.controller.onStateChange((newState) => {
            if (statusText) {
                statusText.textContent = `STATE: ${newState}`;
            }
            if (newState === SPHERE_STATES.IDLE) setActiveButton(btnIdle);
            if (newState === SPHERE_STATES.LISTENING) setActiveButton(btnListen);
            if (newState === SPHERE_STATES.TALKING) setActiveButton(btnTalk);
        });
    }

    _bindThemeSelector() {
        const themeBtns = document.querySelectorAll('.btn-theme');
        themeBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const themeKey = btn.getAttribute('data-theme');
                logger.info('App._bindThemeSelector', `User selected color theme: ${themeKey}`);
                
                themeBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                if (this.renderer) {
                    this.renderer.setTheme(themeKey);
                }
            });
        });
    }
}

// Bootstrap on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    const app = new App();
    app.bootstrap();
});
