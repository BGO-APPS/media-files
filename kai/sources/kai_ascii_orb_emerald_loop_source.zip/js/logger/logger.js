/**
 * Logger Utility for GNX Green Energy Sphere
 * Standard Format: [PROCESS/DEF_NAME] function_name: LEVEL - message
 */

export class Logger {
    constructor(processName = 'GREEN_SPHERE') {
        this.processName = processName;
    }

    info(fnName, message) {
        console.log(`[${this.processName}] ${fnName}: INFO - ${message}`);
    }

    warn(fnName, message) {
        console.warn(`[${this.processName}] ${fnName}: WARN - ${message}`);
    }

    error(fnName, message, errorObj = null) {
        const stackTrace = errorObj && errorObj.stack ? `\nStack: ${errorObj.stack}` : '';
        console.error(`[${this.processName}] ${fnName}: ERROR - ${message}${stackTrace}`);
    }
}

export const logger = new Logger('GREEN_SPHERE');
