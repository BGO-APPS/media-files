/**
 * 100% Luminous Glass Energy Orb Shaders (Zero Black Shadows)
 * 
 * Removes all dark void/black core colors. Renders a vibrant, radiant,
 * fully illuminated glass orb with specular glass reflections and glowing fluid caustics.
 * 
 * Maps 1:1 to AGSL RuntimeShader in Native Android (Jetpack Compose / SceneView).
 */

export const VERTEX_SHADER_SOURCE = `
uniform float uTime;
uniform float uAudioLevel;

varying vec3 vNormal;
varying vec3 vWorldPosition;
varying vec3 vViewPosition;
varying vec2 vUV;
varying vec3 vLocalPosition;

void main() {
    vUV = uv;
    vLocalPosition = position;
    vNormal = normalize(normalMatrix * normal);
    
    float timeMod = mod(uTime, 62.83185);
    
    // Smooth organic surface breathing along normal
    float pulse = sin(position.y * 5.0 + timeMod * 2.5) * cos(position.x * 5.0 + timeMod * 1.8);
    float displacement = pulse * (0.015 + uAudioLevel * 0.05);
    
    vec3 displacedPos = position + normal * displacement;
    vec4 mvPosition = modelViewMatrix * vec4(displacedPos, 1.0);
    
    vViewPosition = -mvPosition.xyz;
    vWorldPosition = (modelMatrix * vec4(displacedPos, 1.0)).xyz;
    
    gl_Position = projectionMatrix * mvPosition;
}
`;

export const FRAGMENT_SHADER_SOURCE = `
uniform float uTime;
uniform float uAudioLevel;
uniform vec3 uBaseColor;      // Primary Luminous Energy Color
uniform vec3 uHighlightColor; // Bright Specular Sheen / Glow
uniform vec3 uCoreColor;      // Luminous Inner Core Color (No Black)
uniform vec2 uTouchPoint;

varying vec3 vNormal;
varying vec3 vWorldPosition;
varying vec3 vViewPosition;
varying vec2 vUV;
varying vec3 vLocalPosition;

mat3 rotateY(float a) {
    float c = cos(a), s = sin(a);
    return mat3(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c);
}

mat3 rotateX(float a) {
    float c = cos(a), s = sin(a);
    return mat3(1.0, 0.0, 0.0, 0.0, c, -s, 0.0, s, c);
}

mat3 rotateZ(float a) {
    float c = cos(a), s = sin(a);
    return mat3(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0);
}

// Swirling Toroidal Energy Grooves
float toroidalVortex(vec3 p, float t) {
    vec3 q = rotateZ(0.785) * rotateX(0.55) * rotateY(t * 0.4) * p;
    
    float r = length(q.xz);
    float angle = atan(q.z, q.x);
    
    float ring1 = sin(r * 11.0 - q.y * 6.0 + angle * 2.0 - t * 2.0);
    float ring2 = cos(q.y * 9.0 + r * 7.0 - angle * 3.0 + t * 1.5);
    
    return smoothstep(-0.2, 0.8, ring1 * 0.65 + ring2 * 0.45);
}

void main() {
    vec3 N = normalize(vNormal);
    vec3 V = normalize(vViewPosition);
    
    float timeMod = mod(uTime, 62.83185);
    
    // 1. Fresnel Edge Glass Glow
    float NdotV = max(dot(N, V), 0.0);
    float fresnel = pow(1.0 - NdotV, 2.2);
    
    // 2. Swirling Fluid Pattern
    vec3 p = vLocalPosition * 2.1;
    float vortex1 = toroidalVortex(p, timeMod);
    float vortex2 = toroidalVortex(p * 1.3 + vec3(0.5), timeMod * 1.2);
    
    float vortexPattern = clamp(vortex1 * 0.7 + vortex2 * 0.5, 0.0, 1.0);
    
    // 3. ZERO BLACK SHADOWS - Pure Luminous Color Compositing
    vec3 luminousCore = uCoreColor;
    vec3 fluidEnergy = mix(uBaseColor, uHighlightColor, vortexPattern);
    
    // Smooth luminous color blending with no dark voids
    vec3 color = mix(luminousCore, fluidEnergy, vortexPattern * 0.6 + 0.4);
    
    // 4. Sharp Studio Glass Specular Spotlights
    vec3 lightDir1 = normalize(vec3(0.4, 0.8, 1.0));
    vec3 lightDir2 = normalize(vec3(-0.6, -0.5, 0.7));
    
    vec3 H1 = normalize(lightDir1 + V);
    float spec1 = pow(max(dot(N, H1), 0.0), 96.0); // Pure white studio glass highlight
    
    vec3 H2 = normalize(lightDir2 + V);
    float spec2 = pow(max(dot(N, H2), 0.0), 48.0);
    
    // Add specular gloss & volumetric core radiance
    color += vec3(1.0, 1.0, 1.0) * spec1 * 1.6;
    color += uHighlightColor * spec2 * 0.7;
    color += mix(uBaseColor, uHighlightColor, fresnel) * (fresnel * 1.4);
    
    // Audio energy pulse brightness
    color += uHighlightColor * (uAudioLevel * 0.4);
    
    // Interactive Touch Wave
    float distToTouch = length(vUV - uTouchPoint);
    float touchWave = sin(distToTouch * 30.0 - timeMod * 10.0) * exp(-distToTouch * 5.0);
    color += vec3(1.0) * max(touchWave, 0.0) * 0.8;

    // Fully vibrant alpha opacity
    float alpha = mix(0.92, 1.0, fresnel + vortexPattern * 0.1);

    gl_FragColor = vec4(color, alpha);
}
`;
