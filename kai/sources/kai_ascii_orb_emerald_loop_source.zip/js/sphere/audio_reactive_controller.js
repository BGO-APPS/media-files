/**
 * Audio Reactive & Interactive Energy State Controller
 * 
 * Drives state transitions (IDLE, LISTENING, TALKING, SURGE), smooth pulse modulation,
 * microphone audio analyzer input, and touch reactions.
 * 
 * Maps directly to Kotlin ViewModel + StateFlow on Android.
 */

import { logger } from '../logger/logger.js';

export const SPHERE_STATES = {
    IDLE: 'IDLE',
    LISTENING: 'LISTENING',
    TALKING: 'TALKING',
    SURGE: 'SURGE'
};

export class AudioReactiveController {
    constructor(renderer) {
        this.renderer = renderer;
        this.currentState = SPHERE_STATES.IDLE;
        
        this.targetAudioLevel = 0.0;
        this.currentAudioLevel = 0.0;
        this.audioContext = null;
        this.analyser = null;
        this.isMicActive = false;
        
        this.listeners = [];
        logger.info('AudioReactiveController.constructor', 'Instantiated state controller');
    }

    init() {
        logger.info('AudioReactiveController.init', 'Initializing audio reactive controller');
        this._startStateUpdateLoop();
    }

    setState(newState) {
        if (!SPHERE_STATES[newState]) {
            logger.warn('AudioReactiveController.setState', `Invalid state requested: ${newState}`);
            return;
        }

        const oldState = this.currentState;
        this.currentState = newState;
        logger.info('AudioReactiveController.setState', `State transition: ${oldState} -> ${newState}`);
        
        this._notifyStateChange(newState, oldState);
    }

    async enableMicrophone() {
        logger.info('AudioReactiveController.enableMicrophone', 'Requesting microphone access');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const source = this.audioContext.createMediaStreamSource(stream);
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            source.connect(this.analyser);
            
            this.isMicActive = true;
            this.setState(SPHERE_STATES.LISTENING);
            logger.info('AudioReactiveController.enableMicrophone', 'Microphone stream connected successfully');
        } catch (err) {
            logger.error('AudioReactiveController.enableMicrophone', 'Microphone permission denied or unavailable', err);
            this.isMicActive = false;
        }
    }

    triggerSurge(durationMs = 2000) {
        logger.info('AudioReactiveController.triggerSurge', `Triggering energy surge pulse for ${durationMs}ms`);
        const previousState = this.currentState;
        this.setState(SPHERE_STATES.SURGE);
        
        setTimeout(() => {
            if (this.currentState === SPHERE_STATES.SURGE) {
                this.setState(previousState);
            }
        }, durationMs);
    }

    onStateChange(callback) {
        this.listeners.push(callback);
    }

    _notifyStateChange(newState, oldState) {
        this.listeners.forEach(cb => cb(newState, oldState));
    }

    _startStateUpdateLoop() {
        const update = () => {
            const now = Date.now() / 1000.0;

            // Determine target audio amplitude based on state or live mic
            if (this.isMicActive && this.analyser) {
                const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
                this.analyser.getByteFrequencyData(dataArray);
                let sum = 0;
                for (let i = 0; i < dataArray.length; i++) {
                    sum += dataArray[i];
                }
                const average = sum / dataArray.length;
                this.targetAudioLevel = Math.min(average / 128.0, 1.0);
            } else {
                switch (this.currentState) {
                    case SPHERE_STATES.IDLE:
                        // Slow ambient breathing pulse
                        this.targetAudioLevel = (Math.sin(now * 1.5) * 0.5 + 0.5) * 0.15;
                        break;
                    case SPHERE_STATES.LISTENING:
                        // Gentle attentive ripple
                        this.targetAudioLevel = (Math.sin(now * 3.0) * 0.5 + 0.5) * 0.35 + 0.1;
                        break;
                    case SPHERE_STATES.TALKING:
                        // Vibrant talking energy fluctuations
                        this.targetAudioLevel = (Math.sin(now * 8.0) * 0.3 + Math.cos(now * 14.0) * 0.3 + 0.4) * 0.8;
                        break;
                    case SPHERE_STATES.SURGE:
                        // High energy surge
                        this.targetAudioLevel = 0.95 + Math.sin(now * 20.0) * 0.05;
                        break;
                }
            }

            // Smooth interpolation (lerp) for natural organic movement
            this.currentAudioLevel += (this.targetAudioLevel - this.currentAudioLevel) * 0.1;
            
            // Pass level to renderer
            if (this.renderer) {
                this.renderer.setAudioLevel(this.currentAudioLevel);
            }

            requestAnimationFrame(update);
        };

        update();
    }
}
