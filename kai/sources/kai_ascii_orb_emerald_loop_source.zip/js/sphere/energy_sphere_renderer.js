/**
 * 100% Luminous Glass Energy Orb Renderer
 * 
 * Completely eliminates black shadows and dark voids inside the sphere.
 * Renders vibrant, fully illuminated glass energy themes.
 */

import * as THREE from 'three';
import { logger } from '../logger/logger.js';
import { VERTEX_SHADER_SOURCE, FRAGMENT_SHADER_SOURCE } from './energy_shader.js';

export const COLOR_THEMES = {
    COSMIC_SAPPHIRE: {
        name: 'Cosmic Sapphire',
        base: 0x00d2ff,      // Vibrant Electric Sapphire Blue
        highlight: 0xffffff, // Pure White Glass Specular
        core: 0x0055ff       // Luminous Cobalt Blue (No Black)
    },
    NEON_PURPLE: {
        name: 'Neon Purple',
        base: 0x9d4edd,      // Electric Violet
        highlight: 0xff70a6, // Hot Pink Glow
        core: 0x5a189a       // Luminous Royal Purple (No Black)
    },
    SOLAR_AMBER: {
        name: 'Solar Amber',
        base: 0xff9100,      // Solar Amber Gold
        highlight: 0xffffff, // Pure White Specular
        core: 0xff3d00       // Luminous Warm Crimson (No Black)
    },
    CYBER_AQUA: {
        name: 'Cyber Aqua',
        base: 0x00f5d4,      // Electric Aqua Cyan
        highlight: 0xffffff, // Pure White
        core: 0x00a896       // Luminous Deep Teal (No Black)
    }
};

export class EnergySphereRenderer {
    constructor(canvasElement) {
        this.canvas = canvasElement;
        this.renderer = null;
        this.scene = null;
        this.camera = null;
        this.sphereMesh = null;
        this.material = null;
        this.uniforms = null;
        
        this.startTime = Date.now();
        this.isRunning = false;
        this.audioLevel = 0.0;
        this.targetRotX = 0;
        this.targetRotY = 0;
        
        // Initial Theme: Cosmic Sapphire (Fully Luminous Blue)
        this.targetBaseColor = new THREE.Color(COLOR_THEMES.COSMIC_SAPPHIRE.base);
        this.targetHighlightColor = new THREE.Color(COLOR_THEMES.COSMIC_SAPPHIRE.highlight);
        this.targetCoreColor = new THREE.Color(COLOR_THEMES.COSMIC_SAPPHIRE.core);

        logger.info('EnergySphereRenderer.constructor', 'Instantiated Luminous Glass Orb Renderer');
    }

    init() {
        logger.info('EnergySphereRenderer.init', 'Initializing Luminous Glass Orb Renderer');
        
        try {
            this.renderer = new THREE.WebGLRenderer({
                canvas: this.canvas,
                alpha: true,
                antialias: true,
                powerPreference: 'high-performance'
            });
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
            this.renderer.setClearColor(0x000000, 0);

            this.scene = new THREE.Scene();
            const aspect = this.canvas.clientWidth / this.canvas.clientHeight;
            this.camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
            this.camera.position.z = 3.5;

            this.uniforms = {
                uTime: { value: 0 },
                uAudioLevel: { value: 0 },
                uBaseColor: { value: this.targetBaseColor.clone() },
                uHighlightColor: { value: this.targetHighlightColor.clone() },
                uCoreColor: { value: this.targetCoreColor.clone() },
                uTouchPoint: { value: new THREE.Vector2(0.5, 0.5) }
            };

            this.material = new THREE.ShaderMaterial({
                vertexShader: VERTEX_SHADER_SOURCE,
                fragmentShader: FRAGMENT_SHADER_SOURCE,
                uniforms: this.uniforms,
                transparent: true,
                depthWrite: true,
                depthTest: true,
                side: THREE.FrontSide
            });

            const geometry = new THREE.SphereGeometry(1.15, 128, 128);
            this.sphereMesh = new THREE.Mesh(geometry, this.material);
            this.scene.add(this.sphereMesh);

            this._setupEvents();
            this.resize();

            logger.info('EnergySphereRenderer.init', 'Luminous Glass Orb initialized cleanly');
            return true;
        } catch (err) {
            logger.error('EnergySphereRenderer.init', 'Failed to initialize Renderer', err);
            return false;
        }
    }

    setTheme(themeKey) {
        const theme = COLOR_THEMES[themeKey];
        if (!theme) {
            logger.warn('EnergySphereRenderer.setTheme', `Unknown theme key: ${themeKey}`);
            return;
        }

        logger.info('EnergySphereRenderer.setTheme', `Switching to color theme: ${theme.name}`);
        this.targetBaseColor.setHex(theme.base);
        this.targetHighlightColor.setHex(theme.highlight);
        this.targetCoreColor.setHex(theme.core);
    }

    _setupEvents() {
        window.addEventListener('resize', () => this.resize());

        let isDragging = false;
        let lastX = 0, lastY = 0;

        const onPointerDown = (e) => {
            isDragging = true;
            lastX = e.clientX || (e.touches && e.touches[0].clientX);
            lastY = e.clientY || (e.touches && e.touches[0].clientY);

            const rect = this.canvas.getBoundingClientRect();
            const x = (lastX - rect.left) / rect.width;
            const y = (lastY - rect.top) / rect.height;
            this.uniforms.uTouchPoint.value.set(x, y);
        };

        const onPointerMove = (e) => {
            if (!isDragging) return;
            const currentX = e.clientX || (e.touches && e.touches[0].clientX);
            const currentY = e.clientY || (e.touches && e.touches[0].clientY);

            const deltaX = currentX - lastX;
            const deltaY = currentY - lastY;

            this.targetRotY += deltaX * 0.008;
            this.targetRotX += deltaY * 0.008;

            lastX = currentX;
            lastY = currentY;
        };

        const onPointerUp = () => { isDragging = false; };

        this.canvas.addEventListener('mousedown', onPointerDown);
        window.addEventListener('mousemove', onPointerMove);
        window.addEventListener('mouseup', onPointerUp);

        this.canvas.addEventListener('touchstart', onPointerDown, { passive: true });
        window.addEventListener('touchmove', onPointerMove, { passive: true });
        window.addEventListener('touchend', onPointerUp);
    }

    resize() {
        if (!this.renderer || !this.camera) return;
        const width = this.canvas.clientWidth || window.innerWidth;
        const height = this.canvas.clientHeight || window.innerHeight;

        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();

        this.renderer.setSize(width, height, false);
    }

    setAudioLevel(level) {
        this.audioLevel = level;
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        logger.info('EnergySphereRenderer.start', 'Starting 60 FPS render loop');
        this._renderLoop();
    }

    stop() {
        this.isRunning = false;
        logger.info('EnergySphereRenderer.stop', 'Stopped render loop');
    }

    _renderLoop() {
        if (!this.isRunning) return;

        this.render();
        requestAnimationFrame(() => this._renderLoop());
    }

    render() {
        if (!this.renderer || !this.scene || !this.camera) return;

        const currentTime = (Date.now() - this.startTime) / 1000.0;

        // Uniform Updates
        this.uniforms.uTime.value = currentTime;
        this.uniforms.uAudioLevel.value = this.audioLevel;

        // Smooth Color Lerp
        this.uniforms.uBaseColor.value.lerp(this.targetBaseColor, 0.05);
        this.uniforms.uHighlightColor.value.lerp(this.targetHighlightColor, 0.05);
        this.uniforms.uCoreColor.value.lerp(this.targetCoreColor, 0.05);

        // Organic Pulse & Rotation
        const scalePulse = 1.0 + Math.sin(currentTime * 2.5) * 0.015 + this.audioLevel * 0.07;
        this.sphereMesh.scale.setScalar(scalePulse);

        this.sphereMesh.rotation.y += 0.005;
        this.sphereMesh.rotation.x += (this.targetRotX - this.sphereMesh.rotation.x) * 0.08;
        this.sphereMesh.rotation.y += (this.targetRotY - this.sphereMesh.rotation.y) * 0.08;

        this.renderer.render(this.scene, this.camera);
    }
}
