# KAI Launch Trailer

A 66.6-second YouTube launch trailer for KAI. Everything you need to change it and render it again is in this folder. The picture, the music, the narrator and the timing are all rebuilt from the files here.

## What's where

| File / folder | What it is |
|---|---|
| `brag.mp4` | the finished trailer (appears after a render) |
| `roughcut.mp4` | quick preview: real clips + final sound + flat titles |
| `source/` | the 4 original screen recordings (copies; the originals stay in Downloads) |
| **`build/timeline.py`** | **the master clock**: every time, status label, result line and narrator beat |
| `build/captions.json` | word timings of the 4 spoken commands (made by `build/captions.py`, ElevenLabs) |
| `build/vo/` | narrator takes (ElevenLabs, voice "Brian") and `make_takes.py` that made them |
| `music/` | the score engine: `compose.py` (arrangement), `instruments.py` (sounds), `dsp.py` (mixing tools) |
| `music/out/` | rendered music stems (drums, bass, music, fx) |
| `build/audio_mix.py` | the final soundtrack: score + narrator + your demo voices + sound effects, mastered |
| `build/cut_clips.py` | cuts the recordings into beat-exact clips (`composition/assets/video/`) |
| `build/make_composition.py` | writes the animated video, `composition/index.html` |
| `composition/` | the Hyperframes project that renders the video |
| `brag-plan.md` | the creative plan and storyboard |
| `composition-brief.md` | the brief for the animation |

## One-time setup

```bash
python3.13 -m venv .venv && .venv/bin/pip install -r requirements.txt
```

You also need `ffmpeg` and `fluidsynth` (`brew install ffmpeg fluid-synth`), plus Node 22 or newer. The ElevenLabs CLI is needed only to make new voice lines or captions.

## Rebuild

```bash
./build.sh              # everything, then render brag.mp4
./build.sh sound        # after changing timing, music or voice
./build.sh video        # after changing text, colours or motion (the fast one)
./build.sh preview      # open it in Hyperframes Studio to scrub through
./build.sh rough        # quick rough cut -> roughcut.mp4
QUALITY=draft ./build.sh video   # faster test render
```

## Common edits

| I want to change… | Edit this | Then run |
|---|---|---|
| a status label, DONE word, result line, chapter name | `build/timeline.py` → `DEMOS` | `./build.sh video` |
| a caption word (spelling only) | `build/captions.json` → `text` | `./build.sh video` |
| colours, fonts, sizes, animation | `build/make_composition.py` | `./build.sh video` |
| the music | `music/compose.py` | `./build.sh sound video` |
| how loud the voices are vs. the music | `build/audio_mix.py` → `DUCK`, `norm_speech(...)` targets, `SFX_GAIN` | `./build.sh mix video` |
| a narrator line | `build/vo/make_takes_deepgram.py` → `LINES`, run it with `DEEPGRAM_API_KEY=... ../../.venv/bin/python make_takes_deepgram.py` from `build/vo/` (it prints where each word sits), then set `PICKS` in `build/audio_mix.py` | `./build.sh mix render poster` |
| go back to the old ElevenLabs narrator | swap in the commented-out `PICKS` in `build/audio_mix.py` | `./build.sh mix render poster` |
| which part of a recording is used | `build/timeline.py` → `cmd`, `kai`, `shots` (source seconds) | `./build.sh` (everything) |

`composition/index.html` can be edited by hand for a quick test, but `./build.sh video` regenerates it. Make lasting changes in `build/make_composition.py`.

## Timing facts

- 100 BPM: one beat = 0.6 s = 18 frames at 30 fps, one bar = 2.4 s.
- Drops at 12, 24, 36 and 48 s. The final hit is at 60 s.
- Each demo is a 2-bar ask (a 3-bar reveal + ask for the first one) followed by a 3-bar drop of six 2-beat shots.
- The whole film is 27 bars plus a 1.8 s ring-out = 66.6 s.
