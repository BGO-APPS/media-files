# Brag Plan: KAI

## What is this app?
KAI is a voice AI for Android that operates your other apps for you: you say what you want, and KAI's Copilot opens the app, searches, picks, and fills the cart while you watch.

## The angle
The brand's own line, played literally: **stop opening apps.** Four real, unedited-in-content screen recordings — food, a ride, a text, groceries — each one a spoken sentence followed by KAI doing every tap. The film is built as four ask → drop cycles: the user asks, the music stops dead under KAI's one-word reply ("On it!"), and the beat drops into a Copilot montage labelled with KAI's own status text. The proof is the footage; the type just keeps score.

## Hook (first 2-3 seconds)
Black. The green KAI dot pings once. Then three slams on three beats, narrated: **STOP. / OPENING. / APPS.** (green square periods, the KAI logo's full stop).

## Key moments (the middle)
- The real command on the KAI Live screen, captioned word by word as it's spoken.
- The stop-time: the band cuts out, KAI answers "On it!" in silence, the drop hits.
- The Copilot montage: six beat-cut shots per demo at 1-3x speed, KAI's status text as giant kinetic type ("Searching food", "Selecting Auto", "Composing message").
- The DONE stamp slammed on each result: IN YOUR CART. / RIDE READY. / SENT. / IN YOUR CART.

## Outro / punchline
Four results slap down one per beat → **4 APPS. / 0 TAPS.** → final hit: a hard ink wipe reveals **KAI.** and the green square pings → narrator: "Kai. Stop opening apps."

## User flow worth showing
Speak a request on the KAI Live screen → KAI's Copilot drives the target app on its own (status pills: Opening, Searching, Selecting, Adding) → the result screen (cart / ride confirm / sent message). Shown four times, from the four recordings in `~/Downloads/DEM-VID-V10*.mov`.

## Tone
- Preset: cinematic
- Creative direction: trailer-scale product film with a perreo heartbeat — cinematic build into dembow drops
- Interpretation: big type and hard hits, but every claim is shown in real footage; readability wins over speed on every caption

## Format: landscape — 1920x1080
## Duration: 66.6s (27 bars at 100 BPM + a 1.8s ring-out)
The /brag default is 15-25s; the user asked for a full 60-75s YouTube trailer that shows all four demos, so the length follows the four-cycle structure.

## Visual identity (from the project)
- Background: paper `#F6F6F4` (asks), black `#050505` (drops, hook, logo) — `lib/theme/mono.dart` / `Mono.kt`
- Accent: live green `#30D158` (the dot), accent `#23C552`, accent ink `#08240F` for text on green
- Text: ink `#0E0E10` on paper, paper on black; steel `#8A8A8E` / silver `#C6C6C8` for meta
- Display font: Syne ExtraBold (the app's splash wordmark)
- Body font: Instrument Serif Italic (editorial lines), JetBrains Mono (status / meta)
- Strongest visual element: the "KAI" wordmark with the green square full stop; KAI's green Copilot border and black status pills in the footage
- Style rules (marketing.md): flat 2D agency look, B&W kinetic type, hand-drawn doodles, snappy elastic motion, hard cuts, real UI in tilted panels with hard ink shadows. No neon, glow, gradients, glossy sci-fi or particles.

## Share copy (draft)
Four apps. Zero taps. You say it, KAI does it — food, rides, texts, groceries.

## Audio direction
- Role: cinematic support that becomes a dense rhythmic layer on every drop
- Music: original score composed for this cut — G minor, 100 BPM, cinematic braams and orchestra into Bad Bunny-style perreo (dembow kick/snare, tresillo 808). Engine: `~/Documents/music research/kai_score/` (numpy synthesis + FluidSynth orchestra), stems mixed in `build/audio_mix.py`.
- Music treatment: builds bar by bar; hard stop-time gate under each KAI reply; drops get crash + boom + impact; auto-ducked under every voice; mastered -14 LUFS / -1.2 dBTP
- Music cue guidance: the score is written to the edit, so the grid is exact — beat = 0.6s, bar = 2.4s. Strong cues: drops at 12.0 / 24.0 / 36.0 / 48.0s and the final hit at 60.0s. Beat-grid windows: hook words 0.6 / 1.2 / 1.8; tap flurry 2.4-3.6 in 16ths; montage shots every 2 beats inside each drop; climax cards 55.2 / 55.8 / 56.4 / 57.0; 4 APPS. 57.6; 0 TAPS. 58.8. Cue file: `composition/assets/music/cues/kai_trailer_mix.music-cues.json`.
- Audio-reactive treatment: subtle; bass energy makes the phone panel's hard shadow and the live-dot indicator breathe. No waveform or equalizer visuals.
- SFX posture: moderate and motion-matched, all synthesised — dot pings, eight finger taps, whooshes into every ink wipe, rubber-stamp thuds on DONE, 32nd-note key ticks under the typed message, card slaps in the climax.
- Audio-coupled moments: word-by-word captions ride the real voice; DONE stamps; the typed message; card-by-card climax; logo ping.
- Restraint rule: nothing speaks over the user's command or KAI's reply; the music never pumps under the narrator's hook words by more than 6 dB.

## Voiceover script
Narrator: ElevenLabs "Brian" (eleven_v3), placed so each word's vowel lands on its beat.
- 0.6 / 1.2 / 1.8s — "Stop. / Opening. / Apps."
- 3.6s — "Just say it."
- 60.3s — "Kai."
- 61.2s — "Stop opening apps."
The four commands and KAI's replies are the real recordings, not TTS.

## Storyboard

### Scene 1 — Hook — 2.4s (0.0-2.4)
Black. Green square pings at centre (0.0). STOP. / OPENING. / APPS. slam in on beats 2-4, stacked, green square periods; each hold ≥ 0.6s, the full set holds to 2.4.
Sequential/interaction: yes — three words, one per beat, narrated.
Audio intent: trailer braams, one per word, over silence.
Audio-coupled idea: dot ping; braam + timpani per word.
Transition mood: hard → Scene 2

### Scene 2 — The old way — 1.2s (2.4-3.6)
Paper. "The old way." A grid of eight ink app tiles gets tapped one per 16th note; the tapped tiles fill ink, the last one green. Counter "TAPS ×8".
Sequential/interaction: yes — simulated taps on a 16th grid.
Audio intent: frantic pizzicato ostinato + finger taps.
Transition mood: hard → Scene 3

### Scene 3 — Just say it — 1.2s (3.6-4.8)
Black. JUST / SAY / IT. appear on the narrator's syllables, hand-drawn squiggle under SAY.
Audio intent: the big hit (impact, boom, brass, choir).
Transition mood: ink wipe → Scene 4

### Scene 4 — Reveal — 2.4s (4.8-7.2)
Paper. The phone panel (tilted, hard ink shadow) wipes in on the real KAI Live screen connecting. Beside it: "This is KAI." and a live "● LISTENING" indicator.
Audio intent: choir and strings swell, first hint of the hook melody on bells.
Transition mood: continuous → Scene 5

### Scenes 5-12 — Four ask → drop cycles — 12s each (7.2-55.2)
Ask (paper, 4.8s; the first one 4.8s after the reveal): the phone plays the real command; the sentence builds word by word beside it, then KAI's reply lands in a green pill during the stop-time silence.
Drop (black, 7.2s): flash-inversion on the downbeat; six 2-beat shots with punch-ins and alternating tilt; KAI's status text as giant kinetic type per shot; chapter tag 01 FOOD / 02 RIDES / 03 TEXTS / 04 GROCERIES; the last shot takes the DONE stamp + the result line from the screen.
Order: DoorDash (phone left) → Uber (right) → the chat (left; the typed message types out with key ticks) → Zepto (right).
Sequential/interaction: yes — captions word by word; shots on the beat grid; stamp slam.
Audio intent: ask 1 near-silent heartbeat, ask 2 filtered groove, ask 3 half-time guitar, ask 4 tremolo tension; each drop bigger than the last.
Transition mood: ink wipe between cycles; hard flash cut on every drop.

### Scene 13 — Climax — 4.8s (55.2-60.0)
Paper. The four result screens slap down one per beat as tilted cards, then **4 APPS.** (57.6) and **0 TAPS.** (58.8), each held ≥ 1.2s.
Sequential/interaction: yes — card by card on the beat grid.
Audio intent: full band, snare roll and riser into the final hit.
Transition mood: hard → Scene 14

### Scene 14 — Logo + outro — 6.6s (60.0-66.6)
Black. Final hit; a hard-edge ink wipe reveals **KAI.**; the green square pings as the wipe clears it (60.9). "Stop opening apps." in Instrument Serif Italic (61.2). Hold, fade on the ring-out.
Audio intent: the biggest hit, then the hook melody slowed on a glass bell.

**Music mood for this video:** cinematic → perreo
**Audio summary:** trailer braams and a heartbeat build to four dembow drops, each one bigger, each stopped dead so KAI's answer can be heard, ending on one huge hit and a bell.

## Decisions I made (flag any you want changed)
- Claims stay true to the footage: "IN YOUR CART." / "RIDE READY." rather than "ordered" — every demo stops at a cart or confirm screen. The Zepto cart's second item was already there before the demo; the card shows the whole cart screen, the line names only the item KAI added.
- The DoorDash line uses the cart's own total (A$25.65 = A$22.90 + fees).
- The chat demo is labelled TEXTS; its first shot is pushed in 1.16x so the messaging app's wordmark stays out of frame. The spoken command still names the app — see the notes at delivery.
- "0 TAPS." means taps by the user after speaking; the recordings show none.
- The tapping montage is drawn rather than filmed, because every demo frame already shows KAI's Copilot border.
