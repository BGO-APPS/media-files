# Hyperframes Composition Brief: KAI

## Objective
A cinematic 66.6s launch trailer for KAI's YouTube channel: four real voice-command demos, each an ask → stop-time → dembow drop, bookended by "STOP. OPENING. APPS." and the KAI logo.

## Output
- Composition directory: `composition/`
- Rendered video: `brag.mp4`
- Format: landscape — 1920x1080, 30 fps
- Duration: 66.6s (user-requested full trailer; overrides the 15-25s default)

## Source Material
- Project root: `/Users/skgokulbarath/Documents/LAMx/GNX` (app: `gnx_ai_kotlin`)
- Primary files read: `gnx_ai_kotlin/.../ui/screens/SplashScreen.kt`, `Mono.kt` / `lib/theme/mono.dart`, `marketing.md`, the four demo recordings `~/Downloads/DEM-VID-V10*.mov`
- Product name: KAI
- Tagline / strongest claim: "Stop opening apps." (marketing.md, Ad 3)
- Key UI to show: the KAI Live screen, the Copilot border and status pills driving DoorDash, Uber, the chat app and Zepto; each result screen
- Copy that must appear verbatim:
  - STOP. OPENING. APPS. / JUST SAY IT.
  - KAI's status texts per shot (see `build/timeline.json` → demos[].do.shots[].label)
  - KAI's replies: "On it!", "Right away!", "Right away!", "Sure!"
  - Result lines exactly as on screen: "Big Brekkie Burger Meal · Total A$25.65", "Auto to George Town - 3 min - Rs 165.73", "Hey Alex! Meeting is confirmed for 4 PM.", "Amul Gold Butterscotch 1L - Rs 260"
  - 4 APPS. / 0 TAPS. / KAI. / Stop opening apps.

## Creative Direction
- Tone preset: cinematic
- Creative direction: trailer-scale product film with a perreo heartbeat
- Interpretation: slam-in / hold type, hard cuts and wipes, flash inversions on drops; captions always held long enough to read
- Angle, hook, outro: see `brag-plan.md`
- Avoid: generic SaaS language, abstract filler, neon/glow/gradients/particles (brand rule), recolouring or redrawing the app UI

## Visual Identity
- Background: paper `#F6F6F4`; black `#050505`
- Text: ink `#0E0E10`; paper on black; steel `#8A8A8E`, silver `#C6C6C8`
- Accent: live green `#30D158`; text on green `#08240F`
- Display font: Syne ExtraBold (`assets/fonts/syne_extrabold.ttf`, from the app)
- Body fonts: Instrument Serif Italic (`assets/fonts/instrument_serif_italic.ttf`, from the app), JetBrains Mono (`assets/fonts/JetBrainsMono-Variable.ttf`)
- Visual references: KAI wordmark with the green square full stop; flat panels with hard offset ink shadows; hand-drawn squiggles

## Storyboard
Contract: `brag-plan.md`. All times come from `build/timeline.json` (single source of truth); captions from `build/captions.json`; voice/SFX spans from `build/audio_cues.json`.
1. Hook — 2.4s — dot ping, STOP. / OPENING. / APPS.
2. The old way — 1.2s — eight tapped tiles
3. Just say it — 1.2s
4. Reveal — 2.4s — KAI Live screen, "This is KAI."
5-12. Four ask/drop cycles — 48s — captions, KAI reply pill, montage with status type, DONE stamps
13. Climax — 4.8s — four result cards, 4 APPS. / 0 TAPS.
14. Logo + outro — 6.6s — ink wipe reveals KAI., dot ping, "Stop opening apps."

## Audio
- Audio role: cinematic support → dense rhythmic layer on the drops
- Audio arc: braams → heartbeat → four drops, each bigger → final hit → bell
- Music: `assets/music/kai_trailer_mix.wav` — the full final mix (score + narrator + the demos' real voices + synthesised SFX), already ducked and mastered to -14 LUFS / -1.2 dBTP. It is the only `<audio>` element and plays at volume 1.
- Music cue guidance: `assets/music/cues/kai_trailer_mix.music-cues.json` (exact grid: the score was written to this edit). Strong cues: 12.0 / 24.0 / 36.0 / 48.0 / 60.0.
- Audio-reactive treatment: subtle — bass band drives the phone panel's shadow depth and the live-dot indicator
- Audio-coupled moments: captions ride the real voice; DONE stamps; typed message; climax cards; logo ping
- SFX: already mixed into the master; visuals must land on the SFX times in `build/audio_cues.json`

## Hyperframes Instructions
Standalone root, one paused GSAP timeline at `window.__timelines["main"]`, generated from the timeline JSON by `build/make_composition.py`. Videos are host-level (never inside a timed wrapper). Beat-locked drops marked `// beat-locked`, sequential reveals marked `// beat-grid`. Gate: `npx hyperframes check` with zero errors.
