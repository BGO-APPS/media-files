import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { PhoneRingIcon } from "../components/Icons";
import { LiveDot } from "../components/LiveDot";
import { DoodleUnderline } from "../components/DoodleUnderline";
import { KaiStamp } from "../components/KaiStamp";

// Hero ad — "The Save". Source: marketing.md §5 Scenario B (Arjun, 29 — the
// one scenario none of the 7-day calendar touched) + §6 Ad 1's own spec
// ("Quick cuts of ... dialogue as on-screen kinetic text. Freeze. Stamp.").
// Built as a real two-voice phone call rather than one narrator VO: KAI
// (voice "River", the same voice used across all 7 days) and Arjun (voice
// "Will") each speak their own lines from marketing.md's dialogue verbatim.
// A generated ring SFX plays under the incoming-call screen.
//
// Every beat below is sized from the ACTUAL measured duration of its audio
// clip (ffprobe on public/audio/hero/*.mp3), not eyeballed — the fix applied
// to Day 6 after the "captions out of sync" report, this time built in from
// the start instead of patched in after.
//
// Audio clip durations (30fps):
//   ring.mp3       3.000s -> 90f
//   kai_l1.mp3     3.483s -> 105f  "Quick one. You told me last month your mom's birthday is tomorrow."
//   kai_l2.mp3     2.508s -> 76f   "Flowers close at six. Order the usual place?"
//   arjun_l1.mp3   1.579s -> 48f   "...I completely forgot."
//   arjun_l2.mp3   1.579s -> 48f   "Yes. You're a lifesaver."
//   kai_outro.mp3  4.551s -> 137f  "KAI remembers what you said once, weeks ago. KAI, the AI that lives with you."
//
// fps 30, 1080x1920, total 721 frames = 24.03s.

const COLD_1_END = 24; // 0.0-0.8s: "3:40 PM."
const COLD_2_END = 54; // 0.8-1.8s: "Back-to-back meetings."
const COLD_3_END = 72; // 1.8-2.4s: "Then—"

const RING_END = COLD_3_END + 90; // 162 (5.4s): incoming-call screen, ring.mp3 plays full length

const CONNECT_PAUSE = 10; // silent beat as the "call connects", before KAI speaks
const CALL_START = RING_END + CONNECT_PAUSE; // 172

const K1_END = CALL_START + 105; // 277: kai_l1 plays + caption
const K2_START = K1_END + 8; // 285: short breath, KAI continues
const K2_END = K2_START + 76; // 361: kai_l2 plays + caption
const A1_START = K2_END + 20; // 381: longer pause -- Arjun processing what he just heard
const A1_END = A1_START + 48; // 429: arjun_l1 plays + caption
const A2_START = A1_END + 10; // 439: quick beat
const A2_END = A2_START + 48; // 487: arjun_l2 plays + caption

const FREEZE_START = A2_END + 14; // 501: let the gratitude land before the cut
const FREEZE_END = FREEZE_START + 40; // 541: silent freeze-frame beat, per Ad 1 spec ("Freeze.")

const STAMP_START = FREEZE_END; // 541
const CTA_DELAY = 147; // local frame inside the stamp: kai_outro (137f) + 10f gap
const STAMP_DURATION = 180; // 6.0s -- covers the full outro VO plus CTA hold

export const heroDurationInFrames = STAMP_START + STAMP_DURATION; // 721 = 24.03s
export const heroFps = 30;
export const heroWidth = 1080;
export const heroHeight = 1920;

export const HeroTheSave: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.paper, fontFamily }}>
      {/* Cold open -- silent, context only, paper/ink, same kinetic-caption
          grammar as Day 1's cold open so the hero ad still reads as the
          same brand system. */}
      <Sequence from={0} durationInFrames={COLD_1_END}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <WordPop>
            <div style={{ fontSize: 64, fontWeight: 700, color: kai.ink, letterSpacing: -1 }}>
              3:40 PM.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={COLD_1_END} durationInFrames={COLD_2_END - COLD_1_END}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <WordPop>
            <div
              style={{
                fontSize: 52,
                fontWeight: 700,
                color: kai.ink,
                textAlign: "center",
                maxWidth: 800,
                letterSpacing: -1,
              }}
            >
              Back-to-back meetings.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={COLD_2_END} durationInFrames={COLD_3_END - COLD_2_END}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <WordPop>
            <div style={{ fontSize: 46, fontWeight: 500, color: kai.steel, letterSpacing: -0.5 }}>
              Then—
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Incoming call -- hard cut to black, ring SFX plays under a pulsing
          call screen. First time this project uses a generated sound
          effect rather than only spoken VO. */}
      <Sequence from={COLD_3_END} durationInFrames={RING_END - COLD_3_END}>
        <Audio src={staticFile("audio/hero/ring.mp3")} />
        <IncomingCallScreen />
      </Sequence>

      {/* The call connects -- silent beat, then real two-voice dialogue.
          Each line is its own audio clip in its own Sequence, so captions
          are in sync by construction: the Sequence's duration IS that
          clip's measured length, not a guess. */}
      <Sequence from={CALL_START} durationInFrames={K1_END - CALL_START}>
        <Audio src={staticFile("audio/hero/kai_l1.mp3")} />
        <CallLine speaker="KAI" text="Quick one. You told me last month your mom's birthday is tomorrow." fontSize={46} />
      </Sequence>

      <Sequence from={K2_START} durationInFrames={K2_END - K2_START}>
        <Audio src={staticFile("audio/hero/kai_l2.mp3")} />
        <CallLine speaker="KAI" text="Flowers close at six. Order the usual place?" fontSize={50} />
      </Sequence>

      <Sequence from={A1_START} durationInFrames={A1_END - A1_START}>
        <Audio src={staticFile("audio/hero/arjun_l1.mp3")} />
        <CallLine speaker="ARJUN" text="…I completely forgot." fontSize={54} />
      </Sequence>

      <Sequence from={A2_START} durationInFrames={A2_END - A2_START}>
        <Audio src={staticFile("audio/hero/arjun_l2.mp3")} />
        <CallLine speaker="ARJUN" text="Yes. You're a lifesaver." fontSize={54} />
      </Sequence>

      {/* Freeze -- per marketing.md Ad 1 spec verbatim: "Freeze." Silent
          beat, paper bg bookending the cold open, self-drawing underline
          keeps the hold in motion per the "more motion graphics" note. */}
      <Sequence from={FREEZE_START} durationInFrames={FREEZE_END - FREEZE_START}>
        <FreezeBeat />
      </Sequence>

      {/* Stamp -- KAI's own VO closes the ad, then the same download CTA
          built for Day 6 pops in right as the VO finishes. */}
      <Sequence from={STAMP_START} durationInFrames={STAMP_DURATION}>
        <Audio src={staticFile("audio/hero/kai_outro.mp3")} />
        <KaiStamp
          startFrame={0}
          tagline="It remembers everything. So you don't have to."
          ctaDelay={CTA_DELAY}
        />
      </Sequence>
    </AbsoluteFill>
  );
};

// Incoming-call screen -- a full-screen call UI (not a chat/screenshot
// mock like the other days use), pulsing gently in time with the ring SFX.
const IncomingCallScreen: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = 1 + Math.sin(frame / 6) * 0.035;
  return (
    <AbsoluteFill style={{ background: kai.black, alignItems: "center", justifyContent: "center" }}>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 26,
          transform: `scale(${pulse})`,
        }}
      >
        <PhoneRingIcon color={kai.paper} size={104} />
        <div style={{ fontSize: 72, fontWeight: 700, color: kai.paper, letterSpacing: -1.5 }}>
          KAI
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <LiveDot size={14} />
          <div style={{ fontSize: 26, fontWeight: 500, color: kai.steel, letterSpacing: 1 }}>
            incoming call…
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Shared dialogue-line treatment -- speaker label (LiveDot only for KAI,
// per marketing.md's single-accent rule: the dot marks the AI, never the
// human) above a big kinetic-typography line, black bg carried through
// every dialogue Sequence so the call reads as one continuous screen.
const CallLine: React.FC<{ speaker: "KAI" | "ARJUN"; text: string; fontSize?: number }> = ({
  speaker,
  text,
  fontSize = 52,
}) => (
  <AbsoluteFill style={{ background: kai.black, alignItems: "center", justifyContent: "center", padding: "0 90px" }}>
    <WordPop>
      <div style={{ textAlign: "center" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            marginBottom: 20,
          }}
        >
          {speaker === "KAI" ? <LiveDot size={14} /> : null}
          <div
            style={{
              fontSize: 24,
              fontWeight: 700,
              letterSpacing: 3,
              color: kai.steel,
              textTransform: "uppercase",
            }}
          >
            {speaker}
          </div>
        </div>
        <div style={{ fontSize, fontWeight: 700, color: kai.paper, lineHeight: 1.2, maxWidth: 860 }}>
          {text}
        </div>
      </div>
    </WordPop>
  </AbsoluteFill>
);

// Freeze beat -- separated into its own component so it can read its own
// local frame for the self-drawing underline, same technique Day 7's
// Aftermath beat uses.
const FreezeBeat: React.FC = () => {
  const frame = useCurrentFrame();
  const underlineProgress = Math.min(1, Math.max(0, (frame - 10) / 20));
  return (
    <AbsoluteFill style={{ background: kai.paper, alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center" }}>
        <WordPop>
          <div style={{ fontSize: 60, fontWeight: 700, color: kai.ink, letterSpacing: -1 }}>
            That&rsquo;s the magic moment.
          </div>
        </WordPop>
        <div style={{ display: "flex", justifyContent: "center", marginTop: 20 }}>
          <DoodleUnderline progress={underlineProgress} color={kai.ink} width={260} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
