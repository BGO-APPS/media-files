# Creative Prompt & Synthesis Pipeline: Flat Motion Graphic App Showcase

## Generation Prompt
```
Flat 2D vector animation showcasing multi-app automation: Uber, Zepto, Telegram, WhatsApp.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
