#!/usr/bin/env bash
# Introducing KAI - rebuild the film from the sources in this folder.
#
#   ./build.sh            everything: timeline -> music -> mix -> captions -> clips -> animation -> check -> render -> poster
#   ./build.sh sound      timeline -> music -> mix -> audio data (after changing timing, music or voice)
#   ./build.sh video      clips -> animation -> check -> render -> poster (after changing text, colours, motion)
#   ./build.sh preview    open the composition in Hyperframes Studio
#   ./build.sh <step>...  any of: timeline music mix captions clips audiodata comp check render poster
#
#   QUALITY=draft ./build.sh render     faster, lower-quality render while iterating
set -euo pipefail
cd "$(dirname "$0")"
PY="$PWD/.venv/bin/python"
HF="npx --yes hyperframes@0.8.80"
HF_EXTRACT="${HF_EXTRACT:-$HOME/.claude/skills/hyperframes-creative/scripts/extract-audio-data.py}"

[ -x "$PY" ] || { echo "no .venv yet - run: python3.13 -m venv .venv && .venv/bin/pip install -r requirements.txt"; exit 1; }
step() { printf '\n== %s\n' "$1"; }

timeline()  { step "timeline";  "$PY" build/timeline.py; }
music()     { step "music (score stems)"; (cd music && "$PY" compose.py ../build/timeline.json out); }
mix()       { step "final mix"; "$PY" build/audio_mix.py; }
captions()  { step "captions"; "$PY" build/captions.py; }
clips()     { step "clips + screens"; "$PY" build/cut_clips.py; }
audiodata() {
  if [ -f "$HF_EXTRACT" ]; then
    step "audio-reactive data"
    "$PY" "$HF_EXTRACT" build/mix_layers/score_ducked.wav --fps 30 --bands 8 -o build/audio-data.json
  else
    step "audio-reactive data: helper not found, keeping build/audio-data.json"
  fi
}
comp()      { step "animation (composition/index.html)"; "$PY" build/make_composition.py; }
check()     { step "hyperframes check"; (cd composition && $HF check); }
render()    { step "render"; (cd composition && $HF render --quality "${QUALITY:-delivery}" --output ../brag.mp4); }
poster()    { step "poster"; "$PY" build/poster.py; }
preview()   { (cd composition && $HF preview); }

if [ $# -eq 0 ]; then set -- all; fi
for target in "$@"; do
  case "$target" in
    all)   timeline; music; mix; captions; clips; audiodata; comp; check; render; poster ;;
    sound) timeline; music; mix; audiodata ;;
    video) clips; comp; check; render; poster ;;
    timeline|music|mix|captions|clips|audiodata|comp|check|render|poster|preview) "$target" ;;
    *) echo "unknown step: $target"; exit 1 ;;
  esac
done
