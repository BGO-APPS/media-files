# Introducing KAI (introduction film)

This is a calm, 1:54 introduction film that covers all of KAI, not just app control. You can change and re-render everything from this folder. It follows the same system as `../KAI-Launch-Trailer`: one master clock, with the music, voice, sound effects and animation all built from it.

## The film

| Time | Scene | On screen | Narrator (Deepgram, voice Cole) |
|---|---|---|---|
| 0:00 | Intro | *Introducing* → **KAI.** wipe + green-dot ping → *Your autonomous AI companion.* | "Introducing… Kai." "Your autonomous AI companion." |
| 0:10 | Home | the phone arrives on the home screen | |
| 0:13 | Problem | 8 app tiles, one tapped per beat | "Every day, we open app after app, just to get simple things done." |
| 0:19 | Flip | **Stop opening apps. Start answering them.** | the same |
| 0:22 | 01 It speaks first | the mom-flowers chat, bubble by bubble | "Kai speaks first." |
| 0:32 | 02 It calls you | the incoming call, rings, Accept | "When something's urgent, it doesn't send a notification." "It calls you." |
| 0:42 | 03 Your day | brief chat → calendar (flight delayed, pickup moved) → reminders → all three: *Unified.* | "It briefs you every morning," "moves things when plans change," "and keeps every reminder." |
| 0:58 | 04 It remembers | the Riya chat: "Wait… how did you know that?" | "One memory, that never resets." |
| 1:10 | Turn | *And it doesn't just talk.* **It gets things done.** | the same |
| 1:14 | 05 WhatsApp | the real voice command, then KAI doing it → **SENT.** | |
| 1:26 | 05 Uber | the real voice command, then KAI doing it → **RIDE READY.** | |
| 1:39 | Finale | six chapter screens → *One companion, for everything.* | the same |
| 1:46 | Logo | **KAI.** + *Stop opening apps. Start answering them.* | "Kai." |

The music is an original score in D major at 75 BPM: piano, celesta, strings, a warm pad and a felt kick. The phone rings in key, the strings take the melody for Memory, and it all resolves on the logo.

## What's where

| File / folder | What it is |
|---|---|
| `brag.mp4` | the finished film (frame 0 is the poster) |
| `brag.jpg` | the poster / YouTube thumbnail |
| `share-copy.txt` | YouTube title, description with chapters, short post |
| `source/` | the 2 screen recordings (WhatsApp, Uber) and the 14 app screenshots |
| **`build/timeline.py`** | **the master clock**: scenes, narrator times, bubble times, demo shots |
| `music/compose.py` | the score: chords, melodies, arrangement, balance |
| `build/vo/make_takes.py` | narrator lines (Deepgram); the takes are saved beside it |
| `build/audio_mix.py` | the soundtrack: score + narrator + demo voices + sound effects; `PICKS` chooses the takes |
| `build/captions.py` | word timings of the two spoken commands (reused from the trailer's alignment) |
| `build/cut_clips.py` | frame-exact demo clips + the screens, sized for the phone |
| `build/make_composition.py` | writes the animated film, `composition/index.html` (bubble texts, screen geometry, styles) |

## Setup and rebuild

```bash
python3.13 -m venv .venv && .venv/bin/pip install -r requirements.txt   # once; also needs ffmpeg + fluidsynth + Node 22+
./build.sh              # everything
./build.sh sound video  # after changing timing, music or narrator picks
./build.sh video        # after changing text, colours or motion
./build.sh preview      # scrub it in Hyperframes Studio
QUALITY=draft ./build.sh render
```

## Common edits

| I want to change… | Edit this | Then run |
|---|---|---|
| a headline, bubble text, chapter name | `build/make_composition.py` (`BUBBLES`, the scene blocks) | `./build.sh video` |
| when something happens | `build/timeline.py` (`SECTIONS`, `NARRATOR`, `CHATS`) | `./build.sh` (everything) |
| the music | `music/compose.py` (`CHART`, `PHRASE1`, `MEMORY`...) | `./build.sh sound video` |
| a narrator line | `build/vo/make_takes.py` → `LINES`; run `DEEPGRAM_API_KEY=... ../../.venv/bin/python make_takes.py` in `build/vo/`, then set `PICKS` in `build/audio_mix.py` | `./build.sh sound video` |
| voice vs. music balance | `build/audio_mix.py` → `DUCK`, `SPEECH_OVER` | `./build.sh mix audiodata video` |
