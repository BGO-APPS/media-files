import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { WordWall } from "../components/WordWall";
import { FlashCut } from "../components/FlashCut";
import { LiveDot } from "../components/LiveDot";
import { KaiStamp } from "../components/KaiStamp";

// Day 5 — "Overwhelm -> Relief". Template: Pattern-Interrupt Word Wall.
// Dramatizes the "Relief" emotional hook from marketing.md §4 ("Stop
// holding your whole life in your head") — implied backstory is Ria
// oversleeping/forgetting an assignment or Dev's brain-dump chaos
// (Scenarios A/D). Extended to a full 10.2s: a second word-wall hit
// doubles the density-spike chaos before the relief cut, and three
// hard-cut Scenario D brain-dump lines ("Follow up Friday." / "Send the
// deck tonight." / "The demo Monday.") make "it remembers everything"
// concrete instead of abstract. fps 30, 1080x1920.
const BEAT_1_END = 27; // 0.0-0.9s: "STOP SCROLLING" pattern-interrupt caption on paper
const BEAT_2_END = 69; // 0.9-2.3s: FORGOT word wall, density-spike hold (42f)
const BEAT_2B_END = 111; // 2.3-3.7s: second word wall, MISSED — double pattern-interrupt (42f)
const BEAT_3_END = 135; // 3.7-4.5s: hard cut to black + flash, "KAI doesn't."
const BEAT_4_END = 165; // 4.5-5.5s: LiveDot + "It remembers everything."
const BEAT_4B_END = 201; // 5.5-6.7s: hard cut, "Follow up Friday."
const BEAT_4C_END = 240; // 6.7-8.0s: hard cut, "Send the deck tonight."
const BEAT_4D_END = 282; // 8.0-9.4s: hard cut, "The demo Monday."
const BEAT_5_END = 360; // 9.4-12.0s: KaiStamp outro — extended hold (VO track is 294 frames / 9.8s, finishes comfortably)

export const day5DurationInFrames = BEAT_5_END;
export const day5Fps = 30;
export const day5Width = 1080;
export const day5Height = 1920;

export const Day5Overwhelm: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: kai.paper, fontFamily }}>
      <Audio src={staticFile("audio/day5.mp3")} />
      {/* Beat 1: pattern-interrupt caption, ink-black on paper */}
      <Sequence from={0} durationInFrames={BEAT_1_END}>
        <AbsoluteFill
          style={{
            background: kai.paper,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop>
            <div
              style={{
                fontSize: 76,
                fontWeight: 700,
                color: kai.ink,
                textAlign: "center",
                letterSpacing: -1.5,
              }}
            >
              STOP SCROLLING
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 2: FORGOT word wall — the hook. Edge-to-edge density spike, no padding wrapper. */}
      <Sequence from={BEAT_1_END} durationInFrames={BEAT_2_END - BEAT_1_END}>
        <WordWall word="FORGOT" rows={11} startFrame={0} bg={kai.paper} color={kai.ink} />
      </Sequence>

      {/* Beat 2b: second word wall, different word — double pattern-interrupt hard
          cut into more chaos before the relief cut, same treatment as Beat 2. */}
      <Sequence from={BEAT_2_END} durationInFrames={BEAT_2B_END - BEAT_2_END}>
        <WordWall word="MISSED" rows={11} startFrame={0} bg={kai.paper} color={kai.ink} />
      </Sequence>

      {/* Beat 3: hard cut to black, flash punch, payoff line */}
      <Sequence from={BEAT_2B_END} durationInFrames={BEAT_3_END - BEAT_2B_END}>
        <AbsoluteFill
          style={{
            background: kai.black,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop from="none">
            <div
              style={{
                fontSize: 72,
                fontWeight: 700,
                color: kai.paper,
                textAlign: "center",
              }}
            >
              KAI doesn&apos;t.
            </div>
          </WordPop>
          <FlashCut atFrame={0} />
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4: relief line, LiveDot as the tiny functional accent */}
      <Sequence from={BEAT_3_END} durationInFrames={BEAT_4_END - BEAT_3_END}>
        <AbsoluteFill
          style={{
            background: kai.black,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop>
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              <LiveDot size={20} />
              <div
                style={{
                  fontSize: 52,
                  fontWeight: 700,
                  color: kai.paper,
                  textAlign: "center",
                  maxWidth: 820,
                }}
              >
                It remembers everything.
              </div>
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4b: Scenario D brain-dump, hard cut #1 — makes "remembers everything" concrete */}
      <Sequence from={BEAT_4_END} durationInFrames={BEAT_4B_END - BEAT_4_END}>
        <AbsoluteFill
          style={{
            background: kai.black,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop>
            <div
              style={{
                fontSize: 64,
                fontWeight: 700,
                color: kai.paper,
                textAlign: "center",
                maxWidth: 820,
              }}
            >
              Follow up Friday.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4c: Scenario D brain-dump, hard cut #2 */}
      <Sequence from={BEAT_4B_END} durationInFrames={BEAT_4C_END - BEAT_4B_END}>
        <AbsoluteFill
          style={{
            background: kai.black,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop>
            <div
              style={{
                fontSize: 64,
                fontWeight: 700,
                color: kai.paper,
                textAlign: "center",
                maxWidth: 820,
              }}
            >
              Send the deck tonight.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 4d: Scenario D brain-dump, hard cut #3 */}
      <Sequence from={BEAT_4C_END} durationInFrames={BEAT_4D_END - BEAT_4C_END}>
        <AbsoluteFill
          style={{
            background: kai.black,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <WordPop>
            <div
              style={{
                fontSize: 64,
                fontWeight: 700,
                color: kai.paper,
                textAlign: "center",
                maxWidth: 820,
              }}
            >
              The demo Monday.
            </div>
          </WordPop>
        </AbsoluteFill>
      </Sequence>

      {/* Beat 5: stamp outro */}
      <Sequence from={BEAT_4D_END} durationInFrames={BEAT_5_END - BEAT_4D_END}>
        <KaiStamp startFrame={0} tagline="Stop holding your whole life in your head." />
      </Sequence>
    </AbsoluteFill>
  );
};
