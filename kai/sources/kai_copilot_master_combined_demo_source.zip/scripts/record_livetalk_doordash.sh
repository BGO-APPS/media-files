#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
echo "[RECORD] record_livetalk_doordash: INFO - Cleaning up old recording..."
adb -s $DEVICE shell rm -f /sdcard/livetalk_doordash.mp4

echo "[RECORD] record_livetalk_doordash: INFO - Waking screen..."
adb -s $DEVICE shell input keyevent 224

echo "[RECORD] record_livetalk_doordash: INFO - Starting screenrecord (time-limit 14s)..."
adb -s $DEVICE shell screenrecord --time-limit 14 /sdcard/livetalk_doordash.mp4 &
RECORD_PID=$!

sleep 1.5

echo "[RECORD] record_livetalk_doordash: INFO - Launching LiveTalkDemoScreen with demo_target doordash..."
adb -s $DEVICE shell am force-stop com.gokul00060.gnxtour
adb -s $DEVICE shell am start -n com.gokul00060.gnxtour/com.gokul00060.gnxmobile.MainActivity --ez start_live_talk true --es demo_target doordash

echo "[RECORD] record_livetalk_doordash: INFO - Waiting for screenrecord to finish..."
wait $RECORD_PID || true

echo "[RECORD] record_livetalk_doordash: INFO - Pulling recording..."
adb -s $DEVICE pull /sdcard/livetalk_doordash.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_livetalk_doordash.mp4

echo "[RECORD] record_livetalk_doordash: INFO - Done! Saved to raw_livetalk_doordash.mp4"
