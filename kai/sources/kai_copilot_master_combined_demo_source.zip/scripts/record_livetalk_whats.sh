#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
ADB="/opt/homebrew/share/android-commandlinetools/platform-tools/adb -s $DEVICE"

echo "[RECORD] record_livetalk_whats: INFO - Cleaning up old recording..."
$ADB shell rm -f /sdcard/livetalk_whats.mp4

echo "[RECORD] record_livetalk_whats: INFO - Waking screen..."
$ADB shell input keyevent 224
$ADB shell wm dismiss-keyguard
$ADB shell input keyevent 82
$ADB shell input swipe 540 1800 540 600 200
sleep 1.0

echo "[RECORD] record_livetalk_whats: INFO - Starting screenrecord (time-limit 16s)..."
$ADB shell screenrecord --time-limit 16 /sdcard/livetalk_whats.mp4 &
RECORD_PID=$!

sleep 1.5

echo "[RECORD] record_livetalk_whats: INFO - Launching LiveTalkDemoScreen with demo_target whatsapp..."
$ADB shell am force-stop com.gokul00060.gnxtour
$ADB shell am start -n com.gokul00060.gnxtour/com.gokul00060.gnxmobile.MainActivity --ez start_live_talk true --es demo_target whatsapp

echo "[RECORD] record_livetalk_whats: INFO - Waiting for screenrecord to finish..."
wait $RECORD_PID || true

echo "[RECORD] record_livetalk_whats: INFO - Pulling recording..."
$ADB pull /sdcard/livetalk_whats.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_livetalk_whats.mp4

echo "[RECORD] record_livetalk_whats: INFO - Done! Saved to raw_livetalk_whats.mp4"
