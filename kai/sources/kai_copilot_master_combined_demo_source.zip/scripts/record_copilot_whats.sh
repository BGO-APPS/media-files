#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
ADB="/opt/homebrew/share/android-commandlinetools/platform-tools/adb -s $DEVICE"

echo "[RECORD] record_copilot_whats: INFO - Disabling wifi and mobile data to block all ads..."
$ADB shell svc wifi disable
$ADB shell svc data disable

echo "[RECORD] record_copilot_whats: INFO - Waking device and preparing screen..."
$ADB shell input keyevent 224
$ADB shell wm dismiss-keyguard
$ADB shell input keyevent 82
$ADB shell rm -f /sdcard/copilot_whats.mp4

echo "[RECORD] record_copilot_whats: INFO - Resetting WhatsFake to fresh Chats list..."
$ADB shell am force-stop com.star.fakechatforwhatsapp
$ADB shell monkey -p com.star.fakechatforwhatsapp -c android.intent.category.LAUNCHER 1
sleep 2.2
# Tap "Continue Offline" dialog if present
$ADB shell input tap 351 1355
sleep 1.0
# Return to home screen so KAI Copilot launches fresh
$ADB shell input keyevent 3
sleep 1.0

echo "[RECORD] record_copilot_whats: INFO - Starting screenrecord (time-limit 20s)..."
$ADB shell screenrecord --time-limit 20 /sdcard/copilot_whats.mp4 &
RECORD_PID=$!

sleep 1.2

echo "[RECORD] record_copilot_whats: INFO - Launching KAI Copilot with run_whats_fake_demo..."
$ADB shell am start -n com.gokul00060.gnxmobile/com.gokul00060.gnxmobile.MainActivity --ez run_whats_fake_demo true

echo "[RECORD] record_copilot_whats: INFO - Waiting for WhatsFake Copilot demo to complete..."
wait $RECORD_PID || true

echo "[RECORD] record_copilot_whats: INFO - Pulling recording..."
$ADB pull /sdcard/copilot_whats.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_copilot_whats.mp4

echo "[RECORD] record_copilot_whats: INFO - Done! Saved to raw_copilot_whats.mp4"
