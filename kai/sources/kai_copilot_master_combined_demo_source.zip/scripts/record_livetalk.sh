#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
echo "[RECORD] record_livetalk: INFO - Cleaning up old recording..."
adb -s $DEVICE shell rm -f /sdcard/livetalk_demo.mp4

echo "[RECORD] record_livetalk: INFO - Waking screen..."
adb -s $DEVICE shell input keyevent 224

echo "[RECORD] record_livetalk: INFO - Starting screenrecord (time-limit 17s)..."
adb -s $DEVICE shell screenrecord --time-limit 17 /sdcard/livetalk_demo.mp4 &
RECORD_PID=$!

sleep 1.5

echo "[RECORD] record_livetalk: INFO - Launching LiveTalkDemoScreen..."
adb -s $DEVICE shell am force-stop com.gokul00060.gnxtour
adb -s $DEVICE shell am start -n com.gokul00060.gnxtour/com.gokul00060.gnxmobile.MainActivity --ez start_live_talk true

echo "[RECORD] record_livetalk: INFO - Waiting for screenrecord to finish..."
wait $RECORD_PID || true

echo "[RECORD] record_livetalk: INFO - Pulling recording..."
adb -s $DEVICE pull /sdcard/livetalk_demo.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_livetalk.mp4

echo "[RECORD] record_livetalk: INFO - Done! Saved to raw_livetalk.mp4"
