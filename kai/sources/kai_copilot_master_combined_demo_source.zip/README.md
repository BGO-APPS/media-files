# KAI Copilot Master Combined Demo — Automation Source Code

Contains complete device screen recording hooks, subtitle styling, and copilot execution plans.
