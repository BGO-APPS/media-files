# Creative Prompt & Synthesis Pipeline: Creator Smartphone Discussion

## Generation Prompt
```
Creator actively uses Android smartphone demonstrating KAI copilot auto-booking rides and ordering food.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
