# Creative Prompt & Synthesis Pipeline: Creator Speaking Into Camera

## Generation Prompt
```
Creator speaks naturally into camera discussing hands-free AI phone control, shot at 1080p 60fps cinematic shallow depth of field.
```

## Target Spec
- Resolution: 1080x1920 (9:16 Vertical)
- Architecture: Generative AI Video Model (Runway / Midjourney) + Audio Bed
