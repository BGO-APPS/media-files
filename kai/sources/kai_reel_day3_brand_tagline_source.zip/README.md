# Remotion React Composition: Day 3: Brand Tagline

Built with Remotion React video engine. Install dependencies with `npm install` and run `npm start`.
