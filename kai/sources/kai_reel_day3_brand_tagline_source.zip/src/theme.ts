// KAI "Ink & Paper" design tokens — source of truth: /Users/skgokulbarath/Documents/LAMx/GNX/marketing.md §2
// Do not add colors here. Green/red are functional accents only — never a wash.

export const kai = {
  black: "#050505", // deepest surfaces
  ink: "#0E0E10", // headlines, buttons, primary fills
  steel: "#8A8A8E", // secondary text
  silver: "#C6C6C8", // tertiary text
  paper: "#F6F6F4", // app background, warm off-white
  card: "#FFFFFF",
  liveGreen: "#30D158", // ONLY the "online" pulse dot / live moments
  dangerRed: "#FF453A", // ONLY end-call / delete drama beats
} as const;

// Archivo Black / Space Grotesk / Inter Tight vibe per marketing.md.
// Actual font loading (with weights) happens in loadFont.ts — import
// `fontFamily` from there in any component that renders text, not from here.
export { fontFamily } from "./loadFont";

export const spring = {
  // snappy and springy, never slow or floaty — marketing.md §2 motion rule
  damping: 12,
  mass: 0.6,
  stiffness: 200,
};
