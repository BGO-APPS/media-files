import "./index.css";
import { Composition } from "remotion";
import {
  Day1TheCall,
  day1DurationInFrames,
  day1Fps,
  day1Width,
  day1Height,
} from "./days/Day1TheCall";
import {
  Day2Memory,
  day2DurationInFrames,
  day2Fps,
  day2Width,
  day2Height,
} from "./days/Day2Memory";
import {
  Day3Tagline,
  day3DurationInFrames,
  day3Fps,
  day3Width,
  day3Height,
} from "./days/Day3Tagline";
import {
  Day4HandsFull,
  day4DurationInFrames,
  day4Fps,
  day4Width,
  day4Height,
} from "./days/Day4HandsFull";
import {
  Day5Overwhelm,
  day5DurationInFrames,
  day5Fps,
  day5Width,
  day5Height,
} from "./days/Day5Overwhelm";
import {
  Day6FeatureCarousel,
  day6DurationInFrames,
  day6Fps,
  day6Width,
  day6Height,
} from "./days/Day6FeatureCarousel";
import {
  Day7Intervention,
  day7DurationInFrames,
  day7Fps,
  day7Width,
  day7Height,
} from "./days/Day7Intervention";
import {
  HeroTheSave,
  heroDurationInFrames,
  heroFps,
  heroWidth,
  heroHeight,
} from "./days/HeroTheSave";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="Day1-TheCall"
        component={Day1TheCall}
        durationInFrames={day1DurationInFrames}
        fps={day1Fps}
        width={day1Width}
        height={day1Height}
      />
      <Composition
        id="Day2-Memory"
        component={Day2Memory}
        durationInFrames={day2DurationInFrames}
        fps={day2Fps}
        width={day2Width}
        height={day2Height}
      />
      <Composition
        id="Day3-Tagline"
        component={Day3Tagline}
        durationInFrames={day3DurationInFrames}
        fps={day3Fps}
        width={day3Width}
        height={day3Height}
      />
      <Composition
        id="Day4-HandsFull"
        component={Day4HandsFull}
        durationInFrames={day4DurationInFrames}
        fps={day4Fps}
        width={day4Width}
        height={day4Height}
      />
      <Composition
        id="Day5-Overwhelm"
        component={Day5Overwhelm}
        durationInFrames={day5DurationInFrames}
        fps={day5Fps}
        width={day5Width}
        height={day5Height}
      />
      <Composition
        id="Day6-FeatureCarousel"
        component={Day6FeatureCarousel}
        durationInFrames={day6DurationInFrames}
        fps={day6Fps}
        width={day6Width}
        height={day6Height}
      />
      <Composition
        id="Day7-Intervention"
        component={Day7Intervention}
        durationInFrames={day7DurationInFrames}
        fps={day7Fps}
        width={day7Width}
        height={day7Height}
      />
      <Composition
        id="Hero-TheSave"
        component={HeroTheSave}
        durationInFrames={heroDurationInFrames}
        fps={heroFps}
        width={heroWidth}
        height={heroHeight}
      />
    </>
  );
};
