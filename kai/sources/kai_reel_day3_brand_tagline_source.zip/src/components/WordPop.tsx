import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";

// Punchier than KaiStamp's settle-pop — used for every headline beat across
// Days 2-7 to give the week a consistent, snappy motion signature per the
// user's "more motion graphics, that's the hook" note. Overshoots past
// 100% before settling (bouncier spring than Day 1's card, which needed to
// look stable, not toy-like).
export const WordPop: React.FC<{
  children: React.ReactNode;
  delay?: number;
  from?: "bottom" | "top" | "none";
  style?: React.CSSProperties;
}> = ({ children, delay = 0, from = "bottom", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - delay);
  const pop = spring({
    frame: local,
    fps,
    config: { damping: 9, mass: 0.5, stiffness: 260 },
  });
  const slideOffset = from === "none" ? 0 : (1 - pop) * (from === "bottom" ? 40 : -40);
  return (
    <div
      style={{
        transform: `translateY(${slideOffset}px) scale(${0.7 + pop * 0.3})`,
        opacity: Math.min(1, local / 3),
        ...style,
      }}
    >
      {children}
    </div>
  );
};
