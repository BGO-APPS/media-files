import React from "react";
import { interpolate, useCurrentFrame } from "remotion";

// One-frame white impact flash right at a hard cut — a cheap, common
// motion-graphics trick that sells a "punch" beat (used on Day 3's bg
// color-flip and Day 5's payoff cut). Not in any single reference clip
// directly but consistent with the "hard cuts dominate" + "elastic/snappy"
// motion rules in marketing.md §2 and the teardown's emphasis devices.
export const FlashCut: React.FC<{ atFrame: number; fadeFrames?: number }> = ({
  atFrame,
  fadeFrames = 4,
}) => {
  const frame = useCurrentFrame();
  const local = frame - atFrame;
  if (local < 0 || local > fadeFrames) return null;
  const opacity = interpolate(local, [0, fadeFrames], [0.9, 0], { extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", inset: 0, background: "#FFFFFF", opacity }} />
  );
};
