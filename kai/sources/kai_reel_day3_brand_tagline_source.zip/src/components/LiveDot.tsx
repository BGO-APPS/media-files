import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { kai } from "../theme";

// The ONLY recurring color accent per marketing.md §2 — a single pulsing
// green dot marking a "live/acting now" beat. Never used decoratively.
export const LiveDot: React.FC<{ size?: number }> = ({ size = 14 }) => {
  const frame = useCurrentFrame();
  const pulse = interpolate(frame % 40, [0, 20, 40], [0.6, 1, 0.6], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        borderRadius: "50%",
        background: kai.liveGreen,
        opacity: pulse,
        boxShadow: `0 0 ${size * pulse}px ${kai.liveGreen}55`,
      }}
    />
  );
};
