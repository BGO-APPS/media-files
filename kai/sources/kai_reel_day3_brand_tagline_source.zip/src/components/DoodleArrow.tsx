import React from "react";

// Hand-drawn arrow pointing at a UI affordance — confirmed device in
// motionbyrohit reference clip (agent-chat/02-hook-style-teardown.md #9).
export const DoodleArrow: React.FC<{
  progress: number; // 0-1
  color: string;
  flip?: boolean;
}> = ({ progress, color, flip = false }) => {
  const pathLength = 140;
  return (
    <svg
      width={90}
      height={70}
      viewBox="0 0 90 70"
      style={{ transform: flip ? "scaleX(-1)" : undefined, overflow: "visible" }}
    >
      <path
        d="M6 6 C 20 30, 35 45, 55 50"
        stroke={color}
        strokeWidth={4}
        strokeLinecap="round"
        fill="none"
        strokeDasharray={pathLength}
        strokeDashoffset={pathLength * (1 - progress)}
      />
      <path
        d="M55 50 L38 46 M55 50 L47 34"
        stroke={color}
        strokeWidth={4}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        opacity={progress > 0.85 ? 1 : 0}
      />
    </svg>
  );
};
