import React from "react";
import { OffthreadVideo, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { kai, fontFamily } from "../theme";
import { LiveDot } from "./LiveDot";

// "Real UI screenshots in tilted panels" — explicit DO rule, marketing.md §2.
// Template: Screenshot-in-Card, agent-chat/02-hook-style-teardown.md #3.
//
// videoSrc is undefined until you record the real incoming-call UI on your
// phone and drop it at app/public/call-screen.mp4 (see agent-chat/03-...
// calendar file, "Before you render anything"). Until then this renders an
// honest mock so the composition is previewable — swap MOCK_MODE to false
// once the real file exists.
const MOCK_MODE = true;

export const ScreenshotCard: React.FC<{
  startFrame: number;
  tiltDeg?: number;
  videoAsset?: string; // staticFile name, e.g. "call-screen.mp4" — omit to use the mock
  mock?: React.ReactNode; // defaults to MockCallScreen; pass a different mock for non-call UI (e.g. Day 4's chat screen)
}> = ({ startFrame, tiltDeg = -4, videoAsset, mock }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - startFrame);

  const pop = spring({
    frame: local,
    fps,
    config: { damping: 11, mass: 0.7, stiffness: 190 },
  });
  const scale = 0.6 + pop * 0.4;
  const translateY = (1 - pop) * 60;

  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "50%",
        width: 340,
        height: 604, // 9:19.5-ish phone aspect, matches a real call-screen capture
        borderRadius: 32,
        overflow: "hidden",
        background: kai.black,
        boxShadow: "0 30px 60px rgba(0,0,0,0.35)",
        transform: `translate(-50%, calc(-50% + ${translateY}px)) rotate(${tiltDeg}deg) scale(${scale})`,
      }}
    >
      {MOCK_MODE || !videoAsset ? (
        mock ?? <MockCallScreen />
      ) : (
        <OffthreadVideo src={staticFile(videoAsset)} style={{ width: "100%", height: "100%", objectFit: "cover" }} muted />
      )}
    </div>
  );
};

// Placeholder only — replace by setting MOCK_MODE = false above once the
// real recording exists. Deliberately looks like a real incoming-call
// screen (not a "coming soon" placeholder) so timing/composition can be
// judged accurately in preview.
const MockCallScreen: React.FC = () => {
  const frame = useCurrentFrame();
  const ringPulse = 1 + 0.05 * Math.sin(frame / 6);
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        background: kai.black,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "48px 0 40px",
      }}
    >
      <div style={{ textAlign: "center" }}>
        <div style={{ fontFamily, fontSize: 16, color: kai.steel, marginBottom: 8 }}>
          incoming call
        </div>
        <div
          style={{
            fontFamily,
            fontWeight: 700,
            fontSize: 44,
            color: kai.paper,
            transform: `scale(${ringPulse})`,
          }}
        >
          KAI
        </div>
      </div>
      <div
        style={{
          width: 84,
          height: 84,
          borderRadius: "50%",
          background: kai.liveGreen,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <LiveDot size={0} />
        <svg width={32} height={32} viewBox="0 0 24 24" fill={kai.black}>
          <path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.9 21 3 13.1 3 3.5c0-.6.4-1 1-1H7.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.3 1.1L6.6 10.8z" />
        </svg>
      </div>
    </div>
  );
};
