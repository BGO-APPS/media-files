import React from "react";

// Hand-drawn squiggle underline — confirmed device in 2 of 7 reference clips
// (agent-chat/02-hook-style-teardown.md, points 5 & 9). Draws itself on via
// stroke-dasharray, never a static pre-rendered image.
export const DoodleUnderline: React.FC<{
  progress: number; // 0-1, how much of the squiggle has "drawn" in
  color: string;
  width?: number;
}> = ({ progress, color, width = 180 }) => {
  const pathLength = 220;
  return (
    <svg
      width={width}
      height={24}
      viewBox="0 0 200 24"
      style={{ overflow: "visible" }}
    >
      <path
        d="M4 14 C 30 4, 50 20, 78 10 S 130 2, 160 14 S 190 20, 196 10"
        stroke={color}
        strokeWidth={5}
        strokeLinecap="round"
        fill="none"
        strokeDasharray={pathLength}
        strokeDashoffset={pathLength * (1 - progress)}
      />
    </svg>
  );
};
