import React from "react";
import { useCurrentFrame } from "remotion";

// Small flat hand-drawn-style line icons, all monochrome (currentColor),
// never photoreal/3D per marketing.md §2's explicit ban on "floating
// glowing phone" style renders. Used by Days 4 and 6.

export const PhoneRingIcon: React.FC<{ color: string; size?: number }> = ({
  color,
  size = 64,
}) => {
  const frame = useCurrentFrame();
  const wiggle = Math.sin(frame / 4) * 6;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <g style={{ transform: `rotate(${wiggle}deg)`, transformOrigin: "32px 40px" }}>
        <rect x="20" y="14" width="24" height="40" rx="6" stroke={color} strokeWidth={4} />
        <circle cx="32" cy="46" r="1.5" fill={color} />
      </g>
      <path
        d="M10 20 C 10 12, 16 8, 22 8"
        stroke={color}
        strokeWidth={3}
        strokeLinecap="round"
        fill="none"
        opacity={0.7}
      />
      <path
        d="M4 24 C 4 10, 14 2, 26 2"
        stroke={color}
        strokeWidth={3}
        strokeLinecap="round"
        fill="none"
        opacity={0.4}
      />
    </svg>
  );
};

export const BrainIcon: React.FC<{ color: string; size?: number }> = ({ color, size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path
      d="M24 10c-7 0-12 5-12 11 0 3 1 5 3 7-2 2-3 4-3 7 0 6 5 11 12 11h8c7 0 12-5 12-11 0-3-1-5-3-7 2-2 3-4 3-7 0-6-5-11-12-11"
      stroke={color}
      strokeWidth={4}
      strokeLinejoin="round"
      fill="none"
    />
    <path d="M32 10v36" stroke={color} strokeWidth={3} opacity={0.6} />
  </svg>
);

export const CalendarIcon: React.FC<{ color: string; size?: number }> = ({
  color,
  size = 64,
}) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <rect x="8" y="14" width="48" height="42" rx="6" stroke={color} strokeWidth={4} />
    <path d="M8 26h48" stroke={color} strokeWidth={4} />
    <path d="M20 8v12M44 8v12" stroke={color} strokeWidth={4} strokeLinecap="round" />
    <circle cx="22" cy="38" r="3" fill={color} />
    <circle cx="34" cy="38" r="3" fill={color} />
  </svg>
);

export const BoltIcon: React.FC<{ color: string; size?: number }> = ({ color, size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path d="M34 4 12 36h14l-4 24 26-34H34l4-22z" stroke={color} strokeWidth={4} strokeLinejoin="round" fill="none" />
  </svg>
);
