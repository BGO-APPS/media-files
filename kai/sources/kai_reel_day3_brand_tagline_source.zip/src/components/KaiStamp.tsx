import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { kai, fontFamily } from "../theme";
import { DoodleUnderline } from "./DoodleUnderline";
import { LiveDot } from "./LiveDot";

// End-card used on every Reel per agent-chat/02-hook-style-teardown.md
// point 9 — "every video ends on a distinct stamp/end-card." `ctaDelay` is
// optional (defaults to no CTA, so every other day's stamp is unaffected):
// when set, a "DOWNLOAD NOW / link in bio" line pops in `ctaDelay` local
// frames after the stamp mounts, timed to land right as that day's VO
// narration finishes rather than sitting on a static hold.
export const KaiStamp: React.FC<{
  startFrame: number;
  tagline?: string;
  ctaDelay?: number;
}> = ({ startFrame, tagline, ctaDelay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - startFrame);

  const pop = spring({
    frame: local,
    fps,
    config: { damping: 12, mass: 0.6, stiffness: 200 },
  });
  const underlineProgress = Math.min(1, Math.max(0, (local - 8) / 14));

  const ctaLocal = ctaDelay !== undefined ? Math.max(0, local - ctaDelay) : 0;
  const ctaPop = spring({
    frame: ctaLocal,
    fps,
    config: { damping: 14, mass: 0.5, stiffness: 220 },
  });

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: kai.black,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 14,
        opacity: Math.min(1, local / 6),
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          transform: `scale(${0.85 + pop * 0.15})`,
        }}
      >
        <div
          style={{
            fontFamily,
            fontWeight: 700,
            fontSize: 84,
            color: kai.paper,
            letterSpacing: -2,
          }}
        >
          KAI
        </div>
        <LiveDot size={16} />
      </div>
      <DoodleUnderline progress={underlineProgress} color={kai.paper} width={140} />
      {tagline ? (
        <div
          style={{
            fontFamily,
            fontWeight: 500,
            fontSize: 26,
            color: kai.steel,
            marginTop: 6,
          }}
        >
          {tagline}
        </div>
      ) : null}
      {ctaDelay !== undefined && local >= ctaDelay ? (
        <div
          style={{
            marginTop: 22,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 6,
            opacity: Math.min(1, ctaLocal / 6),
            transform: `translateY(${(1 - ctaPop) * 14}px)`,
          }}
        >
          <div
            style={{
              fontFamily,
              fontWeight: 700,
              fontSize: 30,
              color: kai.paper,
              letterSpacing: -0.5,
            }}
          >
            DOWNLOAD NOW · FREE
          </div>
          <div style={{ fontFamily, fontWeight: 500, fontSize: 20, color: kai.steel }}>
            link in bio
          </div>
        </div>
      ) : null}
    </div>
  );
};
