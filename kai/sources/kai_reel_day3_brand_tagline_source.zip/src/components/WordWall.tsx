import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { fontFamily } from "../theme";

// Full-bleed repeated-word density spike — Template 4 in
// agent-chat/02-hook-style-teardown.md, confirmed device from
// kreativ_ui's "TODAY" x11 wall. Alternating slide-in per row (not a
// static appear) per the "more motion graphics" note — each row still
// lands within ~6 frames so the density-spike read isn't lost.
export const WordWall: React.FC<{
  word: string;
  rows?: number;
  startFrame: number;
  bg: string;
  color: string;
}> = ({ word, rows = 11, startFrame, bg, color }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - startFrame);

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: bg,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-evenly",
        alignItems: "center",
        overflow: "hidden",
      }}
    >
      {Array.from({ length: rows }).map((_, i) => {
        const rowDelay = i * 1.2;
        const rowLocal = Math.max(0, local - rowDelay);
        const pop = spring({
          frame: rowLocal,
          fps,
          config: { damping: 16, mass: 0.4, stiffness: 240 },
        });
        const fromLeft = i % 2 === 0;
        const slide = (1 - pop) * (fromLeft ? -140 : 140);
        return (
          <div
            key={i}
            style={{
              fontFamily,
              fontWeight: 700,
              fontSize: 72,
              lineHeight: 1,
              color,
              letterSpacing: -1,
              transform: `translateX(${slide}px)`,
              opacity: Math.min(1, rowLocal / 3),
              whiteSpace: "nowrap",
            }}
          >
            {word}
          </div>
        );
      })}
    </div>
  );
};
