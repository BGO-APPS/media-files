import React from "react";
import { useCurrentFrame } from "remotion";
import { kai } from "../theme";

// Character-by-character reveal + blinking caret — Template 5 in
// agent-chat/02-hook-style-teardown.md ("mimics an incoming chat message
// rather than a movie-trailer caption"). Used by Day 2 and Day 7.
export const TypewriterLine: React.FC<{
  text: string;
  startFrame: number;
  charsPerFrame?: number; // higher = faster typing
  fontSize?: number;
  color?: string;
  weight?: number;
}> = ({
  text,
  startFrame,
  charsPerFrame = 0.9,
  fontSize = 40,
  color = kai.paper,
  weight = 500,
}) => {
  const frame = useCurrentFrame();
  const local = Math.max(0, frame - startFrame);
  const shown = Math.min(text.length, Math.floor(local * charsPerFrame));
  const doneTyping = shown >= text.length;
  const caretOn = Math.floor(frame / 12) % 2 === 0;

  return (
    <div style={{ fontSize, fontWeight: weight, color, whiteSpace: "pre-wrap" }}>
      {text.slice(0, shown)}
      {(!doneTyping || caretOn) && (
        <span
          style={{
            display: "inline-block",
            width: fontSize * 0.08,
            height: fontSize * 0.9,
            background: color,
            marginLeft: 4,
            transform: "translateY(2px)",
            opacity: doneTyping ? (caretOn ? 1 : 0) : 1,
          }}
        />
      )}
    </div>
  );
};
