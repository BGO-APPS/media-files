import React from "react";

// Hard-edge circle-mask wipe — Template 7 in
// agent-chat/02-hook-style-teardown.md. Caller owns the timeline: render
// Scene A, then Scene B UNDERNEATH this overlay (absolutely positioned,
// same stacking context), and drive `coverAmount` 0→1→0 across frames.
// At coverAmount=1 the circle fully covers a 1080x1920 frame from center
// (diameter 2400px clears the frame diagonal with margin).
export const HardWipe: React.FC<{ coverAmount: number; color: string }> = ({
  coverAmount,
  color,
}) => {
  if (coverAmount <= 0) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "50%",
        width: 2400,
        height: 2400,
        borderRadius: "50%",
        background: color,
        transform: `translate(-50%, -50%) scale(${coverAmount})`,
      }}
    />
  );
};

// Helper: given the wipe's local frame and total duration, returns a
// cover→hold→recede curve (0 → 1 → 1 → 0). coverFrames/recedeFrames control
// how snappy the wipe itself is; the gap between is the "fully covered"
// hold where the caller should swap Scene A for Scene B underneath.
export const wipeCoverAmount = (
  local: number,
  coverFrames: number,
  holdFrames: number,
  recedeFrames: number,
): number => {
  if (local < coverFrames) return local / coverFrames;
  if (local < coverFrames + holdFrames) return 1;
  if (local < coverFrames + holdFrames + recedeFrames) {
    return 1 - (local - coverFrames - holdFrames) / recedeFrames;
  }
  return 0;
};
