import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { kai } from "../theme";

// Rounded card bubble that pops in behind a TypewriterLine — turns the
// typewriter beat into a real chat-message visual instead of bare text on
// black. Monochrome only (Card white on Black bg), per marketing.md §2.
export const ChatBubble: React.FC<{
  startFrame: number;
  align?: "left" | "right";
  children: React.ReactNode;
}> = ({ startFrame, align = "left", children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - startFrame);
  const pop = spring({ frame: local, fps, config: { damping: 14, mass: 0.5, stiffness: 220 } });

  return (
    <div
      style={{
        display: "flex",
        justifyContent: align === "left" ? "flex-start" : "flex-end",
        width: "100%",
      }}
    >
      <div
        style={{
          background: kai.card,
          borderRadius: 22,
          padding: "18px 26px",
          maxWidth: "82%",
          transform: `scale(${0.75 + pop * 0.25})`,
          transformOrigin: align === "left" ? "left center" : "right center",
          opacity: Math.min(1, local / 4),
        }}
      >
        {children}
      </div>
    </div>
  );
};
