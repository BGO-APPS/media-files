import { loadFont } from "@remotion/google-fonts/SpaceGrotesk";

// Bold condensed grotesque per marketing.md §2 ("Archivo Black / Space
// Grotesk / Inter Tight vibe"). Weights 500/700 cover the thin/bold
// emphasis-line device from agent-chat/02-hook-style-teardown.md #3.
export const { fontFamily } = loadFont("normal", { weights: ["500", "700"] });
