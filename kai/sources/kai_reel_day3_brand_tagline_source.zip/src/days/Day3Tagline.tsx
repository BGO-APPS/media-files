import React from "react";
import { AbsoluteFill, Audio, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { kai, fontFamily } from "../theme";
import { WordPop } from "../components/WordPop";
import { FlashCut } from "../components/FlashCut";
import { LiveDot } from "../components/LiveDot";
import { KaiStamp } from "../components/KaiStamp";

// Day 3 — "Tagline Punch". Template: Build-The-Sentence — word-by-word
// kinetic-typography accumulation ending in a hard background color-flip
// punch beat. Primary tagline framing per marketing.md §3 USP / Ad 3 concept:
// "ChatGPT waits. KAI comes to you." fps 30, 1080x1920.
//
// The full Ad 3 concept is a comparison ("Left: a chat app sitting silent,
// cursor blinking, waiting. Right: KAI ringing, nudging, checking in through
// a person's day.") — the reel is a single vertical column, not a literal
// split screen, so the comparison plays sequentially instead: first the
// "waiting" side (INTRO_* beats below), then the hard cut into "KAI" and the
// rest of the original punch sequence.

// --- Intro: the "waiting" side of the comparison, played first -----------
// Same Paper bg / Ink kinetic-typography treatment as the rest of the reel.
// Three hard-cut beats dramatizing the dead-app experience; the third one
// lingers noticeably longer than the first two so "...then you wait." reads
// as an actual (deliberate) wait, not just another quick beat.
const INTRO_A_END = 36; // 0.0-1.2s: "You open an app."
const INTRO_B_END = 72; // 1.2-2.4s: "You type a question."
const INTRO_C_END = 117; // 2.4-3.9s: "...then you wait." (1.5s hold — the wait)
const INTRO_END = INTRO_C_END;

// --- Original punch sequence, unchanged, just pushed later by INTRO_END --
const BEAT_1_END = INTRO_END + 21; // +0.0-0.7s: "KAI" scale-pops in, dead center
const BEAT_2_END = INTRO_END + 45; // +0.7-1.5s: hard cut -> "doesn't wait."
const BEAT_3_END = INTRO_END + 69; // +1.5-2.3s: hard cut -> "It calls." + live dot
const PUNCH_FRAME = BEAT_3_END; // the hard cut instant: bg flips paper -> black
// +2.3-3.2s: "You." lands with a big elastic overshoot, then holds on it
// (extended a couple extra beats past the original hold so the payoff has
// real weight) before the hard cut to the stamp — one continuous PunchWord
// spring covers both, so only the end of the combined beat needs its own
// frame.
const BEAT_5_END = INTRO_END + 163;
const STAMP_DURATION = 80; // extended hold — the ElevenLabs VO track (223 frames) finishes mid-hold, comfortably

export const day3DurationInFrames = BEAT_5_END + STAMP_DURATION; // 310 frames = 10.33s @ 30fps
export const day3Fps = 30;
export const day3Width = 1080;
export const day3Height = 1920;

// Punchier custom spring for the hero payoff word ("You.") — WordPop's
// default (damping 9 / stiffness 260) is already snappy, but this is the
// single most important frame of the whole reel, so it overshoots harder
// and settles with more snap per the owner's "more motion graphics, more
// hook" note. Local to this file since it's a one-off exaggeration.
const PunchWord: React.FC<{ children: React.ReactNode; delay?: number }> = ({
  children,
  delay = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const local = Math.max(0, frame - delay);
  const pop = spring({
    frame: local,
    fps,
    config: { damping: 7, mass: 0.5, stiffness: 320 },
  });
  return (
    <div
      style={{
        transform: `scale(${0.4 + pop * 0.6})`,
        opacity: Math.min(1, local / 2),
      }}
    >
      {children}
    </div>
  );
};

// Shared type treatment for the accumulating words/phrases — same
// position/size so each hard cut reads as a word *replacing* the last one,
// not a new layout. Used by both the intro "waiting" beats and the original
// punch-sequence beats so the whole reel reads as one consistent system.
const wordStyle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 108,
  letterSpacing: -3,
  textAlign: "center",
  maxWidth: 950,
};

export const Day3Tagline: React.FC = () => {
  const frame = useCurrentFrame();
  const background = frame < PUNCH_FRAME ? kai.paper : kai.black;

  return (
    <AbsoluteFill style={{ background, fontFamily }}>
      <Audio src={staticFile("audio/day3.mp3")} />
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <WordStage />
      </AbsoluteFill>

      {/* The punch: one-frame white flash right on the bg color-flip cut. */}
      <FlashCut atFrame={PUNCH_FRAME} fadeFrames={4} />

      <Sequence from={BEAT_5_END} durationInFrames={STAMP_DURATION}>
        <KaiStamp startFrame={0} tagline="ChatGPT waits. KAI comes to you." />
      </Sequence>
    </AbsoluteFill>
  );
};

// Word-by-word accumulation — one word/phrase visible at a time, hard cuts
// between each (no crossfade), per the Build-The-Sentence template. Only
// color besides ink/paper before the punch is the LiveDot accent.
const WordStage: React.FC = () => {
  const frame = useCurrentFrame();

  // --- "Waiting" comparison intro (the chat-app side of the Ad 3 split) --
  if (frame < INTRO_A_END) {
    return (
      <WordPop style={{ ...wordStyle, color: kai.ink }}>
        You open an app.
      </WordPop>
    );
  }

  if (frame < INTRO_B_END) {
    return (
      <WordPop delay={INTRO_A_END} style={{ ...wordStyle, color: kai.ink }}>
        You type a question.
      </WordPop>
    );
  }

  if (frame < INTRO_C_END) {
    return (
      <WordPop delay={INTRO_B_END} style={{ ...wordStyle, color: kai.ink }}>
        ...then you wait.
      </WordPop>
    );
  }

  // --- Original punch sequence (the KAI side of the comparison) ---------
  if (frame < BEAT_1_END) {
    return (
      <WordPop delay={INTRO_END} from="none" style={{ ...wordStyle, fontSize: 160, color: kai.ink }}>
        KAI
      </WordPop>
    );
  }

  if (frame < BEAT_2_END) {
    return (
      <WordPop delay={BEAT_1_END} style={{ ...wordStyle, color: kai.ink }}>
        doesn't wait.
      </WordPop>
    );
  }

  if (frame < BEAT_3_END) {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <WordPop delay={BEAT_2_END} style={{ ...wordStyle, color: kai.ink }}>
          It calls.
        </WordPop>
        <LiveDot size={22} />
      </div>
    );
  }

  if (frame < BEAT_5_END) {
    return (
      <PunchWord delay={PUNCH_FRAME}>
        <div style={{ ...wordStyle, fontSize: 200, color: kai.paper }}>You.</div>
      </PunchWord>
    );
  }

  return null;
};
