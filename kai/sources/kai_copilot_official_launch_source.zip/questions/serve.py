#!/usr/bin/env python3
"""
Local-only questionnaire server for the KAI Copilot YouTube video questions.

  python3 serve.py            -> http://127.0.0.1:8766
  python3 serve.py 9000       -> custom port

Binds to 127.0.0.1 only — nothing is exposed to the network or published.
Serves questions.html and persists every change to answers.json (atomic write,
previous version kept in answers.prev.json).
"""
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(HERE, "questions.html")
ANSWERS_PATH = os.path.join(HERE, "answers.json")
PREV_PATH = os.path.join(HERE, "answers.prev.json")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8766

_lock = threading.Lock()


def _read_answers() -> dict:
    try:
        with open(ANSWERS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"version": 1, "status": "in_progress", "updated_at": None, "answers": {}}


def _write_answers(data: dict) -> None:
    tmp = ANSWERS_PATH + ".tmp"
    with _lock:
        if os.path.exists(ANSWERS_PATH):
            try:
                os.replace(ANSWERS_PATH, PREV_PATH)
            except OSError:
                pass
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")
        os.replace(tmp, ANSWERS_PATH)


class Handler(BaseHTTPRequestHandler):
    server_version = "kai-yt-questions/1"

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code: int, obj) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path in ("/", "/questions.html", "/index.html"):
            try:
                with open(HTML_PATH, "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._send(404, b"questions.html missing", "text/plain")
        elif path == "/answers.json":
            self._json(200, _read_answers())
        elif path == "/ping":
            self._json(200, {"ok": True, "t": time.time()})
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path != "/save":
            self._send(404, b"not found", "text/plain")
            return
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("answers"), dict):
                raise ValueError("bad shape")
        except (ValueError, UnicodeDecodeError) as e:
            self._json(400, {"ok": False, "error": f"invalid JSON: {e}"})
            return
        data["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
        data.setdefault("version", 1)
        data.setdefault("status", "in_progress")
        _write_answers(data)
        self._json(200, {"ok": True, "updated_at": data["updated_at"]})

    def log_message(self, fmt, *args):  # quiet
        if os.environ.get("KAI_Q_VERBOSE"):
            super().log_message(fmt, *args)


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"KAI questions -> http://127.0.0.1:{PORT}   (answers saved to {ANSWERS_PATH})", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
