# Introducing KAI Copilot — storyboard

One take on one paper world, 65.1 s (128 beats at 118 BPM; B = 0.508 s). Every time below comes from
`build/cues.json` (the voice lines are placed on the beat grid by `build/timeline.py`). The film is a single
composition (`index.html`): there are no hard cuts to split it on — the camera, the phone and the ball run
through every scene, which is the point.

Concept: **the green ball does everything.** KAI's Copilot ball is born in the phone, wakes every screen,
carries every scene boundary (it hops phone to phone, rings you, shoves the meeting to 18:30) and lands as the
dot in the KAI wordmark. Method borrowed from the onetake cases (one-dot, knockon, ebb): one central object,
causal carries instead of cuts, an operator camera that leads the action and takes a shake on each hit, a far
lattice to move against. (Method only — onetake's code is noncommercial and none of it is used.)

Layout grammar: words left, phone right; the hook and the end card are centred.

## Frame 1
- status: outline
- id: hook
- src: index.html#s-hook
- time: b0–16 (0.00–8.14)
- blueprint: zoom-out-workspace-reveal (adapted) · rules: svg-path-draw, spring-pop-entrance, cursor-click-ripple, multi-phase-camera
- beat: An ink line phone draws itself on paper; app tiles spring into it on "Your phone can do almost anything" while
  the camera pulls back. "But you still do all the tapping": a grey fingertip taps seven tiles on the 8ths. The tiles
  tire (dim). Rest. "Introducing": a green point is born in the middle of the screen — the ball — and pushes the
  tiles away; the camera leans in; a held breath before the drop.

## Frame 2
- status: outline
- id: title
- src: index.html#s-title
- time: b16–24 (8.14–12.20)
- blueprint: kinetic-type-beats (Product_Intro "Introducing…" name-drop) · rules: ambient-glow-bloom, viewport-change
- beat: On the drop ("KAI Copilot") the ball blooms and floods the screen with the Live screen's green; the line phone
  fills into the real ink phone; the camera whips out and slides the phone right. "KAI Copilot" lands left with a
  hard-edge wipe (the app's own splash move), "Introducing" above it. "Just tell it what you need." writes itself
  underneath, word by word.

## Frame 3
- status: outline
- id: whatsapp
- src: index.html#s-whatsapp
- time: b24–44 (12.20–22.37)
- blueprint: prompt-type-submit-generate → agent-progress-theater · rules: asr-keyword-glow, coordinate-target-zoom, card-morph-anchor
- beat: Live screen, listening. The user's command fills a big voice bubble on the left, each word lighting as it is
  spoken (and mirrors small inside the phone). KAI answers "On it!" in a green-barred bubble. The ball dives to
  where the real Copilot ball sits and opens the WhatsApp recording with an iris from itself. A four-step checklist
  ticks with the narration — Open WhatsApp / Find Alex / Type the message / Send — while the camera pushes onto
  the Alex chat, then the typed message, then the sent bubble. "Sequences shortened."

## Frame 4
- status: outline
- id: uber
- src: index.html#s-uber
- time: b44–52 (22.37–26.44)
- blueprint: device-surface-showcase (cursorless stepwise flow) · rules: motion-blur-streak, asr-keyword-glow, coordinate-target-zoom
- beat: The ball hops out of WhatsApp to the next phone along the rail (sleeping, black) and wakes it; the camera
  whips with it. "Get me a ride to George Town." fills the voice bubble. The Uber recording runs on the beat:
  home → route and rides → prices → Confirm details, Auto ₹165.73, "Done"; the camera pushes onto the fare.

## Frame 5
- status: outline
- id: doordash
- src: index.html#s-doordash
- time: b52–60 (26.44–30.51)
- blueprint: device-surface-showcase · rules: motion-blur-streak, asr-keyword-glow, coordinate-target-zoom
- beat: Hop to the third phone. "Order me a coffee meal from McDonald's." DoorDash on the beat: home → "coffee" →
  McDonald's → Big Brekkie Burger Meal → drink → cart, "Done"; push onto the cart.

## Frame 6
- status: outline
- id: anyapp
- src: index.html#s-anyapp
- time: b60–68 (30.51–34.58)
- blueprint: spatial-pan-stations (landing) + kinetic-type-beats · rules: nudge-curve, spring-pop-entrance
- beat: The camera pulls back; the WhatsApp and DoorDash phones glide in beside Uber — three finished tasks. "Any app."
  lands left; the ball hops across the three screens on the beat, each "Done" pulsing under it. "Without lifting a
  finger." in serif. The outer phones slide behind the middle one: one phone again.

## Frame 7
- status: outline
- id: call
- src: index.html#s-call
- time: b68–96 (34.58–48.81)
- blueprint: camera-journey (A: action roundtrip) · rules: press-release-spring, vertical-spring-ticker, transcript bubbles via asr-keyword-glow, reactive-displacement
- beat: The phone sleeps (lock screen 15:40). "And KAI doesn't wait for you to remember": left, today's card — Team
  Sync with Sarah, 16:00 — with "now" creeping toward it. "It calls you": the ball leaps into the phone and becomes the
  caller; the real incoming-call screen (rebuilt from IncomingCallActivity.kt: black, K avatar, Decline/Accept) rings
  in green ripples, the phone buzzing on the beat. Accept (b76) → the in-call screen (CallScreen.kt: dark green, the
  energy orb, "Call with KAI"). The conversation fills the left as big bubbles, word-lit: KAI's reminder; "Ugh, I'm
  stuck in traffic. Can you push it to six thirty?"; "Done. Moved to six thirty, and I've let Sarah know." On "moved"
  the ball flies out and shoves the meeting card: 16:00 rolls to 18:30, "Rescheduled from 16:00 · Notified on Slack"
  (the app's own wording, as on its calendar screen).

## Frame 8
- status: outline
- id: features
- src: index.html#s-features
- time: b96–112 (48.81–56.95)
- blueprint: fixed-anchor-cycle (phone pinned, words stack) · rules: kinetic-beat-slam, scale-swap-transition
- beat: Second drop. The ball drops into the phone and each impact swaps the screen to a real app screen: memory
  ("…I never forget."), the morning brief, the calendar (the sync now at 18:30 — the call's result), then a rebuilt
  Live talk screen with KAI speaking. Left, the words stack on each beat: Remembers. / Briefs. / Plans. / Talks back.

## Frame 9
- status: outline
- id: end
- src: index.html#s-end
- time: b112–128 (56.95–65.08)
- blueprint: logo-assemble-lockup + cta-morph-press · rules: spring-pop-entrance, press-release-spring
- beat: The phone falls away; the ball flies to centre and lands as the dot of KAI• Copilot on "Kai Copilot." "Your
  phone, on autopilot." in serif. "Get it on Google Play": the official badge springs in with "Also on iPhone · for
  Premium members" (user's wording — confirm). The ball hops onto a Subscribe pill and presses it (Subscribed ✓),
  then returns to its place in the name. Hold.
