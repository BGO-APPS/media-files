---
name: KAI ink & paper (film)
source: gnx_ai_kotlin theme/Mono.kt + theme/KaiTokens.kt, res/font; Copilot ball and Live screen sampled from the demo recordings
colors:
  paper: "#F6F6F4"        # canvas — the whole film sits on it
  card: "#FFFFFF"
  ink: "#0E0E10"          # all display type, phone bezel
  black: "#050505"        # incoming-call screen
  carbon: "#1C1C1E"
  graphite: "#3A3A3C"     # secondary type
  steel: "#8A8A8E"        # labels, upcoming words
  silver: "#C6C6C8"
  mist: "#E8E8EA"         # hairlines, lattice dots
  fog: "#F2F2F3"
  accent: "#23C552"       # KAI green — the one accent
  live: "#30D158"         # accept, live dot, KAI's bubble bar
  danger: "#FF453A"       # decline / end call only
  accentInk: "#08240F"
  evergreen: "#103F35"
  mint: "#D4F5E3"
  ballDeep: "#0B8F5E"     # Copilot ball: shadow side
  ball: "#11EB96"         # Copilot ball: body
  ballMid: "#3DF7BD"      # Copilot ball: mean colour (sampled)
  ballLight: "#76FFED"    # Copilot ball: highlight side
  liveGlow: "#5BFA84"     # Live screen glow core (sampled)
  liveGlowDeep: "#3CDE5D" # Live screen glow base (sampled)
  liveGlowSoft: "#BAEEC2" # Live screen glow edge (sampled)
  livePaper: "#F5F4EE"    # Live screen top (sampled)
  callTop: "#161618"      # in-call screen gradient top
  callBottom: "#0B2923"   # in-call screen gradient bottom (KaiFocus.background)
  callSurface: "#153F35"  # in-call orb rim (KaiFocus.surface)
  callSoft: "#BCD0C7"     # in-call secondary text (KaiFocus.onFocusSecondary)
  emerald: "#2D7962"      # in-call orb idle glow
typography:
  display: { family: "Syne", weight: 800, file: assets/fonts/syne_extrabold.ttf, use: "KAI Copilot, kinetic words, big statements" }
  editorial: { family: "Instrument Serif", style: italic, weight: 400, file: assets/fonts/instrument_serif_italic.ttf, use: "soft accents: almost anything, Your phone, on autopilot." }
  ui: { family: "Inter", weight: "400-700", file: assets/fonts/Inter-var.ttf, use: "rebuilt app screens, voice bubbles, labels" }
  scale: { hero: 150, title: 112, statement: 84, bubble: 44, label: 28, fineprint: 20 }
spacing:
  frameMargin: 120
  gutter: 64
components:
  phone: "ink bezel 12px, screen 404x875 world px (footage 1080x2338 at 0.37407), radius 62/50, punch-hole camera, soft contact shadow"
  ball: "the Copilot ball — liquid green swirl, WebGL shader, soft green bloom; real size in the phone 45 px, free size 60-160 px"
  voicePill: "white card (#FFFFFF), 2px mist border, radius 40, mic dot in accent, Inter 44px ink, words light up as spoken (steel -> ink)"
  kaiBubble: "white card, 6px live bar on the left edge, Inter 44px ink — KAI's spoken lines (matches the app's call bubble)"
  lattice: "mist dots every 48 world px at depth 0.8, under a paper vignette — the ground the camera moves against"
---

# KAI ink & paper — film spec

## Overview

The app's own look, scaled to a 1920×1080 frame: warm paper, ink type, one green. The only saturated colour that moves
is KAI's — the Copilot ball and the Live screen's glow. Everything the film says, it says in ink on paper.

## The frame

- **Ground.** Paper, a faint lattice of mist dots and a soft paper vignette. Never a flat white slide, never dark — except
  inside the phone when the app itself is dark (incoming call, in-call screen).
- **Layout grammar.** Words on the left, the phone on the right — the title, the voice commands, the call transcript and
  the feature words all live left of the phone. Only the hook and the end card are centred.
- **One take.** No cuts. The camera is an operator: it leads the ball by a beat, pushes in on what matters (the message,
  the price, the cart, the new meeting time) and takes a small shake on every hit.
- **The ball.** The hero. It is born in the phone, wakes every screen, carries every scene boundary and lands as the dot
  in the KAI wordmark.

## Type

- Syne ExtraBold for statements and the name, tight tracking (-0.02em), never below 84 px.
- Instrument Serif Italic for the soft line under a statement.
- Inter for anything that is UI: voice bubbles, the rebuilt app screens, labels, fine print.

## Do

- Use the real app screens and the real demo recordings; rebuild a screen in HTML only when there is no recording
  (Live, incoming call, in-call, calendar card), from the app's source values.
- Keep the accent for KAI: the ball, the live dot, KAI's bubble bar, the glow.
- Say "Sequences shortened." whenever a demo is cut or sped up.

## Don't

- No gradient text, no neon, no purple/blue gradients, no dark scenes outside the phone.
- No red except the Decline / End-call controls and the Google Play badge.
- No invented UI claims: everything KAI does on screen is something the app does.
