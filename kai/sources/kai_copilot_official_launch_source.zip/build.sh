#!/usr/bin/env bash
# "Introducing KAI Copilot" — rebuild. Every step re-derives from the one before it.
#
#   ./build.sh               timeline → footage → score → mix → check → render
#   ./build.sh vo [--force]  regenerate the voice first (ElevenLabs; --force redoes every take, e.g. after
#                            upgrading the plan so the takes carry a commercial licence), then all of the above
#   ./build.sh sound         score + mix (music or mix edits; Studio picks up the new master.wav)
#   ./build.sh media         timeline + footage cuts + mix (a voice line was re-placed)
#   ./build.sh video         check + render (picture edits only)
#
# Output: renders/kai-copilot.mp4 — 1920x1080, 30 fps, the picture as rendered with the mastered soundtrack
# (assets/audio/master.wav, -14 LUFS) re-encoded at 320 kb/s AAC.
set -euo pipefail
cd "$(dirname "$0")"

PY=/opt/miniconda3/bin/python3
HF="npx --yes hyperframes@0.8.137"
OUT=renders/kai-copilot.mp4

step() { printf '\n== %s\n' "$*"; }

timeline() { step "timeline (build/cues.json)"; $PY build/timeline.py; }
media()    { step "footage cuts (assets/video, footmap.js, <video> placement)"; $PY build/prep_media.py; }
score()    { step "score (music/stems)"; $PY build/score.py; }
mix()      { step "mix + master (assets/audio/master.wav)"; $PY build/mix.py; }

video() {
  step "check"
  $HF check
  step "render"
  mkdir -p renders
  $HF render . -o renders/kai-copilot.picture.mp4 --quality delivery
  step "soundtrack"
  local enc=aac
  ffmpeg -hide_banner -encoders 2>/dev/null | grep -q " aac_at " && enc=aac_at
  ffmpeg -y -hide_banner -loglevel error -i renders/kai-copilot.picture.mp4 -i assets/audio/master.wav \
    -map 0:v:0 -map 1:a:0 -c:v copy -c:a "$enc" -b:a 320k -ar 48000 -movflags +faststart "$OUT"
  rm renders/kai-copilot.picture.mp4
  step "verify $OUT"
  ffprobe -v error -show_entries stream=codec_type,codec_name,width,height,r_frame_rate,duration,bit_rate -of compact=p=0 "$OUT"
  ffmpeg -hide_banner -nostats -i "$OUT" -map 0:a -af ebur128=peak=true -f null - 2>&1 \
    | sed -n '/Summary:/,$p' | grep -E "I:|Peak:"
}

case "${1:-all}" in
  all)   timeline; media; score; mix; video ;;
  vo)    shift; step "voice (ElevenLabs)"; $PY build/make_vo.py "$@"; timeline; media; score; mix; video ;;
  sound) score; mix ;;
  media) timeline; media; mix ;;
  video) video ;;
  *) echo "usage: ./build.sh [all|vo [--force]|sound|media|video]" >&2; exit 2 ;;
esac
