---
workflow: general-video
flow: automation
storyboard: no
message: "KAI Copilot uses your phone for you — just say it — and KAI even calls you to keep your day on track"
destination: youtube
aspect: 1920x1080
language: en
length: 60s
angle: keynote product film ("Introducing KAI Copilot")
voice: elevenlabs/UgBBYS2sOqTuMpoF3BR0 (Mark - Natural Conversations)
---

## Intent

The first video on the KAI app's YouTube channel. Typical Apple-keynote "Introducing …" film, light theme matching the
app (ink & paper). Order the user asked for: (1) KAI Copilot — the main feature — controls any app on the phone,
(2) the AI that calls you with a reminder, and you can reschedule in that same call, (3) side features.
Tone: Apple keynote — confident, clean, every word lands. Built from scratch (standing rule: never open earlier
video projects' scripts).

## Assets

- ~/Downloads/DEM-VID-V10whatsaoo demo.mov — Copilot sends a WhatsApp message to Alex (hero demo).
- ~/Downloads/DEM-VID-V10uber demo video.mov — Copilot books an Uber Auto to George Town.
- ~/Downloads/DEM-VID-V10doordash.mov — Copilot orders a McDonald's meal on DoorDash.
- GNX/KAI-Why-Reel/assets/img/{call,calendar,memory,brief,reminders}.png — static app screens (call scene + side features); the user said to use static photos for the call.
- gnx_ai_kotlin theme/Mono.kt + res/font — brand tokens and the app's own fonts (Syne ExtraBold, Instrument Serif Italic).

## Customizations

- Concept: "the green ball does everything" — KAI's Copilot ball is the hero that carries every scene and lands as the dot in the KAI wordmark.
- Copilot clips: WhatsApp, Uber, DoorDash (user's pick).
- Side features: memory, morning brief, calendar/to-dos, Live talk.
- Narrator: ElevenLabs voice UgBBYS2sOqTuMpoF3BR0 via the user's `elevenlabs` CLI. In-demo user voice and KAI's voice are ElevenLabs premades (Jessica, Sarah).
- Music: original score in the vibe of the user's NUEVAYoL FL remake (118 BPM, A minor, house-dembow + salsa percussion), every hit synced to picture. Not a copy: the remake is built on the real Bad Bunny / El Gran Combo recordings.
- End card: Get it on Google Play + "iPhone: for Premium members" (user's wording, to confirm) + Subscribe.

## Notes

- ElevenLabs account is on the free plan (no commercial licence). Final VO must be regenerated after the user upgrades (Starter); build.sh `vo` step does it.
- Deepgram key in KAI-Why-Reel/.env is invalid now; STT uses ElevenLabs scribe.
- Don't use the demo clips' own audio (it contains ElevenLabs free-tier voices too).
