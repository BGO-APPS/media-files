# KAI Telegram Chat Demo — Automation Source Code

Cross-app voice command routing directives for Telegram automation.
