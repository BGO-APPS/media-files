# KAI Copilot Cross-App Recording — Architecture & Orchestration Specs

Multi-app state machine rules and screen navigation coordination notes.
