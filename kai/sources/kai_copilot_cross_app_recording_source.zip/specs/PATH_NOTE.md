# SDK & Environment Paths (Reference)

Current as of August 2026 (Mirrors `ENV_PATHS.md`).

## Android SDK
- Path: `/opt/homebrew/share/android-commandlinetools`
- Build tools: `35.0.0`, `36.0.0`
- Platforms: `android-36`
- Platform tools: includes `adb`

## JDK
- Path: `/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home`
- Target: `jvmTarget = 17`

## Gradle
- Wrapper pins Gradle 8.14 (Default `~/.gradle`)
