#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
echo "[RECORD] record_livetalk_uber: INFO - Cleaning up old recording..."
adb -s $DEVICE shell rm -f /sdcard/livetalk_uber.mp4

echo "[RECORD] record_livetalk_uber: INFO - Waking screen..."
adb -s $DEVICE shell input keyevent 224

echo "[RECORD] record_livetalk_uber: INFO - Starting screenrecord (time-limit 14s)..."
adb -s $DEVICE shell screenrecord --time-limit 14 /sdcard/livetalk_uber.mp4 &
RECORD_PID=$!

sleep 1.5

echo "[RECORD] record_livetalk_uber: INFO - Launching LiveTalkDemoScreen with demo_target uber..."
adb -s $DEVICE shell am force-stop com.gokul00060.gnxtour
adb -s $DEVICE shell am start -n com.gokul00060.gnxtour/com.gokul00060.gnxmobile.MainActivity --ez start_live_talk true --es demo_target uber

echo "[RECORD] record_livetalk_uber: INFO - Waiting for screenrecord to finish..."
wait $RECORD_PID || true

echo "[RECORD] record_livetalk_uber: INFO - Pulling recording..."
adb -s $DEVICE pull /sdcard/livetalk_uber.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_livetalk_uber.mp4

echo "[RECORD] record_livetalk_uber: INFO - Done! Saved to raw_livetalk_uber.mp4"
