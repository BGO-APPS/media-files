#!/usr/bin/env bash
set -e

DEVICE="RZCX904D1QV"
ADB="/opt/homebrew/share/android-commandlinetools/platform-tools/adb -s $DEVICE"

echo "[RECORD] record_copilot_uber: INFO - Pre-warming Uber to home screen..."
$ADB shell rm -f /sdcard/copilot_uber.mp4
$ADB shell input keyevent 224
$ADB shell wm dismiss-keyguard
$ADB shell input keyevent 82
$ADB shell am start -n com.ubercab/com.ubercab.presidio.app.core.root.RootActivity
sleep 2.5
# Press back or home so KAI Copilot can launch fresh and switch to Uber
$ADB shell input keyevent 3
sleep 1.0

echo "[RECORD] record_copilot_uber: INFO - Starting screenrecord (time-limit 22s)..."
$ADB shell screenrecord --time-limit 22 /sdcard/copilot_uber.mp4 &
RECORD_PID=$!

sleep 1.2

echo "[RECORD] record_copilot_uber: INFO - Launching KAI Copilot with run_uber_demo..."
$ADB shell am start -n com.gokul00060.gnxmobile/com.gokul00060.gnxmobile.MainActivity --ez run_uber_demo true

# s.setFocusedText in UberDemoScriptRunner types George Town natively

echo "[RECORD] record_copilot_uber: INFO - Waiting for Uber Copilot demo to complete..."
wait $RECORD_PID || true

echo "[RECORD] record_copilot_uber: INFO - Pulling recording..."
$ADB pull /sdcard/copilot_uber.mp4 /Users/skgokulbarath/Documents/LAMx/GNX/raw_copilot_uber.mp4

echo "[RECORD] record_copilot_uber: INFO - Done! Saved to raw_copilot_uber.mp4"
