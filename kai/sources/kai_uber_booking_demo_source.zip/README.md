# KAI Uber Booking Demo — Automation Script

Automated Uber Auto ride-hailing capture script and subtitle synchronization.
